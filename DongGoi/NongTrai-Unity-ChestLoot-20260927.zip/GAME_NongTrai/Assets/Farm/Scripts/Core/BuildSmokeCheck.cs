using System;
using System.Collections;
using System.IO;
using UnityEngine;

namespace NongTrai
{
    // Chỉ chạy khi có cờ kiểm tra, không ảnh hưởng phiên chơi thông thường.
    public sealed class BuildSmokeCheck : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if (Array.IndexOf(Environment.GetCommandLineArgs(), "-farmSmokeCheck") >= 0)
                new GameObject("Build Smoke Check").AddComponent<BuildSmokeCheck>();
        }
        IEnumerator Start()
        {
            Application.runInBackground = true;
            Application.targetFrameRate = 60;
            yield return null;
            var player = FindFirstObjectByType<FarmPlayer>();
            var hud = FindFirstObjectByType<FarmHud>();
            if (player == null || hud == null || Camera.main == null)
                throw new InvalidOperationException("Missing milestone 1 scene dependencies.");
            if(Array.IndexOf(Environment.GetCommandLineArgs(),"-farmSystemsOnly")>=0)
            {yield return new WaitForSeconds(2);yield return FarmSystemsChecks.Run(hud.save,player,hud);Application.Quit(0);yield break;}
            if(Array.IndexOf(Environment.GetCommandLineArgs(),"-farmWaterCanOnly")>=0)
            {yield return new WaitForSeconds(2);yield return FarmWaterCanChecks.Run(hud.save,player,hud);Application.Quit(0);yield break;}
            if(Array.IndexOf(Environment.GetCommandLineArgs(),"-farmTntOnly")>=0)
            {yield return new WaitForSeconds(2);yield return FarmTntChecks.Run(hud.save,player,hud);Application.Quit(0);yield break;}
            if(Array.IndexOf(Environment.GetCommandLineArgs(),"-farmFeedbackOnly")>=0)
            {yield return new WaitForSeconds(2);yield return FarmAdventureFeedbackChecks.Run(hud.save,player,hud);Application.Quit(0);yield break;}
            if(Array.IndexOf(Environment.GetCommandLineArgs(),"-farmPolishOnly")>=0)
            {
                yield return new WaitForSeconds(2);
                yield return FarmVisualChecks.Run(player,hud);
                yield return FarmPolishChecks.Run(hud.save,player,hud);
                Debug.Log("FARM_POLISH_ONLY_OK");Application.Quit(0);yield break;
            }
            player.SetPaused(false);
            // Cửa sổ kiểm tra nền có thể mất focus: tiếp tục mô phỏng trong thời gian chờ tiếp đất.
            float deadline = Time.time + 3;
            int frames = 0;
            while (Time.time < deadline || frames < 60)
            {
                player.SetPaused(false);
                frames++;
                yield return null;
            }
            if (!player.GetComponent<CharacterController>().isGrounded)
                throw new InvalidOperationException("Player did not settle on the ground. Position=" + player.transform.position
                    + " paused=" + player.Paused + " frames=" + frames);
            var originalPosition=player.transform.position;
            var jumpBlock=GameObject.CreatePrimitive(PrimitiveType.Cube);
            jumpBlock.transform.position=new Vector3(0,.5f,-32.8f);jumpBlock.transform.localScale=new Vector3(3,1,1);
            player.Teleport(new Vector3(0,.05f,-35));Physics.SyncTransforms();
            for(int n=0;n<10;n++)yield return null;
            var keyboard=UnityEngine.InputSystem.Keyboard.current;
            UnityEngine.InputSystem.InputSystem.QueueStateEvent(keyboard,new UnityEngine.InputSystem.LowLevel.KeyboardState(UnityEngine.InputSystem.Key.W,UnityEngine.InputSystem.Key.Space));
            float jumpEnd=Time.time+1.3f,maxJumpY=0;
            while(Time.time<jumpEnd){player.SetPaused(false);maxJumpY=Mathf.Max(maxJumpY,player.transform.position.y);yield return null;}
            UnityEngine.InputSystem.InputSystem.QueueStateEvent(keyboard,new UnityEngine.InputSystem.LowLevel.KeyboardState());
            yield return null;
            if(maxJumpY<1.2f||player.transform.position.z<-32)throw new InvalidOperationException("SPACE + forward failed to cross a one metre block: "+player.transform.position+" peak="+maxJumpY);
            var farmerMotion=player.visual.GetComponent<FarmerAnimation>();
            if(farmerMotion==null||farmerMotion.arms==null||farmerMotion.legs==null||farmerMotion.arms[0]==null||farmerMotion.legs[0]==null)
                throw new InvalidOperationException("Farmer arm/leg bones missing.");
            var legAtStart=farmerMotion.legs[0].localRotation;var armAtStart=farmerMotion.arms[0].localRotation;
            float legSwing=0,armSwing=0;
            UnityEngine.InputSystem.InputSystem.QueueStateEvent(keyboard,new UnityEngine.InputSystem.LowLevel.KeyboardState(UnityEngine.InputSystem.Key.W));
            float walkEnd=Time.time+.45f;
            while(Time.time<walkEnd){legSwing=Mathf.Max(legSwing,Quaternion.Angle(legAtStart,farmerMotion.legs[0].localRotation));
                armSwing=Mathf.Max(armSwing,Quaternion.Angle(armAtStart,farmerMotion.arms[0].localRotation));yield return null;}
            UnityEngine.InputSystem.InputSystem.QueueStateEvent(keyboard,new UnityEngine.InputSystem.LowLevel.KeyboardState());
            if(legSwing<3||armSwing<3)throw new InvalidOperationException("Farmer does not visibly swing arms and legs while walking: "+armSwing+"/"+legSwing);
            jumpBlock.SetActive(false);Destroy(jumpBlock);player.Teleport(originalPosition);
            Debug.Log("FARM_JUMP_BLOCK_OK: keyboard SPACE/W crossed a one metre collider.");
            player.cameraRig.ToggleView();
            if (!player.cameraRig.FirstPerson || player.visual.gameObject.activeSelf)
                throw new InvalidOperationException("First-person visibility failed.");
            yield return null;
            player.cameraRig.ToggleView();
            player.SetPaused(true);
            if (!hud.pausePanel.activeSelf) throw new InvalidOperationException("Pause UI failed.");
            hud.Resume();
            if (player.Paused || hud.pausePanel.activeSelf) throw new InvalidOperationException("Resume failed.");
            var field = FindFirstObjectByType<FieldManager>();
            var plots = FindObjectsByType<FarmPlot>(FindObjectsSortMode.None);
            if (field == null || plots.Length != 80) throw new InvalidOperationException("Expected 80 farm plots.");
            for (int i = 0; i < field.crops.Length; i++)
            {
                var plot = plots[i]; var crop = field.crops[i];
                plot.Work(crop, out _);
                if (plot.State != PlotState.Tilled) throw new InvalidOperationException("Tilling failed.");
                plot.Work(crop, out _); plot.Tick(100);
                if (plot.Growth <= 0 || plot.Growth >= 1) throw new InvalidOperationException("Dry crops must grow at reduced speed.");
                for(int watering=0;watering<22 && plot.State==PlotState.Growing;watering++)
                { plot.Work(crop,out _);plot.Tick(60); }
                if (plot.State != PlotState.Ready) throw new InvalidOperationException("Watered crop did not ripen.");
                plot.Work(crop, out int harvested); field.Record(crop, harvested);
                if (harvested != crop.yield || (i<6?field.Harvested[i]:hud.interaction.inventory.Count(crop.specialProduct)) != crop.yield || plot.State != PlotState.Tilled)
                    throw new InvalidOperationException("Harvest or inventory failed.");
                plot.Work(crop, out int duplicate);
                if (duplicate != 0 || plot.State != PlotState.Growing) throw new InvalidOperationException("Replant failed.");
                if(i>=6)hud.interaction.inventory.Remove(crop.specialProduct,crop.yield);
                if(i>=3)field.Harvested[i]=0; // Additional crop assertions should not change legacy shop funds.
            }
            // Trồng một dải cây trong phiên kiểm tra để xem hình dạng các giai đoạn; không lưu vào game.
            for (int i = 3; i < plots.Length; i++)
            {
                var crop = field.crops[i % 3];
                plots[i].Work(crop, out _); plots[i].Work(crop, out _); plots[i].Work(crop, out _);
                plots[i].Tick(crop.growthSeconds * ((i % 4 + 1) / 4f));
            }
            var controller = player.GetComponent<CharacterController>();
            controller.enabled = false; player.transform.position = new Vector3(-4, 0.3f, -16); controller.enabled = true;
            player.cameraRig.ReadLook(new Vector2(-20 / player.settings.mouseSensitivity, -12 / player.settings.mouseSensitivity));
            yield return null;
            string path = Path.Combine(Application.dataPath, "../smoke-preview.png");
            yield return new WaitForEndOfFrame();
            Capture(path, hud, Camera.main);
            if(FarmTutorialCoach.Instance==null)throw new InvalidOperationException("Beginner guide missing.");
            FarmTutorialCoach.Instance.Restore(true);
            var taskMap=FarmNoticeBoard.Instance;
            if(taskMap==null)throw new InvalidOperationException("Task map missing.");
            taskMap.Open();
            if(!taskMap.IsOpen||!player.Paused)throw new InvalidOperationException("E task map did not open with cursor.");
            Capture(Path.Combine(Path.GetDirectoryName(path),"task-map-preview.png"),hud,Camera.main);
            taskMap.Close();
            var animals = FindObjectsByType<FarmAnimal>(FindObjectsSortMode.None);
            if (animals.Length != 6) throw new InvalidOperationException("Expected six animals.");
            float[] travelled = new float[animals.Length];
            for (int i=0;i<animals.Length;i++) travelled[i]=animals[i].DistanceTravelled;
            float animalDeadline=Time.time+8;
            while(Time.time<animalDeadline) { player.SetPaused(false); yield return null; }
            for (int i=0;i<animals.Length;i++)
            {
                var a=animals[i];
                if(a.DistanceTravelled<=travelled[i]) throw new InvalidOperationException("Animal did not move: "+a.name);
                if(a.transform.position.x<a.minimum.x || a.transform.position.x>a.maximum.x || a.transform.position.z<a.minimum.y || a.transform.position.z>a.maximum.y)
                    throw new InvalidOperationException("Animal left paddock.");
            }
            player.SetPaused(true);
            Vector3 stopped=animals[0].transform.position;
            yield return new WaitForSeconds(.2f);
            if(animals[0].transform.position!=stopped) throw new InvalidOperationException("Animal moved while paused.");
            player.SetPaused(false);
            string folder=Path.GetDirectoryName(path);
            var camera=Camera.main;
            var shop=hud.interaction.shop;
            if(hud.instructions.activeSelf || hud.toast.text!="") throw new InvalidOperationException("Instructions must be hidden on entry.");
            shop.Open();
            if(!player.Paused || !shop.Panel.activeSelf || hud.pausePanel.activeSelf) throw new InvalidOperationException("Shop menu failed.");
            Capture(Path.Combine(folder,"shop-preview.png"),hud,camera);
            shop.ShowPage(1);Capture(Path.Combine(folder,"shop-blocks-preview.png"),hud,camera);
            shop.ShowPage(2);Capture(Path.Combine(folder,"shop-extra-preview.png"),hud,camera);
            hud.Resume();
            if(shop.Panel.activeSelf) throw new InvalidOperationException("Shop did not close.");
            var inventory=hud.interaction.inventory;
            inventory.Open();
            if(!inventory.Panel.activeSelf || !player.Paused || shop.Panel.activeSelf) throw new InvalidOperationException("Inventory panel failed.");
            Capture(Path.Combine(folder,"inventory-preview.png"),hud,camera);
            hud.Resume();
            FarmProcessing.Instance.Open();
            Capture(Path.Combine(folder,"processing-preview.png"),hud,camera);
            hud.Resume();
            FarmExpansion.Instance.Open();
            Capture(Path.Combine(folder,"land-preview.png"),hud,camera);
            hud.Resume();
            shop.barn.Open();
            Capture(Path.Combine(folder,"barn-preview.png"),hud,camera);
            hud.Resume();
            hud.mainMenu.SetActive(true);player.SetPaused(true);hud.pausePanel.SetActive(false);
            Capture(Path.Combine(folder,"main-menu-preview.png"),hud,camera);
            hud.OpenSettings();
            if(!hud.settingsPanel.activeSelf || hud.mainMenu.activeSelf)
                throw new InvalidOperationException("Settings menu failed.");
            Capture(Path.Combine(folder,"settings-preview.png"),hud,camera);
            hud.CloseSettings();
            hud.Resume();
            for(int i=0;i<5;i++) if(!shop.ConsumeSeed(0)) throw new InvalidOperationException("Seed use failed.");
            if(shop.ConsumeSeed(0)) throw new InvalidOperationException("Seed inventory went negative.");
            if(!shop.Purchase(0,out _) || shop.Seeds[0]!=5 || shop.Money!=980) throw new InvalidOperationException("Seed purchase failed.");
            if(!shop.Purchase(3,out _) || !shop.Purchase(4,out _)) throw new InvalidOperationException("Animal purchase failed.");
            int dailyMoney=shop.Money;
            if(shop.Purchase(4,out _)||shop.Money!=dailyMoney)throw new InvalidOperationException("Daily purchase limit failed.");
            TimeManager.Instance.Restore(TimeManager.Instance.Day+1,.25f,FarmWeather.Sunny);
            if(!shop.Purchase(4,out _))throw new InvalidOperationException("Next-day animal purchase failed.");
            if(shop.speciesPens[0].AnimalCount()!=2 || shop.speciesPens[1].AnimalCount()!=4) throw new InvalidOperationException("Species pens mismatched.");
            int money=shop.Money;
            if(shop.Purchase(4,out _) || shop.Money!=money) throw new InvalidOperationException("Pig pen capacity failed.");
            if(!shop.Purchase(7,out _) || !shop.extraPen.activeSelf || shop.extraChickenPen.capacity!=5) throw new InvalidOperationException("Second chicken pen purchase failed.");
            money=shop.Money;
            if(shop.Purchase(7,out _) || shop.Money!=money) throw new InvalidOperationException("Duplicate pen charged money.");
            if(shop.Purchase(8,out _) || shop.Money!=money) throw new InvalidOperationException("Insufficient funds failed.");
            int cropSale=0;for(int crop=0;crop<field.crops.Length;crop++)
                cropSale+=field.Harvested[crop]*inventory.Price(crop<3?crop:crop+40);
            if(shop.SellHarvest()!=cropSale || shop.SellHarvest()!=0) throw new InvalidOperationException("Selling crops failed.");
            if(!shop.Purchase(8,out _) || shop.BoughtTrees!=1 || inventory.Count(27)<1) throw new InvalidOperationException("Apple seed purchase failed.");
            shop.Credit(500);
            int woodBefore=inventory.Count(20),grassBefore=inventory.Count(25),feedBefore=shop.FeedStock;
            if(shop.Purchase(13,out _)||shop.Purchase(14,out _)||shop.Purchase(15,out _)||
                inventory.Count(20)!=woodBefore||inventory.Count(25)!=grassBefore||shop.FeedStock!=feedBefore)
                throw new InvalidOperationException("Blocks and animal feed must be crafted or gathered.");
            yield return null;
            inventory.Remove(27,1);
            var apple=Instantiate(shop.treePrefab,new Vector3(-28,0,-5),Quaternion.identity).GetComponent<FruitTree>();
            apple.age=240;
            apple.remaining=0; apple.Harvest(shop); apple.Harvest(shop);
            if(inventory.Count(3)!=5 || inventory.Sell(3,2)!=30 || inventory.Count(3)!=3 || shop.SellHarvest()!=45)
                throw new InvalidOperationException("Individual fruit sales failed.");
            if(inventory.Count(20)!=woodBefore || inventory.Count(25)!=grassBefore)
                throw new InvalidOperationException("Sell all crops must preserve building blocks.");
            var cow=FindObjectsByType<FarmAnimal>(FindObjectsSortMode.None);
            FarmAnimal milkCow=null, sheep=null, pig=null, chicken=null;
            foreach(var a in cow) { if(a.species==AnimalSpecies.Cow) milkCow=a; if(a.species==AnimalSpecies.Sheep) sheep=a; if(a.species==AnimalSpecies.Pig) pig=a; if(a.species==AnimalSpecies.Chicken) chicken=a; }
            milkCow.RestoreCooldown(0);sheep.RestoreCooldown(0);pig.RestoreCooldown(0);
            milkCow.TryCollect(inventory,out _); milkCow.TryCollect(inventory,out _);
            sheep.TryCollect(inventory,out _); sheep.TryCollect(inventory,out _);
            if(inventory.Count(5)!=3 || inventory.Count(6)!=2) throw new InvalidOperationException("Milk/wool cooldown failed.");
            var henPen=shop.speciesPens[3];int previousEggs=henPen.StoredEggs;henPen.Advance(30);
            if(henPen.StoredEggs!=previousEggs+henPen.AnimalCount()) throw new InvalidOperationException("Egg production failed.");
            inventory.AddProduct(FarmInventory.Eggs,henPen.CollectEggs());
            if(henPen.StoredEggs!=0 || inventory.Count(4)!=previousEggs+2) throw new InvalidOperationException("Egg collection failed.");
            var carry=hud.interaction.carry;
            var mover=player.GetComponent<CharacterController>();mover.enabled=false;
            player.transform.position=chicken.transform.position+new Vector3(0,0,1);mover.enabled=true;
            if(!carry.Pickup(chicken) || !chicken.IsCarried) throw new InvalidOperationException("Left click pickup logic failed.");
            mover.enabled=false;
            player.transform.position=new Vector3(shop.speciesPens[1].minimum.x+1,0,5);mover.enabled=true;
            camera.transform.rotation=Quaternion.LookRotation(Vector3.right);
            if(carry.Drop() || carry.Held==null) throw new InvalidOperationException("Wrong species drop allowed.");
            mover.enabled=false;player.transform.position=new Vector3(henPen.minimum.x+1,0,15);mover.enabled=true;
            camera.transform.rotation=Quaternion.LookRotation(Vector3.right);
            if(!carry.Drop() || carry.Held!=null || chicken.IsCarried || chicken.pen!=henPen) throw new InvalidOperationException("Right click drop failed.");
            pig.TryCollect(inventory,out _);
            yield return null;
            if(inventory.Count(7)!=6 || shop.speciesPens[1].AnimalCount()!=3) throw new InvalidOperationException("Meat/slaughter failed.");
            shop.Credit(500);
            for(int i=0;i<3;i++){TimeManager.Instance.Restore(TimeManager.Instance.Day+1,.25f,FarmWeather.Sunny);
                if(!shop.Purchase(6,out _)) throw new InvalidOperationException("Buying chicken up to five failed.");}
            money=shop.Money;
            if(shop.speciesPens[3].AnimalCount()!=5)
                throw new InvalidOperationException("Five chicken limit failed.");
            TimeManager.Instance.Restore(TimeManager.Instance.Day+1,.25f,FarmWeather.Sunny);
            if(!shop.Purchase(6,out _) || shop.extraChickenPen.AnimalCount()!=1)
                throw new InvalidOperationException("Second chicken pen assignment failed.");
            if(inventory.Sell(4,1)!=8 || inventory.Count(4)!=previousEggs+1 || inventory.Sell(7,int.MaxValue)!=180)
                throw new InvalidOperationException("Animal products did not sell correctly.");
            Debug.Log("FARM_INVENTORY_ANIMALS_OK: separate species pens, five hens per pen, egg production/collection, milk/wool cooldown, meat removes pig, mouse pickup/drop, individual product sales.");
            var gate=FindFirstObjectByType<PaddockGate>();gate.Toggle();
            float gateDeadline=Time.time+1.2f;
            while(Time.time<gateDeadline) { player.SetPaused(false); yield return null; }
            if(!gate.IsOpen || Quaternion.Angle(gate.door.localRotation,Quaternion.identity)<80) throw new InvalidOperationException("Gate did not open.");
            gate.Toggle();
            gateDeadline=Time.time+1.2f;
            while(Time.time<gateDeadline) { player.SetPaused(false); yield return null; }
            if(gate.IsOpen || Quaternion.Angle(gate.door.localRotation,Quaternion.identity)>1) throw new InvalidOperationException("Gate did not close.");
            player.SetPaused(true);hud.ToggleInstructions();
            if(!hud.instructions.activeSelf) throw new InvalidOperationException("Help tab failed.");
            Capture(Path.Combine(folder,"pause-preview.png"),hud,camera);
            hud.Resume();
            if(hud.instructions.activeSelf) throw new InvalidOperationException("Help remained visible after resume.");
            var save=hud.save;
            save.pathOverride=Path.Combine(Application.temporaryCachePath,"farm-smoke-save.json");
            int savedMoney=shop.Money, savedSeeds=shop.Seeds[0], savedEggs=shop.speciesPens[3].StoredEggs;
            int savedAnimals=FindObjectsByType<FarmAnimal>(FindObjectsSortMode.None).Length;
            if(!save.Save()) throw new InvalidOperationException("Save failed.");
            shop.Seeds[0]=0;shop.Credit(99);inventory.AnimalProducts[FarmInventory.Eggs]=0;
            shop.speciesPens[3].RestoreProduction(0,0);
            if(!save.Load()) throw new InvalidOperationException("Load failed.");
            yield return null;
            if(shop.Money!=savedMoney || shop.Seeds[0]!=savedSeeds || shop.speciesPens[3].StoredEggs!=savedEggs ||
                FindObjectsByType<FarmAnimal>(FindObjectsSortMode.None).Length!=savedAnimals)
                throw new InvalidOperationException("Save/load did not restore state.");
            File.Delete(save.SavePath);
            if(File.Exists(save.SavePath+".bak")) File.Delete(save.SavePath+".bak");
            save.pathOverride=null;
            Debug.Log("FARM_SAVE_OK: money, seeds, egg production and animals restored from JSON.");
            Debug.Log("FARM_SHOP_GATE_OK: seed consumption, all purchases, capacity, funds, duplicate purchase, selling, fruit harvest, gate open/close, shop/help/resume.");
            camera.transform.position=new Vector3(2.6f,1.5f,4);
            camera.transform.LookAt(new Vector3(2.6f,1.5f,7));
            hud.gameObject.SetActive(false);
            Capture(Path.Combine(folder,"sign-front.png"),hud,camera);
            camera.transform.position=new Vector3(2.6f,1.5f,10);
            camera.transform.LookAt(new Vector3(2.6f,1.5f,7));
            Capture(Path.Combine(folder,"sign-back.png"),hud,camera);
            camera.transform.position=player.transform.position+new Vector3(0,1.55f,3);
            camera.transform.LookAt(player.transform.position+Vector3.up*1.1f);
            Capture(Path.Combine(folder,"farmer-preview.png"),hud,camera);
            camera.transform.position=new Vector3(19,6,-5);
            camera.transform.LookAt(new Vector3(19,.8f,5));
            Capture(Path.Combine(folder,"animals-preview.png"),hud,camera);
            hud.gameObject.SetActive(true);
            Debug.Log("FARM_ANIMALS_SIGNS_OK: six animals moved, stayed in paddock, paused correctly; front/back sign and farmer screenshots captured.");
            var progress=FarmExpansion.Instance;
            var processing=FarmProcessing.Instance;
            var water=FarmWaterSystem.Instance;
            var orders=FarmCraftOrders.Instance;
            var creative=CreativeModeManager.Instance;
            var building=FarmBuildingSystem.Instance;
            if(progress==null || processing==null || processing.Recipes.Length!=11 || water==null || orders==null || creative==null || building==null)
                throw new InvalidOperationException("Expansion systems or JSON recipes missing.");
            water.Open();if(!player.Paused || !water.Panel.activeSelf) throw new InvalidOperationException("Water modal failed to open.");
            hud.Resume();if(water.Panel.activeSelf) throw new InvalidOperationException("Water modal did not close with resume/ESC flow.");
            orders.OpenCraft();if(!player.Paused || !orders.CraftPanel.activeSelf) throw new InvalidOperationException("Craft modal failed to open.");
            if(orders.Recipes.Length!=25||Array.Find(orders.Recipes,r=>r.id=="wooden_bow")==null||
               Array.Find(orders.Recipes,r=>r.id=="arrows")==null||Array.Find(orders.Recipes,r=>r.id=="water_flask")!=null||
               Array.Find(orders.Recipes,r=>r.id=="forge_table")==null)
                throw new InvalidOperationException("Bow, arrows or water flask recipe missing.");
            Capture(Path.Combine(folder,"craft-preview.png"),hud,camera);
            hud.Resume();if(orders.CraftPanel.activeSelf) throw new InvalidOperationException("Craft modal did not close with resume/ESC flow.");
            var beforeCraftRay=player.transform.position;
            player.Teleport(new Vector3(-4,.4f,24));Physics.SyncTransforms();
            Vector3 craftEye=new Vector3(-4,1.6f,24),craftFocus=new Vector3(-4,1,28);
            if(!hud.interaction.TryLeftInteractRay(new Ray(craftEye,(craftFocus-craftEye).normalized))||!orders.CraftPanel.activeSelf)
                throw new InvalidOperationException("Farm left-click ray did not open crafting table.");
            hud.Resume();player.Teleport(beforeCraftRay);
            milkCow=null;
            foreach(var candidate in FindObjectsByType<FarmAnimal>(FindObjectsSortMode.None))
                if(candidate.species==AnimalSpecies.Cow) { milkCow=candidate;break; }
            if(milkCow==null) throw new InvalidOperationException("Cow missing after load.");
            milkCow.RestoreCare(0,0);milkCow.RestoreCooldown(0);
            if(milkCow.TryCollect(inventory,out _)) throw new InvalidOperationException("Hungry cow produced milk.");
            shop.AddFeed(2);milkCow.Feed(shop,out _);milkCow.Feed(shop,out _);
            if(!milkCow.WellCared || !milkCow.TryCollect(inventory,out _))
                throw new InvalidOperationException("Feeding did not restore cow production.");
            shop.Credit(3000);
            if(!shop.speciesPens[0].Upgrade(shop,out _) || shop.speciesPens[0].capacity!=6)
                throw new InvalidOperationException("Pen upgrade failed.");
            if(!shop.speciesPens[3].Upgrade(shop,out _) || shop.speciesPens[3].capacity!=5)
                throw new InvalidOperationException("Chicken pen exceeded five animals.");
            int flourBefore=inventory.Count(8);
            inventory.Add(0,3);
            if(!processing.Enqueue(0) || processing.QueueCount!=1)
                throw new InvalidOperationException("Processing queue failed.");
            processing.OpenForMachine(0);
            if(!processing.Panel.activeSelf || !player.Paused) throw new InvalidOperationException("Machine-specific panel failed.");
            camera.transform.position=new Vector3(-12,3.5f,8);
            camera.transform.LookAt(new Vector3(-13,.8f,12));
            Capture(Path.Combine(folder,"machine-panel-preview.png"),hud,camera);
            hud.Resume();
            hud.gameObject.SetActive(false);
            Capture(Path.Combine(folder,"machines-preview.png"),hud,camera);
            hud.gameObject.SetActive(true);
            var fastJob=processing.Snapshot();fastJob[0].remaining=0;
            processing.Restore(fastJob);
            player.SetPaused(false);yield return null;
            if(inventory.Count(8)!=flourBefore+2 || processing.QueueCount!=0)
                throw new InvalidOperationException("Flour processing failed.");
            progress.GainExperience(500);
            if(progress.Level<2 || !progress.BuyRegion(1) || !progress.UnlockedRegions[1])
                throw new InvalidOperationException("Level gated land purchase failed.");
            if(!progress.UpgradeTool(0) || progress.ToolRadius(0)!=3)
                throw new InvalidOperationException("Tool upgrade failed.");
            water.Restore(new WaterState{pumpStock=1});
            if(water.RefillCan()!=water.CanCapacity || water.PumpStock!=0 || !water.Consume(1) || water.CanWater!=water.CanCapacity-1 || water.RefillCan()!=0)
                throw new InvalidOperationException("Finite pump stock or watering can failed.");
            water.AdvancePump(599);
            if(water.PumpStock!=0)throw new InvalidOperationException("Pump produced water before ten minutes.");
            water.AdvancePump(1);
            if(water.PumpStock!=1||water.RefillCan()!=1)throw new InvalidOperationException("Pump did not refill a partial can after ten minutes.");
            water.AdvancePump(1800);
            if(water.PumpStock!=3||water.RefillCan()!=water.CanCapacity||water.CarriedCans!=2)
                throw new InvalidOperationException("Three-can carry or pump buffer failed.");
            var pumpSnapshot=water.Snapshot();
            water.Restore(new WaterState{pumpStock=1,spareCans=3,canWater=0});
            if(water.RefillCan()!=0||water.CarriedCans!=3)
                throw new InvalidOperationException("Full carry of saved spare cans accepted a fourth can.");
            water.Restore(pumpSnapshot);
            if(FindFirstObjectByType<WaterPumpVisual>()==null)
                throw new InvalidOperationException("Visible pump water stream was not created.");
            camera.transform.position=new Vector3(31,3.2f,-16);
            camera.transform.LookAt(new Vector3(28.5f,1.1f,-11));
            Capture(Path.Combine(folder,"water-pump-preview.png"),hud,camera);
            if(!water.BuyStation(0)||water.StationWater[0]!=8) throw new InvalidOperationException("Irrigation station initial charge failed.");
            if(water.TransferToStation(0)<=0 || water.StationWater[0]<=0)
                throw new InvalidOperationException("Irrigation station transfer failed.");
            var irrigation=FindFirstObjectByType<IrrigationStation>();
            if(irrigation==null) throw new InvalidOperationException("Built irrigation station visual missing.");
            player.SetPaused(false);yield return new WaitForSeconds(.6f);
            if(!irrigation.WaterVisualsActive)
                throw new InvalidOperationException("Active sprinkler range or water spray is invisible.");
            camera.transform.position=irrigation.transform.position+new Vector3(7,4.5f,-7);
            camera.transform.LookAt(irrigation.transform.position+Vector3.up*.7f);
            Capture(Path.Combine(folder,"irrigation-preview.png"),hud,camera);
            camera.transform.position=irrigation.transform.position+new Vector3(0,2.3f,-10);
            camera.transform.LookAt(irrigation.transform.position+Vector3.up*.85f);
            Capture(Path.Combine(folder,"irrigation-eye-preview.png"),hud,camera);
            int bundles=inventory.Count(16);inventory.Add(0,2);inventory.Add(1,1);
            if(!orders.Craft(0) || inventory.Count(16)!=bundles+1)
                throw new InvalidOperationException("JSON crafting recipe failed.");
            inventory.Add(20,5);
            if(!orders.Craft(4) || inventory.Count(26)!=1) throw new InvalidOperationException("Crafting table recipe failed.");
            inventory.Add(20,2);if(!orders.Craft(5)||inventory.Count(28)==0)throw new InvalidOperationException("Decorative wood steps recipe failed.");
            inventory.Add(3,3);inventory.Add(0,3);int cake=inventory.Count(32);
            if(!orders.Craft(9)||inventory.Count(32)!=cake+1)throw new InvalidOperationException("Apple cake recipe failed.");
            inventory.Add(0,2);inventory.Add(2,2);int feed=inventory.Count(34);
            if(!orders.Craft(11)||inventory.Count(34)!=feed+1)throw new InvalidOperationException("Premium animal feed recipe failed.");
            building.Toggle();
            if(!building.TryPlaceSelected(new Vector3(0,.5f,-35),0) || inventory.Count(26)!=0 || !building.HasPlacedTable)
                throw new InvalidOperationException("Crafting table placement failed.");
            building.Select(0);
            inventory.Add(20,1);
            int woodForBuilding=inventory.Count(20);
            if(!building.TryPlaceSelected(new Vector3(2,.5f,-35),0) || inventory.Count(20)!=woodForBuilding-1 ||
                building.Snapshot().blocks.Length!=2)
                throw new InvalidOperationException("Block placement did not consume one block.");
            building.Toggle();
            building.Toggle();
            if(!building.IsBuilding) throw new InvalidOperationException("Building mode failed to open with placed crafting table.");
            Capture(Path.Combine(folder,"building-preview.png"),hud,camera);
            building.Toggle();
            building.Restore(new BuildingState{blocks=new[]{new PlacedBlockRecord{type=0,position=new Vector3(205,.5f,18),euler=Vector3.zero}}});
            if(building.Snapshot().blocks.Length!=1) throw new InvalidOperationException("Placeable block restore failed.");
            building.Restore(new BuildingState{blocks=new[]{new PlacedBlockRecord{type=12,position=new Vector3(5,.5f,-35),euler=Vector3.zero}}});
            if(!AdventureWolves.Instance.IsSafe(new Vector3(5,.5f,-35)))throw new InvalidOperationException("Campfire did not repel wolves.");
            var retreatWolf=NightWolf.Create(new Vector3(5,.5f,-35),AdventureWolves.Instance);retreatWolf.Retreat();
            player.SetPaused(false);yield return new WaitForSeconds(1);
            if(retreatWolf!=null)throw new InvalidOperationException("Wolf did not return to its den at sunrise.");
            building.Restore(new BuildingState{blocks=new[]{new PlacedBlockRecord{type=0,position=new Vector3(205,.5f,18),euler=Vector3.zero}}});
            var store=FarmStorage.Instance;
            if(store==null||orders.Orders.Length!=5||AdventureWolves.Instance==null)
                throw new InvalidOperationException("Five orders, storage or wolf system missing.");
            var orderItems=new System.Collections.Generic.HashSet<int>();
            foreach(var order in orders.Orders)
                if(order.remaining<=0||order.difficulty<1||order.difficulty>5||!orderItems.Add(order.item))
                    throw new InvalidOperationException("Order variety, difficulty or deadline failed.");
            orders.OpenMail();Capture(Path.Combine(folder,"mail-preview.png"),hud,camera);hud.Resume();
            store.Open();int stored=store.Warehouse[0];inventory.Add(0,3);
            if(!store.Transfer(0,3,true)||store.Warehouse[0]!=stored+3||!store.Transfer(0,3,false)||store.Warehouse[0]!=stored)
                throw new InvalidOperationException("Warehouse transfer failed.");
            var testChest=FarmChest.Create(new Vector3(5,1,-35),true,"smoke-open",new int[38]);
            testChest.items[20]=3;
            int dropsBefore=WorldPickup.Snapshot().Length;
            store.Open(testChest);
            Capture(Path.Combine(folder,"chest-direct-loot-preview.png"),hud,camera);
            int chestWoodBefore=inventory.Count(20);
            if(!store.Panel.activeSelf||!testChest.gameObject.activeSelf||!store.Transfer(20,1,false)||testChest.items[20]!=2||inventory.Count(20)!=chestWoodBefore+1||WorldPickup.Snapshot().Length!=dropsBefore)
                throw new InvalidOperationException("Chest did not open directly for taking items.");
            hud.Resume();store.Open(testChest);store.TakeAll();
            if(testChest.items[20]!=0||inventory.Count(20)!=chestWoodBefore+3)throw new InvalidOperationException("Take all did not preserve the partially looted chest.");
            hud.Resume();testChest.BreakExploration();
            var rewardChest=FarmChest.Create(new Vector3(7,1,-35),true,"smoke-break",new int[FarmInventory.ItemCount]);
            rewardChest.items[20]=3;dropsBefore=WorldPickup.Snapshot().Length;rewardChest.BreakExploration();
            int dropsAfter=WorldPickup.Snapshot().Length;rewardChest.BreakExploration();
            if(rewardChest.gameObject.activeSelf||dropsAfter<=dropsBefore||WorldPickup.Snapshot().Length!=dropsAfter)
                throw new InvalidOperationException("Breaking unopened chest lost or duplicated loot.");
            Debug.Log("FARM_CHEST_DIRECT_OK: open, take one/all, reopen partial chest, break unopened chest, no duplicate drops.");
            if(!orders.Reroll(0) || orders.RerollRemaining<=0)
                throw new InvalidOperationException("Order reroll cooldown failed.");
            for(int i=0;i<orders.Orders.Length;i++)
            { inventory.Add(orders.Orders[i].item,orders.Orders[i].count);if(!orders.Deliver(i)) throw new InvalidOperationException("Order delivery failed."); }
            if(orders.CompletedOrders<2 || !orders.ProcessingUnlocked("bread"))
                throw new InvalidOperationException("Order recipe unlock failed.");
            save.pathOverride=Path.Combine(Application.temporaryCachePath,"farm-expansion-smoke-save.json");
            int savedLevel=progress.Level,savedFeed=shop.FeedStock,savedStation=water.StationWater[0],savedOrders=orders.CompletedOrders;
            store.Warehouse[20]=4;var savedRunner=FarmRunner.Instance.Snapshot();var savedFuel=(float[])processing.FuelSeconds.Clone();
            if(!save.Save()) throw new InvalidOperationException("Expansion save failed.");
            progress.Restore(1,0,1,0,null,null);shop.AddFeed(9);
            water.Restore(null);orders.Restore(null,false);building.Restore(null);store.Restore(null);FarmRunner.Instance.Restore(new RunnerState{tickets=0});processing.RestoreFuel(null);
            if(!save.Load() || progress.Level!=savedLevel || !progress.UnlockedRegions[1] ||
                progress.ToolRadius(0)!=3 || shop.FeedStock!=savedFeed || water.StationWater[0]!=savedStation ||
                orders.CompletedOrders!=savedOrders || building.Snapshot().blocks.Length!=1 || store.Warehouse[20]!=4)
                throw new InvalidOperationException("Expansion save did not restore state.");
            if(FarmRunner.Instance.Tickets!=savedRunner.tickets||processing.FuelSeconds[0]!=savedFuel[0]||processing.FuelSeconds[1]!=savedFuel[1])throw new InvalidOperationException("v17 runner/fuel save round-trip failed.");
            File.Delete(save.SavePath);
            if(File.Exists(save.SavePath+".bak")) File.Delete(save.SavePath+".bak");
            save.pathOverride=null;
            Debug.Log("FARM_EXPANSION_OK: animal care, pens, JSON processing, region gates, tools and manual save.");
            var clock=TimeManager.Instance;
            var islands=IslandManager.Instance;
            var disaster=FindFirstObjectByType<DisasterPuzzleManager>();
            if(clock==null || islands==null || disaster==null || TimeManager.DayLengthSeconds!=1080)
                throw new InvalidOperationException("Time, island or disaster manager missing.");
            clock.Restore(28,.80f,FarmWeather.Sunny);
            if(clock.Season!=FarmSeason.Spring || clock.Year!=1)
                throw new InvalidOperationException("Season calendar incorrect.");
            clock.SleepUntilMorning();
            if(disaster.Pending) disaster.Answer(0);
            if(clock.Day!=29 || clock.Season!=FarmSeason.Summer || clock.Hour!=6)
                throw new InvalidOperationException("Sleep or season transition failed.");
            plots[0].Restore(PlotState.Growing,field.crops[0],0,0);
            clock.SetWeather(FarmWeather.Rain);
            if(plots[0].Moisture<.99f) throw new InvalidOperationException("Rain did not water crops.");
            clock.SetWeather(FarmWeather.Storm,true);
            if(!disaster.Pending || disaster.ProjectedDamage<30 || disaster.ProjectedDamage>80)
                throw new InvalidOperationException("Storm puzzle did not start.");
            disaster.Answer(0);
            if(disaster.LastDamage!=0 || disaster.LastPrevented==0)
                throw new InvalidOperationException("Correct storm answer did not protect farm.");
            inventory.Add(0,10);int beforeStorm=inventory.Count(0);
            disaster.BeginStorm();disaster.Answer(1);
            if(inventory.Count(0)>=beforeStorm || disaster.LastDamage==0)
                throw new InvalidOperationException("Wrong storm answer caused no damage.");
            clock.SetWeather(FarmWeather.Sunny);
            progress.GainExperience(2000);
            if(progress.LevelCap!=99) throw new InvalidOperationException("Normal level cap failed.");
            if(!islands.Travel(1) || Mathf.Abs(player.transform.position.x-200)>2 || islands.Travel(2) || islands.Travel(3))
                throw new InvalidOperationException("Two map travel failed.");
            var rememberedExplore=IslandManager.ExploreArrival+new Vector3(10,0,5);
            player.Teleport(rememberedExplore);islands.Travel(0);islands.Travel(1);
            if(Vector3.Distance(player.transform.position,rememberedExplore)>1)throw new InvalidOperationException("Exploration position was not remembered between maps.");
            player.Teleport(IslandManager.ExploreArrival);
            clock.Restore(clock.Day,.5f,FarmWeather.Sunny);
            camera.transform.position=new Vector3(232,1028,-36);
            camera.transform.LookAt(new Vector3(199,1001,0));
            Capture(Path.Combine(folder,"exploration-preview.png"),hud,camera);
            inventory.Add(13,2);
            if(processing.Enqueue(5)) throw new InvalidOperationException("Furnace worked without blueprint.");
            var exploration=ExplorationWorld.Instance;
            var beforeRay=exploration.Snapshot();
            player.Teleport(new Vector3(186,1000.05f,-20));Physics.SyncTransforms();
            var aimed=new Vector3(186,999.98f,-18);
            var rayStart=new Vector3(186,1003,-24);
            var thirdPersonRay=new Ray(rayStart,(aimed-rayStart).normalized);
            if(exploration.UpdateMiningRay(thirdPersonRay,true,.45f)||!exploration.UpdateMiningRay(thirdPersonRay,true,.45f))
                throw new InvalidOperationException("Third person hold-to-mine ray failed.");
            if(exploration.BlockAt(new Vector3Int(10,3,6))!=0)throw new InvalidOperationException("Aimed surface block was not excavated.");
            exploration.Restore(beforeRay);Physics.SyncTransforms();
            var eye=player.transform.position+Vector3.up*1.65f;
            if(!exploration.UpdateMiningRay(new Ray(eye,(aimed-eye).normalized),true,.9f))throw new InvalidOperationException("First person hold-to-mine ray failed.");
            exploration.Restore(beforeRay);islands.Travel(1);
            Debug.Log("FARM_MINING_RAY_OK: first/third person rays, hold duration and terrain mutation.");
            int mined=0;
            for(int x=0;x<10 && mined<30;x++)for(int z=12;z<30 && mined<30;z++)
                if(exploration.MineCell(new Vector3Int(x,2,z)))mined++;
            if(mined!=30 || exploration.MinedCount!=30 || islands.Blueprints!=1)
                throw new InvalidOperationException("Voxel mining blueprint failed.");
            int seed=exploration.Seed;
            var farCell=new Vector3Int(-160,2,320);
            while(exploration.BlockAt(farCell)==0)farCell.x++;

            var farPoint=ExplorationWorld.Origin+new Vector3(farCell.x,exploration.SurfaceHeight(farCell.x,farCell.z)+2,farCell.z);
            player.Teleport(farPoint);
            yield return null;
            if(!exploration.MineCell(farCell)||exploration.BlockAt(farCell)!=0)throw new InvalidOperationException("Far negative chunk mining failed.");
            var chunkState=exploration.Snapshot();
            int sampleHeight=exploration.SurfaceHeight(512,512);
            exploration.Restore(new ExplorationState{seed=seed,generatorVersion=chunkState.generatorVersion});
            if(exploration.SurfaceHeight(512,512)!=sampleHeight)throw new InvalidOperationException("Same seed changed terrain.");
            var heights=new int[16];for(int n=0;n<16;n++)heights[n]=exploration.SurfaceHeight(256+n*16,512);
            bool changed=false;
            exploration.Restore(new ExplorationState{seed=seed^73417,generatorVersion=chunkState.generatorVersion});
            for(int n=0;n<16;n++)if(exploration.SurfaceHeight(256+n*16,512)!=heights[n])changed=true;
            if(!changed)throw new InvalidOperationException("Different seeds generated identical sampled terrain.");

            exploration.Restore(chunkState);
            if(exploration.Seed!=seed||exploration.BlockAt(farCell)!=0)throw new InvalidOperationException("Seeded terrain restore failed.");
            for(int step=0;step<8;step++)
            {
                player.Teleport(ExplorationWorld.Origin+new Vector3(256+step*64,32,256));
                yield return null;
                if(exploration.LoadedChunkCount>49)throw new InvalidOperationException("Chunk streaming leaked loaded terrain.");
            }
            islands.Travel(1);
            player.Teleport(farPoint);
            for(int frame=0;frame<30;frame++)yield return null;
            camera.transform.position=farPoint+new Vector3(0,3,-6);
            camera.transform.LookAt(farPoint+new Vector3(0,0,14));
            Capture(Path.Combine(folder,"streamed-world-preview.png"),hud,camera);
            islands.Travel(1);
            var legacy=new ExplorationState{removed=new[]{(0*18+2)*48+12},minedCount=30};
            exploration.Restore(legacy);
            if(exploration.BlockAt(new Vector3Int(0,2,12))!=0)throw new InvalidOperationException("v7 voxel migration failed.");
            exploration.Restore(chunkState);
            Debug.Log("FARM_STREAMING_OK: seeded terrain, distant/negative coordinates, unloading cap, excavated persistence and v7 voxel migration.");
            if(exploration.MineCell(new Vector3Int(24,2,4)))throw new InvalidOperationException("Spawn was mineable.");
            hud.Resume();
            if(!processing.Enqueue(5)) throw new InvalidOperationException("Furnace did not unlock.");
            clock.Restore(clock.Day+1,.25f,FarmWeather.Sunny);
            var hotbar=FindFirstObjectByType<FarmHudV2>();hotbar.Select(8);
            if(AdventureBag.Instance.Selected!=8) throw new InvalidOperationException("Nine slot hotbar failed.");
            islands.Travel(0);player.Teleport(new Vector3(8,.4f,14));islands.Travel(1);
            player.Teleport(IslandManager.ExploreArrival);
            save.pathOverride=Path.Combine(Application.temporaryCachePath,"farm-islands-smoke-save.json");
            if(!save.Save()) throw new InvalidOperationException("Island save failed.");
            clock.Restore(1,.25f,FarmWeather.Sunny);player.Teleport(Vector3.zero);
            exploration.Restore(null);
            if(!save.Load() || exploration.MinedCount!=31 || exploration.MineCell(new Vector3Int(0,2,12)) || clock.Day<=1 || islands.Blueprints!=1 ||
                Mathf.Abs(player.transform.position.x-200)>2)
                throw new InvalidOperationException("Time/island save did not restore.");
            islands.Travel(0);
            if(Mathf.Abs(player.transform.position.x-8)>1)throw new InvalidOperationException("Saved farm return position was lost.");
            islands.Travel(1);
            if(Mathf.Abs(player.transform.position.x-200)>2)throw new InvalidOperationException("Saved exploration return position was lost.");
            string modernSave=File.ReadAllText(save.SavePath);
            player.Teleport(new Vector3(200,.4f,-20));
            if(!save.Save())throw new InvalidOperationException("Migration fixture save failed.");
            string oldSave=File.ReadAllText(save.SavePath).Replace("\"version\": 21","\"version\": 7");
            File.WriteAllText(save.SavePath,oldSave);
            if(!save.Load()||Mathf.Abs(player.transform.position.y-1000.4f)>1)throw new InvalidOperationException("Legacy player position migration failed.");
            File.WriteAllText(save.SavePath,modernSave);if(!save.Load())throw new InvalidOperationException("Modern restore failed.");
            File.Delete(save.SavePath);
            if(File.Exists(save.SavePath+".bak")) File.Delete(save.SavePath+".bak");
            save.pathOverride=null;
            Debug.Log("FARM_ISLANDS_TIME_OK: 18-minute day, seasons, rain, storm puzzle, sleep, two portals with remembered positions, voxel mining, level cap, furnace blueprint, hotbar and manual save.");
            yield return AdventureChecks.Run(save,player);
            yield return FarmV12Checks.Run(save,player);
            var beforeFallPosition=player.transform.position;
            var survival=AdventureWolves.Instance;
            survival.RestoreHealth(100);
            player.SetPaused(false);
            player.Teleport(new Vector3(0,14,0));
            yield return null;
            float fallDeadline=Time.time+5f;
            while(Time.time<fallDeadline&&!player.GetComponent<CharacterController>().isGrounded)
            {player.SetPaused(false);yield return null;}
            if(!player.GetComponent<CharacterController>().isGrounded||survival.Health>=100)
                throw new InvalidOperationException("High fall did not cause damage or player did not land: position="+player.transform.position+" health="+survival.Health+" paused="+player.Paused+" creative="+CreativeModeManager.IsCreative);
            survival.RestoreHealth(100);
            player.Teleport(beforeFallPosition);
            Debug.Log("FARM_FALL_DAMAGE_OK: high fall cost health, landing and restore remain safe.");
            yield return FarmPolishChecks.Run(save,player,hud);
            yield return FarmAdventureFeedbackChecks.Run(save,player,hud);
            yield return FarmTntChecks.Run(save,player,hud);
            yield return FarmWaterCanChecks.Run(save,player,hud);
            yield return FarmSystemsChecks.Run(save,player,hud);
            save.pathOverride=Path.Combine(Application.temporaryCachePath,"farm-creative-do-not-save.json");
            if(File.Exists(save.SavePath)) File.Delete(save.SavePath);
            creative.StartCreative();
            if(progress.Level!=99 || progress.LevelCap!=99 || !CreativeModeManager.IsFlying)
                throw new InvalidOperationException("Creative mode did not enable LV99 and flight.");
            progress.Restore(1,0,1,.25f,null,null);
            if(!CreativeModeManager.IsCreative || !islands.Travel(1) || player.transform.position.y<500)
                throw new InvalidOperationException("Creative LV1 island travel failed.");
            creative.ToggleFlight();if(CreativeModeManager.IsFlying) throw new InvalidOperationException("Creative flight toggle failed.");
            if(save.Save() || File.Exists(save.SavePath)) throw new InvalidOperationException("Creative mode wrote a save file.");
            save.pathOverride=null;
            Debug.Log("FARM_WATER_ORDERS_CREATIVE_OK: finite water, irrigation, JSON craft, daily orders, v8 seeded chunk/terrain/building save and discard-only creative mode.");
            yield return new WaitForSeconds(2);
            var runner=FarmRunner.Instance;
            if(runner==null)throw new InvalidOperationException("Farm Runner missing from Tab map.");
            runner.Restore(new RunnerState{tickets=3});runner.OpenMenu();
            int tickets=runner.Tickets;
            if(!runner.StartRun()||!runner.IsRunning||runner.Tickets!=tickets-1||runner.PoolCount!=6||runner.RunCamera.targetTexture!=null)
                throw new InvalidOperationException("Runner full-screen map/ticket/pool failed.");
            runner.ChangeLane(-1);runner.Jump();runner.Tick(.05f);
            if(runner.Lane!=0)throw new InvalidOperationException("Runner lane input failed.");
            float runDistance=runner.Distance;runner.Tick(.2f);
            if(runner.Distance-runDistance<2||Mathf.Abs(runner.RunCamera.transform.position.x+.832f)>.08f)
                throw new InvalidOperationException("Runner lost slow-frame time or lane transition exceeded 0.25 seconds.");
            Debug.Log("FARM_RUNNER_INPUT_OK: 200ms frame time preserved, lane settled within 250ms.");
            yield return new WaitForEndOfFrame();Capture(Path.Combine(folder,"runner-preview.png"),hud,runner.RunCamera);
            runner.Finish();int paid=shop.Money;runner.Finish();if(shop.Money!=paid)throw new InvalidOperationException("Runner rewarded twice.");
            runner.Restore(new RunnerState{tickets=0,ticketClock=DateTimeOffset.UtcNow.ToUnixTimeSeconds()-14400});
            if(runner.Tickets!=2||FarmRunner.DistanceReward(2000)<=FarmRunner.DistanceReward(1000)*2)
                throw new InvalidOperationException("Runner ticket refill/progressive reward failed.");
            runner.AwardTicket();shop.Credit(500);if(!runner.BuyTicket()||runner.Tickets!=4)throw new InvalidOperationException("Runner ticket award/buy failed.");
            int stonesBefore=inventory.Count(68),tntBefore=inventory.Count(69);
            if(!runner.StartRun())throw new InvalidOperationException("Runner replay failed.");
            runner.Slide();runner.Tick(.01f);if(!runner.Sliding)throw new InvalidOperationException("Runner slide failed.");
            for(int tick=0;tick<5000&&runner.IsRunning&&runner.Distance<2050;tick++)
            {int open=runner.ClearLaneAhead;runner.ChangeLane(open-runner.Lane);runner.Tick(.05f);}
            if(!runner.IsRunning||runner.Distance<2000||runner.PoolCount!=6)throw new InvalidOperationException("Runner safe route/pool failed before 2km: "+runner.Distance);
            runner.Finish();if(inventory.Count(68)!=stonesBefore+1||inventory.Count(69)!=tntBefore+1)throw new InvalidOperationException("Runner milestone gifts missing.");
            hud.Resume();Debug.Log("FARM_RUNNER_OK: independent full-screen scene, farmer, lane/jump, six pooled segments, tickets, escalating reward, one-time settlement.");
            if(Array.IndexOf(Environment.GetCommandLineArgs(),"-farmArtCheck")>=0)yield return FarmVisualChecks.Run(player,hud);
            if(player.GetComponent<FarmBow>()==null)throw new InvalidOperationException("Bow shooting component missing.");
            inventory.Add(20,4);inventory.Add(21,2);inventory.Add(6,1);inventory.Add(15,1);
            int bowRecipe=Array.FindIndex(orders.Recipes,r=>r.id=="wooden_bow");
            int arrowRecipe=Array.FindIndex(orders.Recipes,r=>r.id=="arrows");
            if(!orders.Craft(bowRecipe)||!orders.Craft(arrowRecipe)||inventory.Count(63)<5)throw new InvalidOperationException("Bow/arrow crafting failed.");
            water.FillFromRiver();water.EmptyBucket();
            if(water.CanWater!=0||Array.Exists(orders.Recipes,r=>r.output==64||r.output==71))throw new InvalidOperationException("Duplicate bottle recipes remain.");
            Debug.Log("FARM_BOW_WATER_OK: bow and five arrows crafted; unified bucket, old bottle recipes removed.");
            inventory.Add(20,4);inventory.Add(21,4);inventory.Add(15,3);inventory.Add(13,2);shop.Credit(100);
            int forgeRecipe=Array.FindIndex(orders.Recipes,r=>r.id=="forge_table");
            if(!orders.Craft(forgeRecipe)||inventory.Count(65)<1)
                throw new InvalidOperationException("Forge table could not be crafted.");
            building.Restore(new BuildingState{blocks=new[]{new PlacedBlockRecord{type=13,position=new Vector3(6,.5f,6)}}});
            inventory.Add(68,1);FarmForge.Instance.Restore(0);
            if(!building.HasPlacedForge||FarmForge.Instance==null||!FarmForge.Instance.TryEnhance()||FarmForge.Instance.SwordLevel!=1)
                throw new InvalidOperationException("Sword forge level 1 failed.");
            exploration.Restore(new ExplorationState{seed=exploration.Seed,generatorVersion=2,minedCount=30});
            if(exploration.BlockAt(new Vector3Int(72,6,72))!=0||exploration.BlockAt(new Vector3Int(72,3,72))==0)
                throw new InvalidOperationException("Deep boss cave geometry failed.");
            var caveBoss=CaveBoss.Create(ExplorationWorld.Origin+new Vector3(72.5f,4.05f,72.5f),exploration,player);
            caveBoss.HitRanged(caveBoss.transform.position,CaveBoss.MaxHealth+1);
            if(!exploration.BossDefeated||!exploration.Snapshot().bossDefeated)
                throw new InvalidOperationException("Exploration boss defeat was not persisted.");
            Debug.Log("FARM_FORGE_BOSS_OK: craftable forge, sword enhancement, deep cave and persistent boss reward.");
            yield return FarmNewFeaturesChecks.Run(save,player,hud);
            Debug.Log("FARM_CROPS_SMOKE_OK: grounded, cameras, pause, 80 plots, three crops, dry growth blocked, watering, harvest inventory, replant, screenshot.");
            Application.Quit(0);
        }
        static void Capture(string path, FarmHud hud, Camera camera)
        {
            // Render ra texture để kiểm tra được cả khi cửa sổ Windows bị ẩn.

            var canvas = hud.GetComponent<Canvas>();
            var target = new RenderTexture(1280, 720, 24);
            var previousTarget = camera.targetTexture;
            var previousActive = RenderTexture.active;
            canvas.renderMode = RenderMode.ScreenSpaceCamera;
            canvas.worldCamera = camera;
            canvas.planeDistance = 0.5f;
            Canvas.ForceUpdateCanvases();
            camera.targetTexture = target;
            camera.Render();
            RenderTexture.active = target;
            var snapshot = new Texture2D(1280, 720, TextureFormat.RGB24, false);
            snapshot.ReadPixels(new Rect(0, 0, 1280, 720), 0, 0);
            snapshot.Apply();
            File.WriteAllBytes(path, snapshot.EncodeToPNG());
            camera.targetTexture = previousTarget;
            RenderTexture.active = previousActive;
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            target.Release();
            Destroy(target);
            Destroy(snapshot);
        }
    }
}


