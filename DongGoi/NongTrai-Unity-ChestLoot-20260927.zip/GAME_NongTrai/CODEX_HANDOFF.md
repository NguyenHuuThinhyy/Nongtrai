# Bàn giao cho nhóm qua GitHub Releases — 27/09/2026

Release: https://github.com/NguyenHuuThinhyy/Nongtrai/releases/tag/chestloot-20260927. Có gói Windows chạy ngay, source Unity đầy đủ, RELEASE-MANIFEST.json, SHA256SUMS.txt và HUONG_DAN_NHOM.md. Đọc hướng dẫn này để clone/mở/build ở máy khác; Tools/Build-Windows.ps1 gọi BuildWindowsCurrentScene, không dựng lại scene. Script đã kiểm cú pháp PowerShell; bản runtime dùng build/smoke đã đạt của ChestLoot, không build lại trong lượt upload.

Mã gameplay/assets/config khớp commit build a2507c7. Commit bàn giao chỉ thêm hướng dẫn và công cụ ngoài Assets; manifest ghi riêng build_git_commit và source_git_commit. Git không chứa cache/log/ZIP; các gói tải nằm trong Release. Đã dọn lại Library sinh sau lần build cuối, log cũ và ảnh CombatComfort cũ; giữ log/ảnh kiểm tra ChestLoot, runtime mới và source backups. Library sẽ tự tạo lại khi mở Unity.

## Bản game và lịch sử

# Bản hiện tại — ChestLoot / HThinh.yy — 27/09/2026

Rương bỏ câu đố theo yêu cầu mới nhất. Runtime `Builds/Windows-ChestLoot/NongTrai.exe`; backup `Recovery/Before-ChestLoot-20260927/UnitySource.zip`. Đọc CHOI_GAME.md và BAO_CAO_CHEST_LOOT.md; các quy tắc câu đố rương trong mục lịch sử dưới đây đã bị thay thế.

- FarmStorage xóa quizPanel, nội dung câu hỏi và AnswerQuiz. Open chặn quái canh, sau đó mở Panel trực tiếp. TakeAll dùng Transfer với giới hạn túi; giữ đồ chưa lấy. UI đủ 78 loại, không chồng nút cuối.
- RememberChest đồng bộ mảng đồ/mutated/unlocked sau chuyển đồ, Snapshot và trước khi unload. Restore đóng panel và bỏ tham chiếu rương cũ. BreakExploration bỏ kiểm tra unlocked, rơi đồ còn lại + item36, chặn gọi lặp sau SetActive(false). ChestBroken đánh dấu key đã phá và đóng panel nếu đang xem.
- Save21 giữ tương thích unlocked cũ; quái canh, thưởng boss/hạt và các câu hỏi ngoài rương giữ nguyên. BuildSmokeCheck, FarmAdventureFeedbackChecks, FarmSystemsChecks chuyển sang kiểm mở trực tiếp, lấy một/tất cả, phá chưa mở, không thả trùng, lưu/tải và rời vùng không nhân đồ.

Build Windows OK100987215/169 file; full smoke/art exit0 tại Logs/smoke-chest-loot-final.log; startup responsive8s không exception. Đã xem ảnh bảng rương; scene hash không đổi. Chi tiết BAO_CAO_CHEST_LOOT.md.

## Lịch sử trước ChestLoot

# Bản hiện tại — CombatComfort / HThinh.yy — 27/09/2026

Runtime `Builds/Windows-CombatComfort/NongTrai.exe`; source backup `Recovery/Before-CombatComfort-20260927/UnitySource.zip`. Không chạy CreateScene, scene hash không đổi. Xem BAO_CAO_COMBAT_COMFORT.md và CHOI_GAME.md trước các mục lịch sử bên dưới.

- AdventureWolves ghi deathPosition khi chết; trả 100 xu Teleport đúng vị trí đó, giữ đồ. Miễn phí vẫn về FarmTravelPortal.Arrival/FarmArrival. UI nói rõ hai lựa chọn.
- FarmSponge hong 10 giây khi CampfireCooker.HasHeat trong 2 m và không bị tường che. Type16→15 và property block đổi sang màu khô; thu lại được item72. Timer hong khối đặt gần lửa không lưu, tải lại bắt đầu 10 giây mới. CampfireCooker nhận item73→72 qua chuột phải, 10 giây; dùng trường cooking/cookRemaining/cookedOutput hiện có để lưu. Không đổi save21.
- FarmSwordAim dùng OverlapSphereNonAlloc, kiểm góc chung với FarmSwordAim.ViewportRadius (.055, đường kính 11% chiều cao); LOS cả camera/người chơi; tầm cũ 6/7 m, một mục tiêu mỗi đòn, cooldown/durability giữ nguyên. Vòng mesh UI không texture, hiện khi item106, giữa trong suốt, vàng khi có mục tiêu. ExplorationWorld gọi helper trước ray đào.
- FarmSystemsChecks bổ sung trả tiền tại chỗ/cả hai map/thiếu tiền, hong bọt biển và lưu trạng thái, kiếm lệch tâm/tường/tầm/hồi chiêu/UI. Build final Logs/build-combat-comfort-package.log OK100987695; full smoke/art Logs/smoke-combat-comfort-package.log exit0; startup responsive8s không exception. Đã xem ảnh vòng kiếm mới.
- Dọn thành công cache Library, log và runtime/ZIP Windows cũ (~3,70 GiB, gồm runtime Systems cũ; giữ ZIP dự phòng). Lệnh xóa dùng đường dẫn đã kiểm và không cưỡng chế file đang dùng. Các ghi chú bị chặn dọn ở lượt trước bên dưới là lịch sử, không còn phản ánh kết quả lượt này. Giữ source backup và giấy phép. Git đồng bộ cả source, meta, docs; không push cache/build/ZIP.

## Lịch sử trước CombatComfort

# Bản hiện tại — Systems / HThinh.yy — 27/09/2026

## Đồng bộ Git và dọn file — 27/09/2026

Source Systems đã push lên `main` tại commit `6139748`. Đối chiếu sau bàn giao: 567 file trong Assets/Packages/ProjectSettings khớp từng byte giữa dự án live và mirror Git. Bổ sung `.gitignore` cho cache IDE, captures và thư mục debug Unity. Không sửa gameplay/scene trong lượt dọn này, không chạy lại build/smoke.

Đã rà soát Library (~1,89 GB), log cũ và 6 thư mục runtime cũ trong Recovery. Lệnh xóa bị kiểm duyệt công cụ chặn (`blocked by policy`), kể cả khi thu hẹp chỉ Library; chưa xóa các mục này. Giữ bản game đang chạy, ZIP bàn giao, source backup, meta và giấy phép. Baseline hash nằm tại `Recovery/Cleanup-20260927/source-sha256-before.json` (chỉ ở máy bàn giao).

Live D:/GAME_NongTrai, mirror Git Nongtrai, branch main/origin https://github.com/NguyenHuuThinhyy/Nongtrai.git. Người dùng đã yêu cầu cập nhật Git đầy đủ cho nhóm: commit/push source đã kiểm tra, không chỉ giữ working changes như các bản trước. Runtime Builds/Windows-Systems/NongTrai.exe. Backup Recovery/Before-Systems-20260927-215005/UnitySource.zip và GitMirror-before-sync.zip. Không chạy CreateScene; SHA256 scene trùng backup.

## Dữ liệu / thay đổi

- Save21, đọc v2–20; ItemCount78, crafting25. Item64/71 để dành đọc dữ liệu cũ, không còn recipe hay loot phát sinh trong chơi thường. Item105 là xô duy nhất. PlayerInteraction.Update gọi TryWaterCanInteraction cho TRÁI trước tưới/đào; Explore.Update bỏ mining item105. Rỗng mới ScoopCan, đầy mới PourCan, EmptyBucket không tự lấy bình dự phòng. HeldItemVisual dựng xô có mặt nước đầy/rỗng, chỉ rebuild khi trạng thái đổi. Giữ API bơm/bình cũ cho tương thích/test cũ, UI chơi thường chỉ có xô và thuê vòi.
- MigrateBuckets(v<21): quét products, warehouse/explored chests, placed chests, drops; bỏ64/71, hoàn28/12xu, dọn bag proxy, có bình cũ thì giữ/cấp105 nếu có ô; còn nước thì đầy, bỏ spareCans. Không đụng thuốc máu67. Không reset seed/map/level.
- 72/73 bọt biển khô/đầy, building types15/16. Shop offer40 giá80xu, unlimited. FarmSponge.Absorb chỉ một lần, 3×3×3 ô quanh tâm; nguồn trong vùng bị xóa, dòng của nguồn đó rút. dryCells/farmDryCells lưu vùng đã hút để nước tự nhiên không lập tức đổ lại; đặt nguồn mới gần đó xóa dấu khô trong8ô. Type16 lưu trong BuildingState, phải thu vào túi, bán được. Mesh/material theo khối tái dùng; không tạo mỗi frame.
- Seed proxy100–103 Sync theo stock thực, hết thì nhả ô; mua lại tự Insert. SellInspected bán được hạt/feed và mọi dụng cụ. SellEverything bán stock thật trước (kể cả >36stack), hàng hóa, rồi dụng cụ; không tái sinh công cụ. Shop offer41 xô50xu, bán25xu, không cho mua xô thứ hai. Còn mua xẻng/kiếm/rìu như cũ.
- Vòi56 thuê350xu, hoạt động1080 giây game kể từ đặt; GameSeconds dùng Day+NormalizedTime nên ngủ qua ngày tính hạn. 3lượt/ngày, LV3/5/7 mở4/5/6. rentedToday+lastPortablePurchaseDay lưu. Bấm phải thu sớm kết thúc thuê, không hoànvoucher/lượt. Tự tưới6m, không Consume; trạm cũ cũng tự tưới. Nước đặt sát luống làm ẩm. UI nâng bình cũ bỏ vì xô chỉ đầy/rỗng.
- 74/75 hạt bí pha lê/dâu hoàng kim; 76/77 sản phẩm240/360xu. FarmSpecialCrops.Install(FieldManager.Awake) clone crop3/4 thành index6/7,240/300giây, yield3; specialProduct ánh xạ inventory. Không mutation ngẫu nhiên cho2giống này để giữ phân loại sản phẩm. Rương boss:2hạt74+1hạt75; khôngshop/recipe. DefeatBoss/DefeatSurfaceBoss tạo boss:cave/boss:surface, FarmStorage lưu/stream rương theo vị trí; quiz đúng thả/sai xóa. Rươngguardtier4 cũng thêmhạt, specialLoot tránh nhân bản khi migrate.
- FarmEnemyJump probe phía trước, giới hạn cao1.2m, kiểm khoảng đầu, impulse8.5/cooldown.9s. Dùng choCaveBoss/FarmChestGuard/DayPredator/NightWolf; CharacterController.Move vẫn chặn va chạm. FarmEnemyHealthBar chung, tên+HP/max, 35m; ẩn thanh nhỏ cũ. HUD máu người lớn hơn; RestoreHealth tắt deathPanel cũ khi tải save.
- Góc phải dưới © HThinh.yy, header mã mới, COPYRIGHT.md ghi sở hữu phần gốc và giữ nguyên giấy phép asset bên thứ ba. Không tải model/texture mới, nhiều visual còn primitive như bản trước.

## Kiểm tra / bàn giao

Build Logs/build-systems-final.log FARM_M1_BUILD_OK100978671,169file runtime. Bộ riêng FarmSystemsChecks -farmSystemsOnly đã qua; gồm seed0/rebuy/sellall, sponge/full/save, thuê/level/reset/expire, bosschest/plant/harvest, boss thực sự nhảy1block, HP, migratebottles. FarmWaterCanChecks đổi input thật sang trái; các smoke cũ cập nhật seedslots/craft25/save21. Lượt full trước Logs/smoke-systems-release.log exit0; lượt cuối sau kiểm stock5000hạt Logs/smoke-systems-final.log exit0. Startup Logs/startup-systems-final.log responsive8s, không Exception/Error. Đã xem ảnh HP/copyright trong game. Trạng thái bàn giao cuối được ghi trong BAO_CAO_SYSTEMS.md và DongGoi/RELEASE-MANIFEST.json.

Git chỉ source Assets/Packages/ProjectSettings + meta/docs/license. Không Library/Temp/Logs/Builds/DongGoi/Recovery. Không dùng force push. README hướng dẫn clone/open/build, CHOI_GAME đã đổi điều khiển nước.

## Lịch sử trước Systems (quy tắc cũ về nước/vòi đã được thay)

# Bản hiện tại — Bình tưới múc/đổ nước 27/09/2026

Runtime `Builds/Windows-WaterCan/NongTrai.exe`. Backup `Recovery/Before-WaterCan-20260927-144955/UnitySource.zip`; mirror backup cùng thư mục. Không dựng lại scene, SHA256 Farm.unity trùng backup. Bản TNT cũ chuyển vào OldRelease trong backup.

Item105 (bình tưới mặc định, ô6): PlayerInteraction.TryWaterCanInteraction được gọi cho chuột phải trước fallback ScanNearest. RayWater ưu tiên nước, tầm24m từ camera/6m từ người và chặn bởi collider. Múc nước nạp CanCapacity, không cần item64/71 và không trừ PumpStock. Đổ chỉ nhận địa hình/khối xây, thành công mới Consume toàn bộ CanWater hiện tại; dự phòng tự nạp theo luật cũ. Bấm trái trên cây giữ nguyên. Múc nguồn đã đặt xóa nguồn rồi dựng lại dòng; nước tự nhiên là nguồn vô hạn.

FarmVoxelWater.ScoopCan/PourCan dùng nguồn voxel cũ ở Khám phá. FarmSurfaceWater thêm lưới giới hạn ở nông trại, đọc bounds từ Pond surface - decorative/Pond bottom của scene; chặn dòng bằng collider, tối đa64nguồn/7ô ngang/12000 bước dựng lại, mesh/material dùng chung không collider nước. Không thay khối đất. Nguồn trên đất nông trại lưu trong VoxelWaterState.farmSources (trường tùy chọn, giữ save20); pendingFarmSources giữ dữ liệu nếu auto-load trước Start. Vật phẩm bình rỗng71/bình dự trữ64 vẫn đọc/dùng như cũ.

FarmWaterCanChecks: -farmSmokeCheck -farmWaterCanOnly, cũng chạy full suite trước creative. Test múc hồ/sông không bình phụ, input phải thật múc và đổ, lan nước, che tia ray/nhắm sai không mất nước, múc nguồn lại, save/load cả2map, trái tưới cây. HUD/tutorial nêu rõ ô6 và chuột phải.

Build Logs/build-water-can-release.log: FARM_M1_BUILD_OK100958875. Full smoke/art Logs/smoke-water-can-release.log exit0, FARM_WATER_CAN_OK/FARM_TNT_OK và các checkpoint cũ. Startup Logs/startup-water-can-release.log phản hồi sau8s, không Exception/Error. Đã xem water-can-flow-preview.png. Báo cáo BAO_CAO_NUOC.md, gói/manifest trong DongGoi. Git mirror giữ working changes; không commit/push. Không tải asset mới.

## Lịch sử trước bản WaterCan

# Bản hiện tại — TNT châm bằng đuốc 27/09/2026

Backup Recovery/Before-TNT-20260927-142343/UnitySource.zip. Save20, đọc v2–19; thêm TntRecord[] tnt. Không thay scene, không chạy CreateScene. Runtime mới Builds/Windows-TNT, build bằng FARM_BUILD_OUTPUT.

FarmTnt tách khỏi ExplorationLandmarks sang FarmTnt.cs. Item69: PlayerInteraction xử lý trái/phải trước xây dựng/đào; ray24m, reach6m từ người, chỉ địa hình/PlacedBlock map Khám phá, CheckBox tránh vật khác/người; chỉ trừ TNT sau xác nhận vị trí. Item29 đuốc: trái/phải lên TNT → Ignite, không trừ đuốc. FarmBuildingSystem bỏ preview/đặt khi đang ngắm TNT với đuốc (không lệ thuộc thứ tự Update). Mining bỏ qua item69.

Ngòi phase0..9, mỗi pha .5s: chẵn sáng, lẻ tắt; năm nhịp hoàn chỉnh rồi nổ phase10. Frame khựng chỉ chuyển một pha để không bỏ nháy. Châm lặp không reset. Tạm dừng khi pause/ngoài Khám phá. Save lưu vị trí, ignited, phase, remaining; World.Restore ClearAll, Save.Load restore TNT sau world/building; không tự châm TNT mới. Blast giữ bán kính/loot/sát thương25 cũ, tầng đáy/cổng bảo vệ vẫn do MineCell kiểm.

FarmTntChecks: -farmSmokeCheck -farmTntOnly; cũng nằm trong full suite trước creative. Kiểm không tự nổ, đuốc đúng, không trừ/đặt đuốc, 5 nháy/long frame, pause, save/load unlit và lit, blast, invalid placement, input chuột trái thật.

Build Logs/build-tnt-release.log OK100947275. Full smoke/art Logs/smoke-tnt-release.log exit0, không exceptions, bao gồm input trái thật châm TNT. Startup Logs/startup-tnt-release.log responsive8s. Runtime169files/100947275bytes. Chi tiết: BAO_CAO_TNT.md.

## Lịch sử trước sửa TNT

# Bản hiện tại — AdventureFeedback 27/09/2026

Live D:/GAME_NongTrai; mirror D:/GAME_NongTrai/Nongtrai. Backup Recovery/Before-AdventureFeedback-20260927-135229/UnitySource.zip. Không chạy CreateScene. BuildWindowsCurrentScene nhận env FARM_BUILD_OUTPUT; bản này ở Builds/Windows-AdventureFeedback, không ghi đè scene.

Save19 / ItemCount72 / JSON27 / generator5 cho map mới. Item71 bình rỗng; múc 71→64, đổ/tiếp bình tưới 64→71. FarmVoxelWater dùng cùng flood fill cho mép sông đào trống và nguồn đổ, giới hạn reach7, tối đa64 nguồn; mesh riêng ở world. RayWater truy vấn nước trước terrain, không thêm collider rắn cho mặt nước. IsSubmerged đọc wet, SurfaceAt đọc cột nước. Space thoát nước bằng xung nhảy. WildWaterDistance cache tối đa65536 cột, seed tạo hồ/nhánh sông ngoài vùng landmark; giữ gen cũ khi load save để tránh đổi địa hình đã chơi.

Walk6/run9, IsSprinting dựa vận tốc thực, HungerRate .03/.12. Pitch[-65,90], shoulder offset về0 khi nhìn xuống; FarmAim và reticle tại viewport .5/.5. Placement bỏ vòng cấm1.25m nhưng vẫn CheckBox va chạm thật. FarmerAnimation procedural Work/Attack/Place + shared trail; giữ hat/head, root clamp và palm socket (.25,0,.0285). FarmActionFeedback dùng1 emitter tối đa256particles, shared material. CanReach kiểm độ cao và ray vật cản để chặn cắn xuyên tầng/vách.

FarmPlayer.TryAttack cooldown .3*(1-haste%). BagSlot chứa forgeLevel/bonusDamage/criticalChance/haste và Copy sao đầy đủ; Forge Levels chỉ là API tương thích. Save<19 migrate levels sau Bag.Restore; v19 không ghi đè chỉ số riêng. WorldPickup/PickupRecord lưu BagSlot khi rơi vũ khí do chết. Roll1đá+80xu: ST1..12, crit3..18, haste0..20; critx1.5, cung haste làm kéo nhanh. SwordLV5 +12ST vàHeal3/hit. UI36ô kéo/bấm giữ nguyên; bán/bỏ kiếm/rìu/cung trong túi.

LootChestRecord guardTier/guardDefeated, FarmChest sở hữu guard và hủy cùng chest, không để attacker mồ côi khi unload. Spawn1/24 chunk,max2 gần player; tier1 sói160HP, tier2 rắn220HP, tier3 gấu420HP, tier4 golem1400HP. Quái canh đánh10/12/24/40, báo trước. Bậc cao đá/kim loại/máu/tên/nước nhiều hơn. Save lưu trạng thái hạ quái; câu đố vẫn đúng thả đồ/sai mất rương. Các visual quái canh là mesh primitive tự dựng, không asset tải mới.

CreativeModeManager nút Chơi lại từ đầu xác nhận rồi ArchiveForNewGame (di chuyển .bak/.tmp trước, active save cuối), SceneManager.LoadScene, bắt đầu LV1; Cancel không thay đổi. Mở EXE thông thường vẫn Load manual save. Luật đổi map/respawn giữ nguyên.

Kiểm thử: FarmAdventureFeedbackChecks có flag -farmFeedbackOnly (đi cùng -farmSmokeCheck). Full suite chạy feedback trước khi chuyển sang creative, vì Save bị khóa trong creative. Test dùng temporaryCachePath, không ghi save người dùng. Báo cáo và kết quả cuối: BAO_CAO_ADVENTURE_FEEDBACK.md.

Build release Logs/build-feedback-release.log OK100936715. Full smoke+art Logs/smoke-feedback-release.log exit0, không exceptions. Startup Logs/startup-feedback-release.log alive/responding8s. Runtime169files/100936715bytes. Gói AdventureFeedback-20260927 + manifest trong DongGoi. Scene SHA256 không đổi so với backup. Không tải asset mới; giữ giấy phép CC0.

## Lịch sử các bản trước — thông tin sau đây có thể đã cũ

# Bản hiện tại — Polish / sửa nhớ vị trí đổi map 27/09/2026

Live D:/GAME_NongTrai; Git mirror D:/GAME_NongTrai/Nongtrai. Backup Recovery/Before-Polish-20260927/UnitySource.zip + GitMirror-before-sync.zip. Không chạy CreateScene. BuildWindowsCurrentScene build hiện trạng; UpgradeFarmerInScene chỉ thay visual.

Người dùng sửa lại “thêm tóc” thành tốc chạy. Cuối cùng giữ tóc gốc; runSpeed9, walkSpeed4, gia tốc28/hãm34. Hat child head. Generic arm palm (.25,0,.0285) theo source rig +X; FarmerAnimation.UpdateSocket chạy SAU chỉnh xương, gripRotation hiệu chỉnh từ idle, không dùng +90 Z cũ (chĩa vũ khí dọc cẳng tay). Clamp rigRoot local position để không nhân đôi nhảy. HeldItemVisual cache material, tắt collider ngay.

Save18 / ItemCount71 / JSON26 / generator4. Item70=portal, buildingtype14. FarmTravelPortal.Active tách cổng gốc; Arrival tìm lối đi phía trước/sau, fallback cổng gốc khi thiếu/bị chặn. Theo đính chính: chỉ chết hồi sinh mới dùng cổng. Travel giữ farmPosition/explorePosition như cũ, kể cả khi chưa đặt cổng. Lưu cổng bằng BuildingState. FarmPlayer.IslandSafePoint chỉ trả marker cổng gốc, không gọi Arrival lúc teleport (tránh nạp thêm chunk quanh cổng khi điểm đến ở xa). Save cũ giữ seed/edits, migrate gen4.

FarmVoxelWater sinh sông tây(-36,0), biển nam(0,-75), world mesh không parent Canvas; thêm 4 quad chân trời ngoài vùng tương tác. Player bơi/nổi cơ bản Space ngoi. Quặng1/83, than1/61. BossHP2400, damage38/52, windup.7/.5, enraged nửa máu.

CreativeModeManager.ReturnToMainMenu nay chỉ mở xác nhận. ConfirmRestart(true) Save thành công mới reload; false bỏ phần chưa lưu có cảnh báo; CancelRestart giữ tiến độ. UI “Chơi game lại”. FarmForge có lưới36ô+2đích click/drop, chỉ chọn tham chiếu; không trừ trước, không tạo bản sao inventory.

Runner dùng substeps1/60, HUD10Hz, 5 difficulty tiers, 10–26m/s, 6segment/40m pool, 1–3 hàng, đổi safe lane mỗi hàng, xe tràn từ lề sau500m (dừng dịch khi còn26m). Clamp dt chỉ >.5s. Không cam kết FPS mọi máy.

Đã build Logs/build-travel-fix-final.log: FARM_M1_BUILD_OK100909789. Toàn bộ smoke Logs/smoke-travel-fix-final.log exit0. FarmPolishChecks dùng farm-polish-smoke-save.json ở temporaryCachePath; kiểmLV4, tốc9m/s, hat/socket, nước/ore, portal fullsave+respawn, forge click/drop. Runner test frame200ms/250ms đổi làn và2050m. Startup thường8s responsive, không exceptions. Báo cáo BAO_CAO_POLISH.md, hướng dẫn CHOI_GAME.md, gói/manifest trong DongGoi. Asset licenses CC0 giữ nguyên, không tải mới. Nhiều công trình/dụng cụ/predators/Golem vẫn primitive, NPC chưa có.

## Lịch sử trước bản Polish (có thông tin đã cũ)

# Trạng thái đang bàn giao — cập nhật 27/09/2026

Nguồn Unity thật: `D:\GAME_NongTrai`; Git mirror: `D:\GAME_NongTrai\Nongtrai`. Không chạy CreateScene. Backup trước cập nhật: `Recovery/Before-Runner-20260927/UnitySource.zip`.

## Bản phát hành đã kiểm tra

Build `Logs/build-runner-final.log`: FARM_M1_BUILD_OK 100885906. Smoke `Logs/smoke-runner-final.log`: exit0, cả legacy và test mới, Runner đi2050m/quà2km, boss đánh trong vùng. Startup thường phản hồi sau8s. Đã kiểm ảnh hồ có nước; mặt nước phải là world GameObject độc lập, tuyệt đối không parent vào Canvas. Chi tiết: BAO_CAO_FARM_RUNNER.md. Nhân vật hiện là **Kenney e1,90m**, yếm xanh/áo kem/mũ rơm/da sáng; các mẫu a/b/c/d/f và SurvivalKit không dùng đã chuyển Recovery sau GUID audit. Source mirror sẽ giữ working changes, không push tự động.

## Thay đổi mới

FarmRunner.cs tạo scene runtime riêng với full-screen camera, pause farm, pool 6 đoạn, input A/D/W/Space/S, vé hồi theo UTC, tiền chung, quà mốc. Tab gọi Runner; FarmDeliveryRush cũ giữ source/dữ liệu migration nhưng không còn là mục Tab. Hộp thư vẫn giao đơn và tặng vé. Demo chưa có skin/cánh/đổi giới tính.

FarmConsumption: giữ trái đủ3s mới ăn, cancel khi đổi/thả; bình máu67. FarmerRunEffects bụi chân; FarmerAnimation dùng góc gốc để tránh tích lũy xoay xương.

ItemCount70: 63 tên,64 nước,65 bàn rèn,66 than,67 bình máu,68 đá nâng cấp,69 TNT. JSON25 công thức. Forge sửa lỗi colors[13] vượt mảng, tách mở bàn khỏi mining, chọn106/111/107 + đá68. Save17 lưu weaponLevels,runner,voxelWater,machineFuel,preferredFuel. Legacy v2–16 đọc được; generator3 tạo hồ/đấu trường/làng/hố sâu ở vùng cố định, giữ excavated/additions.

FarmVoxelWater: nguồn + mesh chung; rơi/lan7ô; block placement displacement; giới hạn64nguồn người chơi. Không bơi/áp lực nước. ExplorationLandmarks: làng/tế đàn bằng geometry Unity, boss home/leash. Than block9 trong tầng đá; lò bánh/nung gỗ30s,than120s. Arrow ghim/follow transform và thu hồi trong3phút (chưa lưu riêng tên đang ghim).

FarmStorage clone mảng rương, khóa chuyển đồ khi bảng đóng/rương đã mất, mở phải nhắm rương. Không alias save snapshots. Building.Restore tắt object cũ trước Destroy để không còn collider trong cùng frame.

Smoke mới: FarmNewFeaturesChecks; toàn bộ BuildSmokeCheck và FarmVisualChecks vẫn chạy bằng `-farmSmokeCheck -farmArtCheck`, dùng save tạm, không đụng save người chơi. Kết quả cuối ghi ở báo cáo bản phát hành; không suy ra pass chỉ từ mô tả này.

## Ghi chú lịch sử bên dưới

Các đường dẫn build, số version, NEXT TASK và lỗi trong phần lịch sử có thể đã cũ. Ưu tiên mã hiện tại và phần cập nhật này. Build scene hiện tại bằng `NongTrai.Editor.FarmProjectBuilder.BuildWindowsCurrentScene`.

---

# CẬP NHẬT HÌNH ẢNH VÀ DI CHUYỂN — 25/09/2026

- Scene và `FarmProjectBuilder` hiện dùng Kenney Mini Characters `character-male-a.fbx` CC0. Builder đã bỏ đường dẫn Quaternius người cũ để tránh lần dựng sau ghi đè model mới. Bò/heo/cừu dùng Quaternius FBX, gà OBJ; cây Kenney Nature Kit. File cũ không còn tham chiếu đã chuyển vào `Recovery/ArtRepair-20260925/UnusedAssets`; bản sao source trước sửa ở `Recovery/ArtRepair-20260925/before-repair.zip`.
- Di chuyển nhân vật được tăng/giảm tốc, vật nuôi dùng Rigidbody interpolation và dừng ngay khi pause. Rơi cao gây mất máu; cáo/rắn/sói lùi sau cắn. Lúa mì vàng ấm, bụi việt quất xanh lá, icon quả nổi trên tán đã bỏ; ánh sáng và sương map khám phá điều chỉnh để dễ nhìn. `BuildSmokeCheck` kiểm tra rơi cao và câu đố rương; `FarmVisualChecks` chụp ảnh và kiểm tra model/vật liệu khi chạy cùng `-farmSmokeCheck -farmArtCheck`.
- Rương khám phá có câu hỏi mở khóa; trạng thái `LootChestRecord.unlocked` lưu cùng storage hiện tại, bản lưu cũ đọc được với mặc định khóa. Các yêu cầu trong bản đính kèm về cung giữ-thả, hang sâu rộng, minigame giao hàng năm màn và cường hóa kiếm chưa được triển khai; cần làm theo từng hệ thống và kiểm tra riêng, không gộp với dữ liệu save v15 nếu chưa có migration.

# CẬP NHẬT ƯU TIÊN — 25/09/2026: BẢN v15

Ưu tiên code hiện tại, `README.md` và `CHOI_GAME.md` trước các ghi chú v14 trở xuống.

- Save schema v15 đọc v2–v14. `FarmWaterSystem` lưu nước trong bình đang dùng, tối đa hai bình dự trữ (ba bình mang theo), nước máy bơm và tiến độ hút nước. Bơm tạo một bình sau mỗi 600 giây chơi, có thể giữ tối đa ba bình. Click máy bơm lấy nước; bảng quản lý cạnh máy mở menu mua vòi. Bình tưới trên hotbar hiển thị số nước thay vì độ bền.
- Bơm và trạm tưới có hạt nước xanh nhìn thấy trong game. Nhân vật đã chỉnh tỷ lệ thân, tay và chân nhưng vẫn là model Unity dựng bằng primitive, chưa phải nhân vật 3D rig chuyên nghiệp. HUD đã chuyển gợi ý E/Tab/B về bên trái, tránh giữa màn hình.
- Sửa tiếp vùng tưới: vòng bán kính 6m là dải phẳng mảnh sát mặt ruộng, không còn thanh tia thẳng hay vòng dày nổi. Khi trạm/vòi hoạt động, 96 giọt nước xanh bay từ tay quay xuống mặt đất và 24 điểm bắn tóe xuất hiện nơi nước rơi. Smoke kiểm tra vòng, particle và giọt đang hoạt động; `Builds/Windows/irrigation-preview.png` và `irrigation-eye-preview.png` là ảnh kiểm tra trực quan.
- Cáo/rắn ban ngày có thanh máu trên đầu, mở rộng góc phát hiện; đòn cắn gây sát thương và đẩy người chơi nhẹ, sau đó lùi lại. Khi độ no trên 70, người chơi hồi 2 máu mỗi 5 giây chơi. Smoke test v15 gồm nước bơm, sức chứa bình, hồi máu, thanh máu quái và chuyển bản lưu cũ. Chỉ lưu thủ công, chế độ sáng tạo không ghi file lưu.

---

# CẬP NHẬT CŨ — 24/09/2026: BẢN v14 ĐÃ KIỂM TRA

Đây là ghi chú ưu tiên mới nhất; các mục v13 và cũ hơn bên dưới là lịch sử. Khi có mâu thuẫn, kiểm tra source và `README.md` trước.

- Save schema v14 đọc v2–v13, thêm nhiệm vụ bản đồ tuần tự, giới hạn mua mỗi ngày và các mã hàng 56–62 (vòi phun, thịt bò/cừu/gà sống/chín). Unity 6000.3.22f1 đã build Windows thành công trong `Logs/build-v14-release.log`; smoke 1280×720 thoát 0 trong `Logs/smoke-v14-release.log`, kết thúc `FARM_V14_OK` và `FARM_CROPS_SMOKE_OK`.
- Shop còn bốn trang, không bán khối xây hay thức ăn thú; hạt ruộng và cây giống mua không giới hạn, các món còn lại 1 lần/ngày. Đồng hồ ngày chạy khi đang mở shop để đếm ngược tiếp tục. Bảng chuồng dẫn sang cối xay để chế biến thức ăn theo loài. Phím G mở xây dựng đã bỏ; dùng B → Xây dựng. Lăn chuột đổi hotbar nhạy hơn.
- Vòi phun mua tại bơm nước nay vào túi (item 56), chọn trong hotbar rồi click đất để đặt; click phải vào vòi đã đặt để thu về túi nếu còn chỗ. Vườn cây phía đông chỉ cần LV3, không cần vùng đất 4. Túi có chọn số lượng bán bằng +/−/Hết. Hướng dẫn tự ẩn sau 10 giây, H mở lại.
- Khám phá giới hạn sáu thú hoang hoạt động, có bò/heo/cừu/gà và thịt sống theo loài; cừu thêm len. Thịt sống phải nướng tại đống lửa để ăn. Ban ngày có tối đa hai cáo/rắn chỉ tấn công khi nhìn thấy phía trước; đêm sói 160 máu, kiếm thường 7 đòn, lao nhanh và cú cắn có phản hồi đẩy/hiệu ứng. Khối đã đặt và phần thân gỗ phía trên có xử lý rơi khi mất đỡ.
- Nhân vật và dụng cụ được chỉnh lại bằng mesh/primitive dựng trong project; hình dáng hiện vẫn mang phong cách 3D cách điệu, **chưa phải model người thật có rig và animation chuyên nghiệp**. Đây là giới hạn hình ảnh còn lại cần asset/model mới nếu tiếp tục nâng cấp.

---

# CẬP NHẬT CŨ — BẢN v13

Các mục cũ bên dưới là lịch sử và có thể sai về phiên bản lưu, hotbar hoặc tính năng. Khi mâu thuẫn, kiểm tra code trước.

- FarmSave ghi schema v13 và đọc v2–v12. Dữ liệu mới gồm cây/ruộng đột biến, vườn LV3, loài cây ăn quả và bụi, vòi phun di động, chuồng tự đặt, sản phẩm đột biến theo giống, thịt đang nướng, thời lượng mưa, túi/kho/rương, máu/đói và đơn hàng. Công cụ cuốc/cuốc chim bản cũ chuyển thành xẻng. Chỉ nút Lưu game mới ghi bản lưu; sáng tạo LV99 bỏ thay đổi khi thoát.
- Hai map là Nông trại và Khám phá. Bấm E mở bản đồ nhiệm vụ tương tác đúng map; Tab đổi map và nhớ vị trí. Bấm chuột trái hái nông sản/táo không cần liềm; xẻng xới đất/đào, kiếm đánh, rìu chặt cây nhanh, phá khối luôn làm rơi đồ.
- Có 18 công thức JSON tại `Assets/StreamingAssets/crafting.json`, 11 công thức chế biến tại `Assets/StreamingAssets/recipes.json` chạy trên bảy máy gồm máy ủ phân, 56 mã hàng 0–55, cửa hàng năm trang 40 mặt hàng, năm đơn/ngày; đơn đã giao ẩn đến ngày kế tiếp. Kho/rương kéo-thả với túi đồ; lưới kho hiện phân theo mã hàng. Bốn công thức mới tạo thức ăn riêng cho gà/bò/cừu/heo, mỗi chuồng có một máng chung.
- Minimap đã thu nhỏ ở góc phải; thanh máu/đói gọn ở góc trái dưới, góc phải có nút cài đặt và H tròn nhỏ. Các bảng có nút X và đóng bằng ESC/click ngoài; mở bảng mới đóng bảng cũ. Nhân vật có máu/đói ở cả hai map, hai lựa chọn hồi sinh. Vật nuôi sẵn sản phẩm có thể click con hoặc chuồng để thu; thú hoang tái sinh có giới hạn.
- Hạt táo/lê/đào/việt quất mua vào túi; dùng ở vùng vườn LV3+, cây lớn theo giai đoạn và tưới giúp tăng tốc, click trái hái không cần giỏ. Map khám phá không còn cây táo tròn được sinh sẵn hoặc đọc từ save cũ. Mưa dùng vật liệu URP màu xanh. Vòi phun mua tại bơm nước, đặt tự do không cần LV, phủ bán kính 6m, cần nạp một nước để chạy 30 phút chơi.
- Một ngày vẫn 1080 giây/18 phút; mưa/bão tối đa 270 giây thực (6 giờ game). Bản build Windows v13 thành công trong `Logs/build-v13-final.log`; smoke `Logs/smoke-v13-final.log` thoát 0 với `FARM_V13_OK` và `FARM_CROPS_SMOKE_OK`. Xem `README.md` và `CHOI_GAME.md` cho hướng dẫn hiện hành. Các mục bên dưới chỉ là lịch sử, có thể đã lỗi thời.

---
# CẬP NHẬT ƯU TIÊN — SỬA ĐÀO / NHẢY / HƯỚNG DẪN TAB

- ExplorationWorld.UpdateMiningRay dùng mask bỏ layer8 Player và IgnoreTriggers, ray24m từ camera nhưng kiểm tra tầm6m từ player. Sửa ray TPS tự trúng nhân vật và tầm8m tính từ camera cũ quá ngắn. Runtime và smoke dùng chung đường ray/hold .55s; không chỉ test MineCell trực tiếp.
- Bỏ OnGUI của mining, dùng TMP Canvas: tâm ngắm khi khám phá, tiến độ %, hướng dẫn khối quá xa/khu cổng/tầng đáy. FarmHudV2 thêm nhãn/nút Tab đổi map và nhắc Space.
- PlayerSettings jumpHeight tăng .8 ->1.6 trong class lẫn asset. Smoke giả lập Keyboard W+Space qua collider cao1m, kiểm tra vị trí vượt qua và đỉnh nhảy.
- Schema save vẫn v8, không đổi inventory/seed/chunk persistence.

---

# CẬP NHẬT ƯU TIÊN — MAP SINH LIÊN TỤC (v8)

- ExplorationWorld thay mesh cố định bằng Dictionary<Vector2Int,Chunk>, chunk16x16, cao32; radius2 và vùng giữ thêm1. Một chunk bổ sung/frame, đồng bộ3x3 collider khi dịch chuyển. Gỡ mesh/GameObject xa; chỉ giữ seed và HashSet<Vector3Int> các ô đào. Không sinh thế giới mới khi quay lại.
- GeneratorVersion1, seed ngẫu nhiên nếu chưa có; giữ core48x48 phiên bản trước, bên ngoài sinh đồng cỏ/cát/tuyết và hang/quặng bằng seed. Tọa độ âm dùng floor division.
- Map khám phá chuyển lên y1000 để mở rộng bốn hướng không đè farm. Origin=(175.5,996,-24.5), spawn=(200,1000.4,-20). FarmPlayer nhận biết bằng y>500; phục hồi khi dưới990. Tuyệt đối không dùng x>100 để phân biệt map mới; chỉ dùng trong migration cũ.
- FarmSave v8 migrate vị trí player/trees/buildings của map cũ +1000y; decode removed IDs v7 với stride18x48, giữ tiến độ/blueprint. Mọi thay đổi vẫn manual-save, creative không ghi.
- Biome vật liệu mới chưa có ID túi riêng: cát/tuyết/đất cho item25, đá21, quặng13. Không có sinh tồn/quái/multiplayer. Cây táo khởi đầu vẫn sáu cây; không có hệ rừng streaming.
- Test mới: chunk xa/tọa độ âm, cap49 sau stream, seed tái tạo, seed khác tạo terrain khác, đào lưu/tải, v7 cell migration và migration vị trí player. Thông tin hữu hạn48x48 ở các mục cũ phía dưới đã lỗi thời.
- Rủi ro/khoản chưa làm: Unity floating-point ở tọa độ rất xa, build nhiều khối vẫn giữ GameObject độc lập, chưa greedy mesh/job thread. Không quảng cáo vô hạn tuyệt đối hay đảm bảo FPS máy yếu.

---

# CẬP NHẬT ƯU TIÊN — 23/09/2026: CHỈ HAI MAP

Thông tin dưới mục này về bốn đảo, NPC, đấu giá và minigame đã lỗi thời. Ưu tiên code hiện tại và README/CHOI_GAME.

- Yêu cầu mới: nông trại theo hướng Avatar/Stardew/Hay Day và một map khám phá đào/xây khối; bỏ phần đảo dư.
- IslandManager chỉ chấp nhận map 0 (nông trại) và 1 (khám phá), đều mở từ đầu; Tab/cổng. Điểm đến (0,.4,14) và (200,.4,-20).
- FarmIslandsBuilder dựng hai cổng, không dựng Trung tâm/Thần bí/Công nghiệp. Đã xóa MysteryAltar, IslandTrap, IslandNpc, IslandGameKiosk, IslandAuctionKiosk và meta.
- ExplorationWorld tạo mesh/collider voxel hữu hạn 48x48x18, đồi, đá, quặng, hốc ngầm. Giữ chuột trái đào trong tầm 8m khi ngoài chế độ xây; G dùng FarmBuildingSystem hiện có. Bảo vệ tầng đáy và cổng. Đào 30 khối mở bản vẽ lò nung/đèn. Đất -> item25, đá ->21, quặng ->13. Gỗ vẫn cây táo/shop.
- Cả sáu máy trên nông trại; cấp thường tối đa99, bỏ thử thách mở giới hạn cấp.
- FarmSave v7 lưu ExplorationState (removed cell IDs/minedCount); đọc v2..7. Bản cũ hoàn vật liệu công trình x>100, giữ công trình farm; đưa người ở đảo cũ về cổng khám phá. Giữ bản vẽ cũ. IslandState giữ trường cũ chỉ để đọc tương thích/hoàn hàng đấu giá.
- BuildSmokeCheck đã chuyển test đảo cũ sang hai map, đào30, bảo vệ spawn, lưu/tải terrain. Giữ test cây/thú/nước/đơn/creative.
- Chỉ lưu thủ công. Creative LV99 không được ghi file lưu. Không cấp tiền vô hạn.
- Root D:/GAME_NongTrai là dự án Unity, clone Git là thư mục Nongtrai; đồng bộ sau build. Unity6000.3.22f1, lệnh build trong README.
- Giới hạn hiện tại: map hữu hạn, chưa có quái/sinh tồn/multiplayer/thế giới vô hạn. Mesh được dựng lại khi đào (cần chia chunk nếu tăng kích thước). Đánh giá cảm giác chơi dài hạn và các máy yếu cần chơi thử thực tế.

---

# CODEX HANDOFF — Nông Trại / First Harvest

> **CẬP NHẬT 2026-09-25 (bản phản hồi nhân vật/gameplay):** Dự án Unity gốc ở `D:\GAME_NongTrai`, Git mirror ở `Nongtrai`. Trước khi sửa đã lưu `Recovery/Before-Feedback-20260925/UnitySource-before-feedback.zip`. Scene chỉ thay visual nhân vật bằng `FarmProjectBuilder.UpgradeFarmerInScene`; **không** chạy `CreateScene`/`RebuildSceneAndBuildWindows`. Model người chơi là Kenney Mini Characters `character-male-b.fbx` CC0 cao 1,82 m, có mũ rơm và gait tay/chân bổ sung. `HeldItemVisual` sửa lỗi ô trống vẫn vẽ giỏ lớn trước mặt. Rương khám phá đúng rơi đồ và biến mất, sai biến mất không thưởng. Bàn chế tạo có cung, 5 mũi tên, bình nước dự trữ và bàn rèn (22 công thức). `FarmBow` dùng giữ/thả chuột; `FarmDeliveryRush` vào qua Tab, có năm tuyến 3D và save tiến độ; `FarmForge` cường hóa kiếm LV1–5. Hang mới rộng hơn ở vùng tạo mới, hang boss gần ô (72,72) có Golem sau 30 khối đào, thưởng quặng/kim loại/XP. Save schema v16, đọc v2–v15. Smoke/bản Windows cuối cần xem log mới nhất `Logs/build-feedback-final.log`, `Logs/smoke-feedback-final.log` sau khi đóng gói; ảnh art ở `Builds/Windows-3DArt/ArtChecks`.

> **CẬP NHẬT 2026-09-23:** Kế hoạch từng được ghi là “chưa triển khai” trong tài liệu này đã được triển khai sau khi handoff được tạo. Trạng thái đúng hiện nằm trong code: `FarmWaterSystem.cs`, `FarmCraftOrders.cs`, `CreativeModeManager.cs`, bản lưu v5, hotbar bắt buộc, cây 2/3/5 phút, túi 20 món và scene/build mới. README/CHOI_GAME cùng lịch sử Git mới hơn là nguồn chính xác hơn các đoạn trạng thái cũ bên dưới.

Trạng thái được kiểm tra tại `D:\GAME_NongTrai` sau commit `1cc34cc` trên nhánh `main`. Đây là **bản ghi hiện trạng**, không phải xác nhận rằng kế hoạch ở mục 9 đã được triển khai. Đường dẫn tương đối trong tài liệu này tính từ `D:\GAME_NongTrai` trừ khi ghi rõ khác. `D:\GAME_NongTrai\Nongtrai` là bản sao Git riêng; thư mục gốc mới là Unity project đang được build. Trong lần kiểm tra handoff, nội dung `Assets`, `Packages`, `ProjectSettings`, `README.md`, `CHOI_GAME.md`, `prompt.MD` và ảnh tham chiếu ở hai nơi giống nhau; Git clone sạch trước khi tạo tài liệu này.

# 1. PROJECT OVERVIEW

- **Project:** game nông trại 3D chơi đơn cho Windows, tên sản phẩm `Nong Trai - First Harvest`, hãng trong Unity `Nong Trai Studio`.
- **Công nghệ đã xác minh:** Unity `6000.3.22f1`, C#, URP `17.3.0`, Input System `1.20.0`, Cinemachine `3.1.5`, uGUI `2.0.0` và TextMeshPro được cung cấp qua uGUI cùng TMP Essentials trong `Assets/TextMesh Pro`.
- **Mục tiêu lâu dài:** trồng cây, chăn nuôi, thu thập/chế biến, mở vùng đất và đảo, tương tác NPC, có thử thách theo thời gian/mùa. Yêu cầu mới nhất là làm vòng chơi có độ khó hơn, thêm nước, chế tạo, hộp thư đơn hàng và chế độ sáng tạo phục vụ test; **những tính năng mới nhất này chưa được code**.
- **Cách hoạt động hiện tại:** một scene `Assets/Farm/Scenes/Farm.unity` chứa nông trại và ba đảo khác trong cùng world, không phải bốn scene riêng. Người chơi đi/nhảy, tương tác vật gần bằng E, trồng ba cây, nuôi bò/heo/cừu/gà, vận hành máy, đi đảo bằng Tab/cổng và lưu thủ công trong menu Esc. Bản build Windows chạy không cần Unity trên máy đích nếu giữ đủ thư mục build.
- **Nguồn hình ảnh:** `ChatGPT Image Sep 20, 2026, 07_13_45 PM.png` ở root là ảnh tham chiếu; phần lớn model hiện dựng từ Unity primitives. `prompt.MD` là yêu cầu ban đầu, **không** phải đặc tả ưu tiên hơn yêu cầu mới hoặc code đang chạy.

# 2. CURRENT STATE

## Đã hoàn thành và có trong code/build hiện tại

- Trồng lúa mì/cà chua/đậu nành trên 80 ô đất, 4 vùng (20 ô/vùng); cày, gieo, tưới, thu hoạch, giai đoạn cây và sản lượng. Hiện `growthSeconds` là **35/45/55 giây**, 3 sản phẩm/ô; đất khô **ngừng lớn**. Shop bán cả ba gói 5 hạt với cùng giá **10 xu/gói**; cả ba nông sản bán **10 xu/đơn vị**. Đây là trạng thái cũ cần đổi ở mục 9.
- Hotbar 9 ô có chọn bằng phím 1–9/cuộn chuột và viền ô đang chọn. **Chỉ ba ô hạt đầu thực sự đổi hạt đang gieo**; thao tác E ở ruộng hiện chọn cuốc/tưới/liềm theo trạng thái ô đất, không theo hotbar.
- Shop, túi đồ 16 loại hàng (ID 0–15), bán từng loại/bán hết; 4 loài vật có độ no/vui, cho ăn bằng F, sản xuất trứng/sữa/len/thịt; chuồng riêng, cổng mở/đóng, nâng cấp và giới hạn gà 5 con/chuồng. Chuột trái nhấc vật nuôi, chuột phải thả vào đúng chuồng.
- Máy cối xay/lò bánh/thùng ủ/máy ép/xưởng cưa/lò nung; 6 công thức trong JSON, hàng đợi tối đa 5 lượt trên mỗi máy, nguyên liệu trừ khi xếp việc; lò nung cần bản vẽ từ Đảo Thần Bí.
- Mua thêm vùng đất theo LV/xu, nâng cuốc/bình tưới/liềm theo ba bậc với số ô xử lý 1/3/5; nhạc/âm thanh hành động, hạt khi thu hoạch, số nổi khi bán, menu chính/tạm dừng/cài đặt âm lượng.
- Đồng hồ 1 ngày game = 600 giây đời thực, bốn mùa × 28 ngày, năm, nắng/mưa/sương mù/bão, đổi ánh sáng và màu cỏ/lá. Mưa/bão tự tăng ẩm ô đất. Có câu đố 25 giây khi bão: đúng tránh thiệt hại, sai/hết giờ làm mất 30–80% sản phẩm và trì hoãn máy. Ngủ tại giường từ 18:00 đến trước 06:00 để sang sáng.
- HUD Canvas Scaler tham chiếu 1920×1080, TMP cho HUD/hotbar/túi đồ, một số panel khác còn dùng uGUI `Text`; quét tương tác gần qua `Physics.OverlapSphereNonAlloc`, gợi ý TextMeshPro trong thế giới, viền chọn. Không còn tâm ngắm dấu cộng cố định.
- Bốn đảo trong cùng scene: Nông Trại, Trung Tâm (NPC kết bạn qua trò chuyện, chợ đấu giá NPC mô phỏng chơi đơn, minigame), Thần Bí (mê cung/bẫy/di tích mở level cap 5→10 và bản vẽ), Công Nghiệp (tài nguyên và máy). Du hành Đảo Thần Bí cần LV3, Công Nghiệp cần LV4.
- Bản lưu JSON v4 chỉ ghi khi người chơi bấm **Lưu game**. Thoát không tự lưu; khởi động tải bản lưu nếu có. Loader đọc v2/v3/v4. Trạng thái gồm tiền, hạt, nông sản, vật nuôi/chuồng, tiến độ đất/dụng cụ, máy, thời gian/thời tiết, đảo, vị trí và tài nguyên.
- Bản Windows hiện tại và hai ZIP mới nhất trong `DongGoi` là gói **Islands**. Các ZIP cũ hơn trong cùng thư mục là bản cũ, không đại diện trạng thái hiện tại.

## Đang làm / chưa làm

- Yêu cầu triển khai cuối cùng đã được chốt thành kế hoạch nhưng lượt thi hành vừa bắt đầu thì bị ngắt **trước mọi chỉnh sửa code**. Không có `WaterSystem`, trạm tưới, bàn chế tạo, hộp thư, đơn hàng mới, mở công thức bằng đơn, chế độ sáng tạo, bay hay vật lý di chuyển mới trong code hiện tại.
- Thư mục gốc chỉ đang được thêm tài liệu handoff này; **không** coi tài liệu là triển khai tính năng.

## Hoạt động ổn định đã quan sát

- Build gần nhất ghi `FARM_M1_BUILD_OK` trong `Logs/build-release.log`.
- Smoke build Windows gần nhất ghi đủ bảy mốc `FARM_INVENTORY_ANIMALS_OK`, `FARM_SAVE_OK`, `FARM_SHOP_GATE_OK`, `FARM_ANIMALS_SIGNS_OK`, `FARM_EXPANSION_OK`, `FARM_ISLANDS_TIME_OK`, `FARM_CROPS_SMOKE_OK` trong `Logs/smoke-release.log`, không có dòng `Exception`, `not found` hoặc `Error` trong lần lọc cuối. Đây là kết quả test tự động hiện có, **không** xác nhận mọi ca người chơi hoặc các tính năng mới.
- Ảnh smoke 1280×720 cho thấy nhãn chữ khổng lồ và biển chữ ngược từng báo trước đó không còn tái hiện. Khả năng hiển thị ở mọi độ phân giải khác: **CHƯA XÁC MINH**.

# 3. ARCHITECTURE

- **Entry point runtime:** Unity mở `Assets/Farm/Scenes/Farm.unity`. `FarmProjectBuilder.CreateScene()` dựng lại scene, `BuildWindows()` gọi nó rồi build Windows Development. Scene có `FarmPlayer` + `FarmInput` + `FarmCamera`, `FieldManager`, Canvas `FarmHud` và các component hệ thống gắn với Canvas bởi `FarmShopBuilder.BuildShop()`.
- **Wiring:** `FarmProjectBuilder.BuildPlayer()` tạo player/camera/field; `BuildHud()` tạo Canvas/menu rồi `BuildShop()` gắn `FarmShop`, `FarmInventory`, `FarmSave`, `FarmExpansion`, `TimeManager`, `FarmProcessing`, `DisasterPuzzleManager`, `FarmBarnMenu`, `FarmHudV2`, `IslandManager`; component audio tạo riêng. Nhiều hệ thống lấy singleton `Instance`, một số tham chiếu được gán trực tiếp trong builder.
- **Đầu vào & tương tác:** `FarmInput` khai báo WASD, mouse look, Shift, Space, V, E, Esc. `FarmPlayer` dùng `CharacterController.Move` mỗi `Update`; `PlayerInteraction` đọc B/I/M/N/P/Tab/F và chuột, quét collider gần; mỗi đối tượng thực hiện `IInteractable.InteractionHint`, `CanInteract`, `Interact`, `SetHighlighted`. `InteractionOutline` vẽ LineRenderer quanh collider. `FarmHudV2` tự xử lý phím số/cuộn cho hotbar.
- **Ruộng:** `FieldManager` giữ `CropDefinition[]`, crop được chọn và số đã thu hoạch, tick toàn bộ `FarmPlot` mỗi khoảng 1 giây. `FarmExpansion.Work()` chọn hành động từ `PlotState`, tìm các ô gần, xử lý phạm vi 1/3/5, trừ hạt, cộng nông sản và XP. `FarmPlot.Tick()` hiện chỉ tăng tiến độ khi `Moisture > 0` và nước đầy cạn sau 75 giây; `TimeManager` bổ sung nước khi mưa/bão và tua cây khi ngủ.
- **Túi đồ/economy:** item ID 0–2 đọc/ghi `FieldManager.Harvested`; ID 3 là `FarmShop.Fruit`; ID 4–15 ánh xạ `FarmInventory.AnimalProducts[item-4]` (mảng dài 12). Shop giữ tiền/hạt/thức ăn; `FarmProcessing` đọc `Assets/StreamingAssets/recipes.json` và dùng item ID cố định. Thay đổi ID/mảng/giá phải cập nhật cùng nhau và giữ đọc bản lưu cũ.
- **Thời gian/đảo:** `TimeManager` điều khiển ngày, mùa, thời tiết, ánh sáng, mưa và ngủ; `DisasterPuzzleManager` xử lý bão. `IslandManager` quản lý di chuyển, NPC, chợ, minigame, di tích và `IslandState`. Các đảo nằm x≈0/200/400/600 trong một scene; `IslandManager.Travel()` kiểm tra LV rồi gọi `FarmPlayer.Teleport()`.
- **Lưu:** `FarmSave.Save()` serialize `SaveData` v4 bằng `JsonUtility`, viết tệp `.tmp` rồi `File.Replace`/`File.Move`, có `.bak` khi thay thế. `FarmSave.Start()` tự `Load()` khi không chạy smoke. `FarmHud.SaveNow()` là nút lưu duy nhất. Smoke dùng `pathOverride` trong thư mục cache tạm và dọn tệp test.
- **UI:** `FarmUi` tạo panel/nút uGUI và nhãn TMP; font TMP lấy từ `Assets/Farm/Resources/FarmFont.asset`, TMP Essentials ở `Assets/TextMesh Pro`. Canvas Scaler 1920×1080 Match 0.5. Một số panel cũ vẫn dùng `LegacyRuntime.ttf`.
- **Dependency vận hành:** URP asset/render settings, Input System, Cinemachine, TextMeshPro resources, Unity scene/prefab/`.meta` GUID, JSON recipe ID, Windows build data folder. Không có server/multiplayer cho NPC/chợ.

# 4. IMPORTANT FILES

Quy ước cột cuối: **thận trọng** = chỉ sửa sau khi xem quan hệ/test; **có thể mở rộng** = phù hợp thêm chức năng nhưng vẫn giữ API và compatibility. Không có file nào nên rewrite toàn bộ chỉ để làm task mới.

| Path | Vai trò, API và quan hệ | Mức sửa |
|---|---|---|
| `Assets/Farm/Scenes/Farm.unity` | Scene runtime duy nhất, serialize phần lớn world/HUD/player; được `FarmProjectBuilder.CreateScene()` ghi đè khi build. | Rất thận trọng; ưu tiên sửa builder. |
| `Assets/Farm/Editor/FarmProjectBuilder.cs` | `CreateScene`, `BuildWindows`, cấu hình URP/TMP, tạo ruộng/hồ/nhà/player/HUD; gọi partial builder. | Thận trọng: rebuild ghi scene/prefab/asset. |
| `Assets/Farm/Editor/FarmShopBuilder.cs` | `BuildShop`, wire toàn bộ hệ thống và dựng shop/chuồng/cây. Nơi phải wire hệ thống mới. | Có thể mở rộng, kiểm tra thứ tự khởi tạo. |
| `Assets/Farm/Editor/FarmIslandsBuilder.cs` | Dựng đảo, cổng, NPC, bẫy và resource node ở cùng scene. | Thận trọng với tọa độ/collider/điểm đến. |
| `Assets/Farm/Editor/FarmCharacters.cs` | Dựng hình nhân vật và vật nuôi/prefab primitive. | Có thể sửa hình, giữ prefab/script. |
| `Assets/Farm/Scripts/Player/FarmInput.cs` | InputAction cho di chuyển/nhìn/chạy/nhảy/E/Esc; cần mở rộng cho bay. | Thận trọng với phím đang dùng. |
| `Assets/Farm/Scripts/Player/FarmPlayer.cs` | `CharacterController`, pause, `Teleport`, trọng lực, phục hồi khi rơi; liên quan IslandManager/FarmSave/trap. | Thận trọng, cần smoke chuyển động. |
| `Assets/Farm/Scripts/Player/FarmCamera.cs` | Cinemachine góc nhìn thứ nhất/thứ ba và chống camera xuyên tường. | Giữ hai chế độ. |
| `Assets/Farm/Scripts/Player/PlayerSettings.cs` và `Assets/Farm/Data/PlayerSettings.asset` | Tốc độ 4/7, nhảy 0.8, gravity -22, camera; asset runtime. | Giữ đồng bộ code/asset. |
| `Assets/Farm/Scripts/Interaction/IInteractable.cs` | Interface 4 thành phần và `InteractionOutline`. Các object world triển khai interface. | Không đổi chữ ký tùy tiện. |
| `Assets/Farm/Scripts/Interaction/PlayerInteraction.cs` | Quét mục tiêu `OverlapSphereNonAlloc`, tương tác E, phím panel, F, nhấc/thả vật nuôi, nhãn world TMP. | Có thể thêm route; tránh làm vỡ tương tác cũ. |
| `Assets/Farm/Scripts/Interaction/IslandPortal.cs` | Cổng gọi `IslandManager.Travel(destination)`. | Giữ đích và level thường. |
| `Assets/Farm/Scripts/Crops/CropDefinition.cs` và `Assets/Farm/Data/Crop0.asset`…`Crop2.asset` | Định nghĩa tên, `growthSeconds`, yield, màu; builder hiện gán lại 35/45/55. | Sửa cả builder khi đổi thời gian. |
| `Assets/Farm/Scripts/Crops/FarmPlot.cs` | `PlotState`, `Work`, `Tick`, `AddMoisture`, `Restore`, hình cây; bị ảnh hưởng bởi nước/khô/chọn tool. | Thận trọng với save/smoke. |
| `Assets/Farm/Scripts/Crops/FieldManager.cs` | Danh sách cây, crop chọn, `Harvested`, tick ruộng. | Giữ ánh xạ crop ID. |
| `Assets/Farm/Scripts/Core/FarmExpansion.cs` | LV/XP, 4 vùng đất, nâng dụng cụ, `ToolRadius`, `Work`. Hiện không kiểm tra hotbar. | Có thể mở rộng, giữ region unlock. |
| `Assets/Farm/Scripts/Core/TimeManager.cs` | Đồng hồ 600s/ngày, mùa/thời tiết/mưa/ngủ; cần đồng bộ trạm tưới/đơn ngày mới. | Thận trọng với pause và ngủ. |
| `Assets/Farm/Scripts/Core/DisasterPuzzleManager.cs` | Câu đố bão và thiệt hại. | Tránh thay đổi ngẫu nhiên không liên quan. |
| `Assets/Farm/Scripts/Core/FarmProcessing.cs` và `Assets/StreamingAssets/recipes.json` | Công thức máy, hàng đợi, item ID, metal blueprint; cần nối unlock theo đơn nhưng không biến bàn chế tạo thành máy cũ. | Thận trọng với queue/save. |
| `Assets/Farm/Scripts/Core/IslandManager.cs` | Bản đồ, `Travel`, NPC, đấu giá, minigame, puzzle/bản vẽ; cần bỏ gate LV chỉ trong mode sáng tạo. | Không bỏ gate của mode thường. |
| `Assets/Farm/Scripts/Core/FarmSave.cs` | SaveData v4, `Save`, `Load`, đường lưu, tương thích v2/v3/v4; nơi thêm schema v5/mode. | Rất thận trọng; không auto-save. |
| `Assets/Farm/Scripts/Core/BuildSmokeCheck.cs` | Chạy test trong player khi có `-farmSmokeCheck`, viết ảnh preview và log mốc FARM_*. | Cập nhật assertion khi thay balance. |
| `Assets/Farm/Scripts/UI/FarmHud.cs` | Main/pause/settings/instructions/save/resume/quit; nơi thêm chọn creative và vô hiệu lưu. | Giữ menu Esc/lưu thủ công. |
| `Assets/Farm/Scripts/UI/FarmHudV2.cs` | HUD TMP và hotbar 9 ô, `SelectedSlot`; hiện chỉ ô 1–3 gọi `FieldManager.Select`. | Giữ layout/slot ID khi gate action. |
| `Assets/Farm/Scripts/UI/FarmInventory.cs` | 16 item ID, giá, Add/Remove/Count/Sell, lưới 4×4; sẽ cần thêm hàng và cuộn. | Rất thận trọng với index/save. |
| `Assets/Farm/Scripts/UI/FarmShop.cs` | Tiền, hạt, thức ăn, giá gói hạt, mua vật nuôi/cây/chuồng. | Giữ giao dịch và seed array. |
| `Assets/Farm/Scripts/UI/FarmUi.cs` | Factory UI, nhãn TMP/legacy. | Có thể mở rộng, giữ font TMP. |
| `Assets/Farm/Scripts/Animals/` | FarmAnimal, AnimalPen, AnimalCarry, EggNest, PaddockGate, AnimalSpecies. | Giữ sức chứa/sản phẩm/nhấc thả. |
| `Assets/Farm/Resources/FarmFont.asset` và `Assets/TextMesh Pro/` | Font game và TMP Essentials đã phải thêm để bản build không lỗi. | Không xóa/đổi GUID tùy tiện. |
| `Packages/manifest.json`, `ProjectSettings/ProjectVersion.txt` | Phiên bản dependency/Unity. | Không nâng version tùy tiện. |
| `README.md`, `CHOI_GAME.md` | Chạy/build và hướng dẫn hiện tại. | Cập nhật sau khi code mới chạy thật. |

# 5. CHANGES MADE IN THIS THREAD

**Nguồn xác minh:** Git có bốn commit tuần tự `06edf60` → `aacce4f` → `fae66b0` → `1cc34cc`; `origin/main` hiện là `1cc34cc`. Bản tóm tắt trước compaction và lịch sử commit cho thấy chuỗi chức năng dưới đây. Việc một file trong commit đầu tiên có được tạo trong chính task Codex này hay từ bước chuẩn bị ban đầu: **CHƯA XÁC MINH**. Danh sách A/M/D đầy đủ do Git ghi được chép nguyên trạng ở cuối mục này. `A` = tạo, `M` = sửa; **không có `D`** trong lịch sử bốn commit đã kiểm tra. Các file `.meta` và TMP Essentials được giữ trong manifest vì Unity cần GUID, dù không liệt kê chúng riêng trong mục 4.

1. `06edf60` — tạo dự án Unity cơ bản: cấu hình/packages/scene/asset, builder, crop, FieldManager, FarmPlot, player/input/camera, farm animal, HUD, smoke test, README/CHOI_GAME và ảnh tham chiếu. Lý do: xây game nông trại đầu tiên từ prompt/ảnh.
2. `aacce4f` — tạo `FarmShopBuilder.cs`, prefabs vật nuôi/cây, `AnimalCarry`, `AnimalPen`, `AnimalSpecies`, `EggNest`, `PaddockGate`, `FarmSave`, `FruitTree`, `FarmInventory`, `FarmShop`, `ShopCounter`; sửa builder/scene/FarmAnimal/FarmPlot/PlayerInteraction/HUD/docs/smoke. Lý do: shop, chuồng riêng, sản phẩm vật nuôi, túi đồ, tương tác và lưu.
3. `fae66b0` — sửa `FarmSave.cs`, `FarmProjectBuilder.cs`, scene, prefabs và docs. Lý do: bỏ lưu khi thoát; chỉ bấm nút **Lưu game** mới ghi.
4. `1cc34cc` — tạo `FarmIslandsBuilder.cs`, vật liệu đảo, `FarmFont.asset`, `DisasterPuzzleManager`, `FarmAudio`, `FarmEffects`, `FarmExpansion`, `FarmProcessing`, `IslandManager`, `TimeManager`, `FarmBed`, `FishingPier`, `IInteractable`, các MonoBehaviour đảo/tài nguyên, `FarmBarnMenu`, `FarmHudV2`, `FarmUi`, JSON công thức và TMP Essentials. Sửa builder/wiring, scene, prefab, các hệ thống động vật/ruộng/save/tương tác/player/HUD/shop/inventory/docs/packages. Lý do: bốn đảo, NPC/chợ chơi đơn, chu kỳ ngày-mùa-thời tiết, bão, TMP HUD, chế biến/đất/dụng cụ và giao diện.

**Sửa lỗi trong commit cuối được ghi nhận qua quá trình build/smoke:** tách từng MonoBehaviour của đảo ra file `.cs` đúng tên để Unity không báo Missing Script; nhập TMP Essentials và tạo FarmFont để hết lỗi TMP runtime; thay truy cập `worldLabel.textContainer` (API trả null) bằng `rectTransform`, giảm kích thước nhãn world để hết chữ phóng rất lớn; thay ký tự đồng xu không có glyph bằng `XU`; chỉnh sáng bình minh; biển có mặt trước/sau hiển thị đúng trong ảnh smoke. Các thử nghiệm trung gian tạo log/ảnh trong thư mục ignored, không phải source cuối.

**Không có thay đổi source sau `1cc34cc`:** lượt yêu cầu triển khai nước/chế tạo/creative mới chỉ gửi commentary rồi bị ngắt. Tài liệu handoff này là file mới duy nhất của lượt hiện tại, nằm ở project root ngoài Git clone. `IslandObjects.cs` là tên file trung gian được nhắc trong bản tóm tắt quá trình sửa Missing Script, hiện không tồn tại trong source và không xuất hiện trong bốn commit; việc nó từng được tạo rồi xóa ở trạng thái chưa commit là **CHƯA XÁC MINH bằng Git**. Danh sách Git phía dưới chỉ khẳng định không có file **đã commit** bị xóa.

<details><summary>Manifest A/M/D chính xác từ 4 commit Git — gồm Unity .meta và TMP assets</summary>

```text
COMMIT 06edf60 Add Unity farming game with crops, player and roaming animals

A	.gitignore
A	Assets/DefaultVolumeProfile.asset
A	Assets/DefaultVolumeProfile.asset.meta
A	Assets/Farm.meta
A	Assets/Farm/Art.meta
A	Assets/Farm/Art/DepthFont.shader
A	Assets/Farm/Art/DepthFont.shader.meta
A	Assets/Farm/Data.meta
A	Assets/Farm/Data/Crop0.asset
A	Assets/Farm/Data/Crop0.asset.meta
A	Assets/Farm/Data/Crop1.asset
A	Assets/Farm/Data/Crop1.asset.meta
A	Assets/Farm/Data/Crop2.asset
A	Assets/Farm/Data/Crop2.asset.meta
A	Assets/Farm/Data/PlayerSettings.asset
A	Assets/Farm/Data/PlayerSettings.asset.meta
A	Assets/Farm/Editor.meta
A	Assets/Farm/Editor/FarmCharacters.cs
A	Assets/Farm/Editor/FarmCharacters.cs.meta
A	Assets/Farm/Editor/FarmProjectBuilder.cs
A	Assets/Farm/Editor/FarmProjectBuilder.cs.meta
A	Assets/Farm/Materials.meta
A	Assets/Farm/Materials/Animal black.mat
A	Assets/Farm/Materials/Animal black.mat.meta
A	Assets/Farm/Materials/Animal ivory.mat
A	Assets/Farm/Materials/Animal ivory.mat.meta
A	Assets/Farm/Materials/Barn red.mat
A	Assets/Farm/Materials/Barn red.mat.meta
A	Assets/Farm/Materials/Cheeks.mat
A	Assets/Farm/Materials/Cheeks.mat.meta
A	Assets/Farm/Materials/Denim.mat
A	Assets/Farm/Materials/Denim.mat.meta
A	Assets/Farm/Materials/Eyes and boots.mat
A	Assets/Farm/Materials/Eyes and boots.mat.meta
A	Assets/Farm/Materials/Farmer denim.mat
A	Assets/Farm/Materials/Farmer denim.mat.meta
A	Assets/Farm/Materials/Farmer shirt.mat
A	Assets/Farm/Materials/Farmer shirt.mat.meta
A	Assets/Farm/Materials/Farmer skin.mat
A	Assets/Farm/Materials/Farmer skin.mat.meta
A	Assets/Farm/Materials/Foliage.mat
A	Assets/Farm/Materials/Foliage.mat.meta
A	Assets/Farm/Materials/Grass.mat
A	Assets/Farm/Materials/Grass.mat.meta
A	Assets/Farm/Materials/Hair.mat
A	Assets/Farm/Materials/Hair.mat.meta
A	Assets/Farm/Materials/Ivory.mat
A	Assets/Farm/Materials/Ivory.mat.meta
A	Assets/Farm/Materials/Path.mat
A	Assets/Farm/Materials/Path.mat.meta
A	Assets/Farm/Materials/Pig pink.mat
A	Assets/Farm/Materials/Pig pink.mat.meta
A	Assets/Farm/Materials/Pocket blue.mat
A	Assets/Farm/Materials/Pocket blue.mat.meta
A	Assets/Farm/Materials/Pond.mat
A	Assets/Farm/Materials/Pond.mat.meta
A	Assets/Farm/Materials/Roof.mat
A	Assets/Farm/Materials/Roof.mat.meta
A	Assets/Farm/Materials/SignText.mat
A	Assets/Farm/Materials/SignText.mat.meta
A	Assets/Farm/Materials/Silo.mat
A	Assets/Farm/Materials/Silo.mat.meta
A	Assets/Farm/Materials/Skin.mat
A	Assets/Farm/Materials/Skin.mat.meta
A	Assets/Farm/Materials/Soil.mat
A	Assets/Farm/Materials/Soil.mat.meta
A	Assets/Farm/Materials/Straw.mat
A	Assets/Farm/Materials/Straw.mat.meta
A	Assets/Farm/Materials/Timber.mat
A	Assets/Farm/Materials/Timber.mat.meta
A	Assets/Farm/Prefabs.meta
A	Assets/Farm/Scenes.meta
A	Assets/Farm/Scenes/Farm.unity
A	Assets/Farm/Scenes/Farm.unity.meta
A	Assets/Farm/Scripts.meta
A	Assets/Farm/Scripts/Animals.meta
A	Assets/Farm/Scripts/Animals/FarmAnimal.cs
A	Assets/Farm/Scripts/Animals/FarmAnimal.cs.meta
A	Assets/Farm/Scripts/Core.meta
A	Assets/Farm/Scripts/Core/BuildSmokeCheck.cs
A	Assets/Farm/Scripts/Core/BuildSmokeCheck.cs.meta
A	Assets/Farm/Scripts/Crops.meta
A	Assets/Farm/Scripts/Crops/CropDefinition.cs
A	Assets/Farm/Scripts/Crops/CropDefinition.cs.meta
A	Assets/Farm/Scripts/Crops/FarmPlot.cs
A	Assets/Farm/Scripts/Crops/FarmPlot.cs.meta
A	Assets/Farm/Scripts/Crops/FieldManager.cs
A	Assets/Farm/Scripts/Crops/FieldManager.cs.meta
A	Assets/Farm/Scripts/Interaction.meta
A	Assets/Farm/Scripts/Interaction/FarmSign.cs
A	Assets/Farm/Scripts/Interaction/FarmSign.cs.meta
A	Assets/Farm/Scripts/Interaction/PlayerInteraction.cs
A	Assets/Farm/Scripts/Interaction/PlayerInteraction.cs.meta
A	Assets/Farm/Scripts/Player.meta
A	Assets/Farm/Scripts/Player/FarmCamera.cs
A	Assets/Farm/Scripts/Player/FarmCamera.cs.meta
A	Assets/Farm/Scripts/Player/FarmInput.cs
A	Assets/Farm/Scripts/Player/FarmInput.cs.meta
A	Assets/Farm/Scripts/Player/FarmPlayer.cs
A	Assets/Farm/Scripts/Player/FarmPlayer.cs.meta
A	Assets/Farm/Scripts/Player/FarmerAnimation.cs
A	Assets/Farm/Scripts/Player/FarmerAnimation.cs.meta
A	Assets/Farm/Scripts/Player/PlayerSettings.cs
A	Assets/Farm/Scripts/Player/PlayerSettings.cs.meta
A	Assets/Farm/Scripts/UI.meta
A	Assets/Farm/Scripts/UI/FarmHud.cs
A	Assets/Farm/Scripts/UI/FarmHud.cs.meta
A	Assets/Farm/Scripts/UI/WorldSignText.cs
A	Assets/Farm/Scripts/UI/WorldSignText.cs.meta
A	Assets/Farm/Settings.meta
A	Assets/Farm/Settings/FarmRenderer.asset
A	Assets/Farm/Settings/FarmRenderer.asset.meta
A	Assets/Farm/Settings/FarmURP.asset
A	Assets/Farm/Settings/FarmURP.asset.meta
A	Assets/Resources.meta
A	Assets/UniversalRenderPipelineGlobalSettings.asset
A	Assets/UniversalRenderPipelineGlobalSettings.asset.meta
A	CHOI_GAME.md
A	ChatGPT Image Sep 20, 2026, 07_13_45 PM.png
A	Packages/manifest.json
A	Packages/packages-lock.json
A	ProjectSettings/AudioManager.asset
A	ProjectSettings/ClusterInputManager.asset
A	ProjectSettings/DynamicsManager.asset
A	ProjectSettings/EditorBuildSettings.asset
A	ProjectSettings/EditorSettings.asset
A	ProjectSettings/GraphicsSettings.asset
A	ProjectSettings/InputManager.asset
A	ProjectSettings/MemorySettings.asset
A	ProjectSettings/MultiplayerManager.asset
A	ProjectSettings/NavMeshAreas.asset
A	ProjectSettings/Physics2DSettings.asset
A	ProjectSettings/PresetManager.asset
A	ProjectSettings/ProjectSettings.asset
A	ProjectSettings/ProjectVersion.txt
A	ProjectSettings/QualitySettings.asset
A	ProjectSettings/SceneTemplateSettings.json
A	ProjectSettings/TagManager.asset
A	ProjectSettings/TimeManager.asset
A	ProjectSettings/UnityConnectSettings.asset
A	ProjectSettings/VFXManager.asset
A	ProjectSettings/VersionControlSettings.asset
A	README.md
A	prompt.MD
COMMIT aacce4f Add species pens, animal handling, inventory and saves

M	Assets/Farm/Editor/FarmCharacters.cs
M	Assets/Farm/Editor/FarmProjectBuilder.cs
A	Assets/Farm/Editor/FarmShopBuilder.cs
A	Assets/Farm/Editor/FarmShopBuilder.cs.meta
A	Assets/Farm/Prefabs/Animal0.prefab
A	Assets/Farm/Prefabs/Animal0.prefab.meta
A	Assets/Farm/Prefabs/Animal1.prefab
A	Assets/Farm/Prefabs/Animal1.prefab.meta
A	Assets/Farm/Prefabs/Animal2.prefab
A	Assets/Farm/Prefabs/Animal2.prefab.meta
A	Assets/Farm/Prefabs/Animal3.prefab
A	Assets/Farm/Prefabs/Animal3.prefab.meta
A	Assets/Farm/Prefabs/AppleTree.prefab
A	Assets/Farm/Prefabs/AppleTree.prefab.meta
M	Assets/Farm/Scenes/Farm.unity
A	Assets/Farm/Scripts/Animals/AnimalCarry.cs
A	Assets/Farm/Scripts/Animals/AnimalCarry.cs.meta
A	Assets/Farm/Scripts/Animals/AnimalPen.cs
A	Assets/Farm/Scripts/Animals/AnimalPen.cs.meta
A	Assets/Farm/Scripts/Animals/AnimalSpecies.cs
A	Assets/Farm/Scripts/Animals/AnimalSpecies.cs.meta
A	Assets/Farm/Scripts/Animals/EggNest.cs
A	Assets/Farm/Scripts/Animals/EggNest.cs.meta
M	Assets/Farm/Scripts/Animals/FarmAnimal.cs
A	Assets/Farm/Scripts/Animals/PaddockGate.cs
A	Assets/Farm/Scripts/Animals/PaddockGate.cs.meta
M	Assets/Farm/Scripts/Core/BuildSmokeCheck.cs
A	Assets/Farm/Scripts/Core/FarmSave.cs
A	Assets/Farm/Scripts/Core/FarmSave.cs.meta
M	Assets/Farm/Scripts/Crops/FarmPlot.cs
A	Assets/Farm/Scripts/Crops/FruitTree.cs
A	Assets/Farm/Scripts/Crops/FruitTree.cs.meta
M	Assets/Farm/Scripts/Interaction/PlayerInteraction.cs
M	Assets/Farm/Scripts/UI/FarmHud.cs
A	Assets/Farm/Scripts/UI/FarmInventory.cs
A	Assets/Farm/Scripts/UI/FarmInventory.cs.meta
A	Assets/Farm/Scripts/UI/FarmShop.cs
A	Assets/Farm/Scripts/UI/FarmShop.cs.meta
A	Assets/Farm/Scripts/UI/ShopCounter.cs
A	Assets/Farm/Scripts/UI/ShopCounter.cs.meta
M	CHOI_GAME.md
M	README.md
COMMIT fae66b0 Save farm progress only when player chooses Save

M	Assets/Farm/Editor/FarmProjectBuilder.cs
M	Assets/Farm/Prefabs/Animal0.prefab
M	Assets/Farm/Prefabs/Animal1.prefab
M	Assets/Farm/Prefabs/Animal2.prefab
M	Assets/Farm/Prefabs/Animal3.prefab
M	Assets/Farm/Prefabs/AppleTree.prefab
M	Assets/Farm/Scenes/Farm.unity
M	Assets/Farm/Scripts/Core/FarmSave.cs
M	CHOI_GAME.md
M	README.md
COMMIT 1cc34cc Add seasons, weather, island activities and TMP HUD

A	Assets/Farm/Editor/FarmIslandsBuilder.cs
A	Assets/Farm/Editor/FarmIslandsBuilder.cs.meta
M	Assets/Farm/Editor/FarmProjectBuilder.cs
M	Assets/Farm/Editor/FarmShopBuilder.cs
A	Assets/Farm/Materials/Central island.mat
A	Assets/Farm/Materials/Central island.mat.meta
A	Assets/Farm/Materials/Industrial island.mat
A	Assets/Farm/Materials/Industrial island.mat.meta
A	Assets/Farm/Materials/Island stone.mat
A	Assets/Farm/Materials/Island stone.mat.meta
A	Assets/Farm/Materials/Mystery island.mat
A	Assets/Farm/Materials/Mystery island.mat.meta
A	Assets/Farm/Materials/Sea.mat
A	Assets/Farm/Materials/Sea.mat.meta
M	Assets/Farm/Prefabs/Animal0.prefab
M	Assets/Farm/Prefabs/Animal1.prefab
M	Assets/Farm/Prefabs/Animal2.prefab
M	Assets/Farm/Prefabs/Animal3.prefab
M	Assets/Farm/Prefabs/AppleTree.prefab
A	Assets/Farm/Resources.meta
A	Assets/Farm/Resources/FarmFont.asset
A	Assets/Farm/Resources/FarmFont.asset.meta
M	Assets/Farm/Scenes/Farm.unity
M	Assets/Farm/Scripts/Animals/AnimalPen.cs
M	Assets/Farm/Scripts/Animals/EggNest.cs
M	Assets/Farm/Scripts/Animals/FarmAnimal.cs
M	Assets/Farm/Scripts/Animals/PaddockGate.cs
M	Assets/Farm/Scripts/Core/BuildSmokeCheck.cs
A	Assets/Farm/Scripts/Core/DisasterPuzzleManager.cs
A	Assets/Farm/Scripts/Core/DisasterPuzzleManager.cs.meta
A	Assets/Farm/Scripts/Core/FarmAudio.cs
A	Assets/Farm/Scripts/Core/FarmAudio.cs.meta
A	Assets/Farm/Scripts/Core/FarmEffects.cs
A	Assets/Farm/Scripts/Core/FarmEffects.cs.meta
A	Assets/Farm/Scripts/Core/FarmExpansion.cs
A	Assets/Farm/Scripts/Core/FarmExpansion.cs.meta
A	Assets/Farm/Scripts/Core/FarmProcessing.cs
A	Assets/Farm/Scripts/Core/FarmProcessing.cs.meta
M	Assets/Farm/Scripts/Core/FarmSave.cs
A	Assets/Farm/Scripts/Core/IslandManager.cs
A	Assets/Farm/Scripts/Core/IslandManager.cs.meta
A	Assets/Farm/Scripts/Core/TimeManager.cs
A	Assets/Farm/Scripts/Core/TimeManager.cs.meta
M	Assets/Farm/Scripts/Crops/FarmPlot.cs
M	Assets/Farm/Scripts/Crops/FruitTree.cs
A	Assets/Farm/Scripts/Interaction/FarmBed.cs
A	Assets/Farm/Scripts/Interaction/FarmBed.cs.meta
M	Assets/Farm/Scripts/Interaction/FarmSign.cs
A	Assets/Farm/Scripts/Interaction/FishingPier.cs
A	Assets/Farm/Scripts/Interaction/FishingPier.cs.meta
A	Assets/Farm/Scripts/Interaction/IInteractable.cs
A	Assets/Farm/Scripts/Interaction/IInteractable.cs.meta
A	Assets/Farm/Scripts/Interaction/IslandAuctionKiosk.cs
A	Assets/Farm/Scripts/Interaction/IslandAuctionKiosk.cs.meta
A	Assets/Farm/Scripts/Interaction/IslandGameKiosk.cs
A	Assets/Farm/Scripts/Interaction/IslandGameKiosk.cs.meta
A	Assets/Farm/Scripts/Interaction/IslandNpc.cs
A	Assets/Farm/Scripts/Interaction/IslandNpc.cs.meta
A	Assets/Farm/Scripts/Interaction/IslandPortal.cs
A	Assets/Farm/Scripts/Interaction/IslandPortal.cs.meta
A	Assets/Farm/Scripts/Interaction/IslandTrap.cs
A	Assets/Farm/Scripts/Interaction/IslandTrap.cs.meta
A	Assets/Farm/Scripts/Interaction/MysteryAltar.cs
A	Assets/Farm/Scripts/Interaction/MysteryAltar.cs.meta
M	Assets/Farm/Scripts/Interaction/PlayerInteraction.cs
A	Assets/Farm/Scripts/Interaction/ResourceNode.cs
A	Assets/Farm/Scripts/Interaction/ResourceNode.cs.meta
M	Assets/Farm/Scripts/Player/FarmPlayer.cs
A	Assets/Farm/Scripts/UI/FarmBarnMenu.cs
A	Assets/Farm/Scripts/UI/FarmBarnMenu.cs.meta
M	Assets/Farm/Scripts/UI/FarmHud.cs
A	Assets/Farm/Scripts/UI/FarmHudV2.cs
A	Assets/Farm/Scripts/UI/FarmHudV2.cs.meta
M	Assets/Farm/Scripts/UI/FarmInventory.cs
M	Assets/Farm/Scripts/UI/FarmShop.cs
A	Assets/Farm/Scripts/UI/FarmUi.cs
A	Assets/Farm/Scripts/UI/FarmUi.cs.meta
M	Assets/Farm/Scripts/UI/ShopCounter.cs
A	Assets/StreamingAssets.meta
A	Assets/StreamingAssets/recipes.json
A	Assets/StreamingAssets/recipes.json.meta
A	Assets/TextMesh Pro.meta
A	Assets/TextMesh Pro/Fonts.meta
A	Assets/TextMesh Pro/Fonts/LiberationSans - OFL.txt
A	Assets/TextMesh Pro/Fonts/LiberationSans - OFL.txt.meta
A	Assets/TextMesh Pro/Fonts/LiberationSans.ttf
A	Assets/TextMesh Pro/Fonts/LiberationSans.ttf.meta
A	Assets/TextMesh Pro/Resources.meta
A	Assets/TextMesh Pro/Resources/Fonts & Materials.meta
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Drop Shadow.mat
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Drop Shadow.mat.meta
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Fallback.asset
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Fallback.asset.meta
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Outline.mat
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF - Outline.mat.meta
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset
A	Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset.meta
A	Assets/TextMesh Pro/Resources/LineBreaking Following Characters.txt
A	Assets/TextMesh Pro/Resources/LineBreaking Following Characters.txt.meta
A	Assets/TextMesh Pro/Resources/LineBreaking Leading Characters.txt
A	Assets/TextMesh Pro/Resources/LineBreaking Leading Characters.txt.meta
A	Assets/TextMesh Pro/Resources/Sprite Assets.meta
A	Assets/TextMesh Pro/Resources/Sprite Assets/EmojiOne.asset
A	Assets/TextMesh Pro/Resources/Sprite Assets/EmojiOne.asset.meta
A	Assets/TextMesh Pro/Resources/Style Sheets.meta
A	Assets/TextMesh Pro/Resources/Style Sheets/Default Style Sheet.asset
A	Assets/TextMesh Pro/Resources/Style Sheets/Default Style Sheet.asset.meta
A	Assets/TextMesh Pro/Resources/TMP Settings.asset
A	Assets/TextMesh Pro/Resources/TMP Settings.asset.meta
A	Assets/TextMesh Pro/Shaders.meta
A	Assets/TextMesh Pro/Shaders/SDFFunctions.hlsl
A	Assets/TextMesh Pro/Shaders/SDFFunctions.hlsl.meta
A	Assets/TextMesh Pro/Shaders/TMP_Bitmap-Custom-Atlas.shader
A	Assets/TextMesh Pro/Shaders/TMP_Bitmap-Custom-Atlas.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_Bitmap-Mobile.shader
A	Assets/TextMesh Pro/Shaders/TMP_Bitmap-Mobile.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_Bitmap.shader
A	Assets/TextMesh Pro/Shaders/TMP_Bitmap.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF Overlay.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF Overlay.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF SSD.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF SSD.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-HDRP LIT.shadergraph
A	Assets/TextMesh Pro/Shaders/TMP_SDF-HDRP LIT.shadergraph.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-HDRP UNLIT.shadergraph
A	Assets/TextMesh Pro/Shaders/TMP_SDF-HDRP UNLIT.shadergraph.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile Masking.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile Masking.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile Overlay.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile Overlay.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile SSD.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile SSD.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile-2-Pass.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile-2-Pass.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Mobile.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Surface-Mobile.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Surface-Mobile.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Surface.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF-Surface.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-URP Lit.shadergraph
A	Assets/TextMesh Pro/Shaders/TMP_SDF-URP Lit.shadergraph.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF-URP Unlit.shadergraph
A	Assets/TextMesh Pro/Shaders/TMP_SDF-URP Unlit.shadergraph.meta
A	Assets/TextMesh Pro/Shaders/TMP_SDF.shader
A	Assets/TextMesh Pro/Shaders/TMP_SDF.shader.meta
A	Assets/TextMesh Pro/Shaders/TMP_Sprite.shader
A	Assets/TextMesh Pro/Shaders/TMP_Sprite.shader.meta
A	Assets/TextMesh Pro/Shaders/TMPro.cginc
A	Assets/TextMesh Pro/Shaders/TMPro.cginc.meta
A	Assets/TextMesh Pro/Shaders/TMPro_Mobile.cginc
A	Assets/TextMesh Pro/Shaders/TMPro_Mobile.cginc.meta
A	Assets/TextMesh Pro/Shaders/TMPro_Properties.cginc
A	Assets/TextMesh Pro/Shaders/TMPro_Properties.cginc.meta
A	Assets/TextMesh Pro/Shaders/TMPro_Surface.cginc
A	Assets/TextMesh Pro/Shaders/TMPro_Surface.cginc.meta
A	Assets/TextMesh Pro/Sprites.meta
A	Assets/TextMesh Pro/Sprites/EmojiOne Attribution.txt
A	Assets/TextMesh Pro/Sprites/EmojiOne Attribution.txt.meta
A	Assets/TextMesh Pro/Sprites/EmojiOne.json
A	Assets/TextMesh Pro/Sprites/EmojiOne.json.meta
A	Assets/TextMesh Pro/Sprites/EmojiOne.png
A	Assets/TextMesh Pro/Sprites/EmojiOne.png.meta
M	CHOI_GAME.md
M	Packages/manifest.json
M	Packages/packages-lock.json
A	ProjectSettings/ShaderGraphSettings.asset
M	README.md
```

</details>

# 6. IMPORTANT DECISIONS

- Chợ đấu giá và kết bạn tại Đảo Trung Tâm là **NPC/mô phỏng chơi đơn trước**, không có multiplayer/server; user đã xác nhận.
- Lưu **thủ công**: thoát không ghi; game tải bản lưu gần nhất khi khởi động. Giữ hành vi này khi thêm tính năng mới.
- Một scene chứa bốn đảo, di chuyển bằng Tab hoặc cổng; đảo Thần Bí/Công Nghiệp có gate LV trong chế độ thường.
- `IInteractable` + quét mục tiêu gần bằng `Physics.OverlapSphereNonAlloc`, viền và gợi ý world-space thay cho dấu cộng cố định.
- Công thức máy trong `StreamingAssets/recipes.json`, dùng item ID của `FarmInventory`; bàn chế tạo được thống nhất là hệ thống **ghép nhiều nguyên liệu ra hàng giao hộp thư**, khác với máy xếp hàng hiện tại.
- Kế hoạch mới đã chọn: cây được tưới chín 2/3/5 phút; khô vẫn lớn 20%; lấy nước ở hồ; trạm tự tưới trong vùng nhưng **người chơi phải chở nước từ hồ tới nạp**, không tự tạo nước.
- Hộp thư: hai đơn ngẫu nhiên/ngày, một đơn craft và một đơn nông sản/chế biến; được đổi **một đơn mỗi 5 phút chơi thực tế**, không tính pause/ngủ. Đơn hoàn thành mở dần bánh mì/phô mai/nước táo. Đây là **quyết định thiết kế chưa triển khai**.
- Chế độ sáng tạo được chốt là **dịch chuyển mọi đảo không cần LV và bay**, không cấp tài nguyên/xu vô hạn; bắt đầu từ bản sao trong bộ nhớ của bản lưu hiện có, **không lưu**, rời mode bỏ mọi thay đổi. Mode thường vẫn giữ LV và bản lưu. Đây là **quyết định thiết kế chưa triển khai**.
- User ưu tiên tối ưu đi bộ/nhảy/va chạm, không yêu cầu đại tu camera. Đây là **quyết định thiết kế chưa triển khai**.
- Giải pháp trung gian bị bỏ: nhiều MonoBehaviour trong một file làm scene báo Missing Script; TMP không có Essentials gây lỗi runtime; `TextMeshPro.textContainer` obsolete trả `null`; ký tự `◉` không có glyph. Bản cuối đã dùng file tách riêng, TMP resources và `rectTransform`, nhãn nhỏ, `XU`.
- Build không được đưa cả `Library`, `Temp`, `Logs`, `Builds` vào Git/source ZIP. Các ZIP cũ vẫn còn để tham khảo, nhưng gói mới nhất có tiền tố `NongTrai-Islands`.

# 7. DO NOT BREAK

- Giữ namespace `NongTrai`, interface `IInteractable` và các method `CanInteract`, `Interact`, `SetHighlighted`, `InteractionHint` vì nhiều object đang implement. Unity MonoBehaviour nên có `.cs` cùng tên class khi attach; giữ `.meta` GUID và scene/prefab references.
- Giữ `FarmProjectBuilder.BuildWindows()` và `CreateScene()` hoặc cập nhật nhất quán lệnh build/docs. Builder tái dựng `Farm.unity` và prefab; không sửa scene bằng tay rồi build khi chưa đưa thay đổi vào builder.
- Giữ item ID hiện hành: 0–2 crop, 3 táo, 4 trứng, 5 sữa, 6 len, 7 thịt, 8 bột, 9 bánh, 10 phô mai, 11 nước táo, 12 gỗ, 13 quặng, 14 ván, 15 kim loại. Mở rộng ID từ 16 trở đi, không đổi ID cũ; đồng bộ `FarmInventory`, JSON recipe và save.
- Giữ `FarmShop.Seeds` độ dài 3, `FieldManager.Harvested` độ dài 3, `FarmExpansion.ToolTiers` độ dài 3 và `UnlockedRegions` độ dài 4 trừ khi có migration đầy đủ. `SaveData` v4 hiện đọc v2/v3/v4; v5 mới phải tiếp tục đọc v2–v4. Không tự lưu khi thoát và không cho creative ghi đè bản lưu thường.
- Giữ 4 loài/chuồng riêng, gà tối đa 5 con/chuồng, nhấc trái/thả phải, F cho ăn, thu trứng tại ổ, sữa/len có cooldown, heo cho thịt rồi rời chuồng.
- Giữ 1 ngày 600s, mùa 28 ngày, mưa tưới ruộng, bão có puzzle, ngủ tới 06:00; khi sửa tốc độ cây phải cập nhật cả tick lúc ngủ/test.
- Giữ 4 đảo, cổng, NPC/chợ chơi đơn, di tích/bản vẽ và gate LV ở **mode thường**. Bypass LV chỉ cho du hành ở creative; không tắt cơ chế khác ngoài yêu cầu.
- Giữ font `FarmFont.asset`/TMP Essentials và tỷ lệ Canvas 1920×1080; không tái đưa nhãn tương tác khổng lồ/chữ đảo chiều. Giữ Input System mới; không chuyển lẫn UnityEngine.Input cũ.
- Giữ build Windows kèm `NongTrai_Data`, `MonoBleedingEdge`, DLL/UnityPlayer; một EXE riêng lẻ không đủ để chạy trên máy khác.

# 8. CURRENT BUGS / TECHNICAL DEBT

| Vấn đề | Triệu chứng & file liên quan | Nguyên nhân/đã thử/kết quả | Hướng tiếp theo |
|---|---|---|---|
| Hotbar không ràng buộc dụng cụ | Có thể cày dù không chọn cuốc, tưới dù không chọn bình; `FarmHudV2.cs`, `FarmExpansion.cs`, `FarmPlot.cs`. | `SelectedSlot` chỉ chọn crop khi `<3`; `FarmExpansion.Work` tự suy tool từ `PlotState`. User xác nhận đây là nghĩa của “vật phẩm bị ghi đè”. Chưa có fix. | Gate thao tác theo slot, hiển thị phím cần chọn, test không tiêu vật phẩm khi chọn sai. |
| Cây quá nhanh, đất khô dừng hẳn | 35/45/55s, nước đầy kéo 75s; `FarmProjectBuilder.cs`, Crop assets, `FarmPlot.cs`, smoke. | Cả ba cây chín sau một lần tưới. Chưa chỉnh theo kế hoạch mới. | 120/180/300s khi ẩm, 20% tốc độ lúc khô, giá khác nhau; sửa test cũ đang assert khô `Growth==0`. |
| Hồ chỉ trang trí; không có nước hữu hạn | `FarmProjectBuilder.cs` tạo `Pond surface - decorative`, `FarmPlot.Work` tưới không trừ nước; không có WaterSystem/pump. | Chưa thử giải pháp trong code. | Tạo điểm lấy nước, lượng nước bình và trạm tự tưới có bồn được nạp thủ công. |
| Chưa có craft/mail/đơn | `FarmProcessing.cs` chỉ có máy một-input và queue; `FarmInventory.cs` chỉ 16 loại lưới 4×4; chưa có mailbox. | Thiết kế được chốt qua các câu hỏi nhưng chưa code. | JSON craft nhiều nguyên liệu, 4 item mới, túi cuộn, hộp thư và giới hạn reroll. |
| Chưa có creative/test mode | `IslandManager.Travel` gate LV; `FarmHud` chỉ một nút vào game; `FarmSave` tự tải và có nút lưu; `FarmPlayer` chỉ đi/nhảy. | Chưa triển khai. | Mode riêng không lưu, clone trạng thái lưu vào RAM, bypass LV riêng cho travel, bay va chạm, reset scene khi rời. |
| Di chuyển vật lý còn tối giản | `FarmPlayer.cs` một `CharacterController.Move`, `isGrounded` đơn giản; rơi dưới y=-10 luôn về spawn ban đầu ở đảo nông trại. | Smoke chỉ kiểm tra đứng đất ban đầu; dốc/bậc/fall island khác: **CHƯA XÁC MINH**. | Cải thiện ground probe/jump buffer/coyote/slope/terminal speed, respawn đảo hiện tại, thêm test thực tế. |
| UI không thuần TMP, tỷ lệ khác chưa kiểm đủ | `FarmUi.Label`, shop/menu dùng uGUI `Text`; inventory TMP 4×4 hiện vừa 16 item. | Ảnh smoke 1280×720 hiện đọc được; 1920×1080 và màn hình hẹp: **CHƯA XÁC MINH**. | Khi thêm item, dùng ScrollRect và kiểm nhiều tỷ lệ. |
| Đồng hồ đấu giá có thể chạy khi game tạm dừng | `IslandManager.Update` trừ `Time.unscaledDeltaTime` khi có listing, không kiểm `player.Paused`. | Suy ra trực tiếp từ code; việc đây có phải lỗi theo ý định sản phẩm hay không: **CHƯA XÁC MINH**. | Khi làm bộ đếm 5 phút cho hộp thư, định nghĩa rõ loại thời gian; không vô tình đổi đấu giá nếu task không cần. |
| Lỗi cũ từng thấy, hiện đã xử lý trong bản smoke cuối | Chữ trên biển ngược, nhãn world phóng to, NullReference `textContainer`, TMP thiếu font/glyph. | Sửa mặt biển/nhãn, TMP Essentials/FarmFont, `rectTransform`, `XU`; build/smoke cuối không còn log lỗi tương ứng. | Không tái sử dụng `textContainer`; kiểm ảnh sau mọi thay đổi UI. |

Không có crash runtime còn tồn tại đã được xác nhận từ log smoke cuối. Những vấn đề ngoài smoke và quan sát ảnh: **CHƯA XÁC MINH**.

# 9. NEXT TASK

**Task được user giao nhưng chưa thi hành:** triển khai toàn bộ kế hoạch “Cập nhật nông trại, đơn hàng và chế độ sáng tạo để kiểm thử” đã được người dùng yêu cầu implement. Lượt implementation trước bị ngắt sau lời báo bắt đầu, trước khi sửa file. Các con số/quy tắc sau là **đặc tả mục tiêu**, không phải trạng thái hiện tại.

1. **Hotbar + cân bằng:** E chỉ cày với slot 5, gieo với slot 1–3, tưới với slot 6, thu hoạch với slot 7; slot sai chỉ gợi ý. Cây 120/180/300 giây khi ẩm, khô 20%; gói 5 hạt giá 20/40/75, sản phẩm bán 8/18/32. Cần cập nhật builder **và** Crop assets, Shop, Inventory, FarmPlot, Expansion, HUD/hint và smoke.
2. **Nước:** hồ refill bình 8/16/24 theo tier, mỗi ô một đơn vị; mưa không tốn. Một trạm/vùng đất đã mở, từ LV2, giá 600/900/1200/1500, bồn 32, nạp từ bình mang ở hồ, tự tưới ô trong bán kính 6m khi ẩm <20%. Cần đặt object/`IInteractable`, hệ thống tick/pause/sleep, UI và save.
3. **Craft & mailbox:** bàn/hộp thư trước nhà; JSON craft nhiều input → 4 item mới: Bó nông sản = 2 lúa mì+1 cà chua; Gói đậu = 2 đậu nành+1 lúa mì; Giỏ táo = 3 táo+1 ván; Đèn thủ công = 2 ván+1 kim loại. Hai công thức đầu mở sẵn; món sau chỉ mở khi nguồn nguyên liệu tương ứng khả dụng. Hai đơn random khả thi/ngày (một craft, một nông sản/chế biến); giao đủ một lần bằng E lấy 150% giá bán thường + XP; hết hạn ngày sau không mất đồ. Đổi **một** đơn mỗi 5 phút chơi thực (không pause/ngủ), chọn đơn khác có thể làm. Số đơn hoàn thành mở bánh mì 2, phô mai 4, nước táo 6; flour sẵn, ván/metal vẫn theo đảo/bản vẽ. Bảng craft không thay máy queue cũ. Giá bán cụ thể của 4 item craft và XP/order **CHƯA CHỐT bằng user**, nên cần quyết định nội bộ hợp lý, hiển thị rõ, giữ tổng thưởng lớn hơn giá nguyên liệu. Inventory phải mở từ 16 lên 20 ID và có cuộn, không đổi ID 0–15.
4. **Di chuyển + creative:** sửa tiếp đất/mép bậc/dốc, nhảy có buffer ngắn, giới hạn tốc độ rơi, respawn tại đảo đang ở; flight vẫn va chạm. Nút “Chế độ sáng tạo” ở main menu, dùng bản sao RAM của save hiện có (nếu không có thì mặc định), Tab/cổng đi 4 đảo ngay LV1, F8 bật bay, WASD/Space lên/Ctrl xuống/Shift nhanh. Không vô hạn xu/vật phẩm, không bỏ gate của gameplay khác. Badge sáng tạo, vô hiệu Save, rời mode bỏ thay đổi và mở normal phải tải lại save; **không** ghi file lưu khi test.
5. **Migration + release:** SaveData v5 thêm nước/pump/4 item mới/đơn/reroll/unlock recipe; đọc v2–v4, giữ công thức người chơi cũ từng dùng. Cập nhật `BuildSmokeCheck`, docs, build Windows, kiểm ảnh/UI, ZIP Windows+Unity, đồng bộ GitHub `main` theo uỷ quyền trước đây. **Chỉ làm bước release sau khi code và test đúng**.

**Bước đầu tiên nên thực hiện:** kiểm `git status` tại `D:\GAME_NongTrai\Nongtrai` và so source với Unity root; đọc các file mục 4, đặc biệt builder/wiring, `FarmPlot`, `FarmExpansion`, `FarmInventory`, `FarmSave`, `BuildSmokeCheck`. Chia thay đổi theo hệ thống và sửa test assertion cũ đồng thời với luật chơi mới. Tránh build khi Unity Editor khác đang mở project. Sau đó compile/build/smoke và chơi thử các ca tương tác thực tế.

**Hoàn thành khi:** tính năng đúng các quy tắc trên; bản save cũ tải được và creative không đổi file save; mode thường vẫn gate LV; Windows build thành công; smoke mới qua; ảnh không chồng chữ/ô ở ít nhất 1280×720 và 1920×1080; ZIP mới và GitHub cùng source/build đã kiểm tra. Các tiêu chí chưa được kiểm tra thực tế trong bản hiện tại.

# 10. HOW TO RUN / TEST

## Chạy và mở Editor

- Chạy Windows: `D:\GAME_NongTrai\Builds\Windows\NongTrai.exe` cùng toàn bộ thư mục `Builds\Windows`. ZIP chạy mới nhất hiện là `D:\GAME_NongTrai\DongGoi\NongTrai-Islands-Windows.zip`; source ZIP mới nhất `D:\GAME_NongTrai\DongGoi\NongTrai-Islands-Unity.zip`. Các ZIP khác mang tên cũ là bản cũ.
- Unity Hub → Add project from disk → `D:\GAME_NongTrai` → Unity `6000.3.22f1` → scene `Assets/Farm/Scenes/Farm.unity` → Play. Git clone `Nongtrai` là bản sao mã, không phải projectPath đang build.
- Game tự tải `%USERPROFILE%\AppData\LocalLow\Nong Trai Studio\Nong Trai - First Harvest\farm-manual-save.json` nếu có. **Không xóa bản lưu người dùng để test**; smoke có `pathOverride` trong `Application.temporaryCachePath`.

## Build và smoke hiện có

Đóng Unity Editor khác đang mở cùng project. Trong PowerShell tại `D:\GAME_NongTrai`:

```powershell
& 'D:\Unity\Editors\6000.3.22f1\Editor\Unity.exe' -batchmode -nographics -quit -projectPath 'D:\GAME_NongTrai' -executeMethod NongTrai.Editor.FarmProjectBuilder.BuildWindows -logFile 'D:\GAME_NongTrai\Logs\build-next.log'
```

`BuildWindows` **dựng lại và ghi đè scene/asset** rồi build Development Windows vào `Builds\Windows`; nếu đã sửa scene thủ công, chuyển sửa đó vào builder trước. Khi build xong kiểm `FARM_M1_BUILD_OK` và không có compile/build exception. Smoke hiện tại:

```powershell
& 'D:\GAME_NongTrai\Builds\Windows\NongTrai.exe' -farmSmokeCheck -screen-fullscreen 0 -screen-width 1280 -screen-height 720 -force-d3d11 -logFile 'D:\GAME_NongTrai\Logs\smoke-next.log'
```

Kiểm `FARM_*_OK`, `Exception`, `Error`, `not found` trong log. Test có thể tạo ảnh `*-preview.png` ở `Builds\Windows`; xem trực quan menu, túi, các biển/nhân vật. Sau đổi luật khô/tưới/giá, sửa các assertion cũ của `BuildSmokeCheck` trước khi dùng nó làm tiêu chí pass. Cần thêm test creative: normal LV1 không đến Đảo Thần Bí/Công Nghiệp; creative LV1 đến đủ đảo; fly/va chạm; bỏ mode không đổi hash của save gốc. Kiểm thao tác tay tại hồ, trạm, bàn craft, hộp thư và save migration; smoke hiện tại **chưa** bao phủ chúng.

## Git/package

- Git repo: `D:\GAME_NongTrai\Nongtrai`, remote `https://github.com/NguyenHuuThinhyy/Nongtrai.git`, nhánh `main`, commit hiện `1cc34cc` và `origin/main` trùng. Root Unity project không phải Git repo. Sau khi thay source root cần đồng bộ `Assets`, `Packages`, `ProjectSettings`, `README.md`, `CHOI_GAME.md` vào clone rồi kiểm diff/commit/push; không đưa `Library`, `Temp`, `Logs`, `Builds` vào Git.
- Gói source cần `Assets`, `Packages`, `ProjectSettings`, docs, `.gitignore`, `prompt.MD`, ảnh tham chiếu. Gói Windows cần EXE, `NongTrai_Data`, `MonoBleedingEdge`, D3D12/DLL kèm; ảnh preview/log không cần. Gói Islands hiện có SHA-256: Unity `A32D946CA3C2918C06AD6C7EFBD8F288520188025054F8B2600B00BF2613E389`; Windows `A65C31E165F4F330450F444C364AF3ECD94B36B16D4E9CB92212F57A90B4F12E`.

# 11. ENVIRONMENT

- OS đã xác minh: **Microsoft Windows 11 Home Single Language**, version `10.0.26200`, build `26200`; shell PowerShell.
- Unity Editor đã dùng: `D:\Unity\Editors\6000.3.22f1\Editor\Unity.exe`; `ProjectSettings/ProjectVersion.txt` khớp `6000.3.22f1` revision `1c726e1fb402`.
- Build target trong builder: `StandaloneWindows64`, `BuildOptions.Development`; Unity Linear color space, URP, Input System mới, layer 8 = Player; 1600×900 mặc định, FullScreenWindow, Canvas ref 1920×1080.
- Packages từ manifest: Cinemachine `3.1.5`, Input System `1.20.0`, URP `17.3.0`, uGUI `2.0.0`; TMP Essentials asset nằm trong project. Git đã xác minh `2.53.0.windows.3`. Phiên bản .NET độc lập bên ngoài Unity: **CHƯA XÁC MINH** và chưa cần cho workflow này.
- Filesystem đã xác minh: project root `D:\GAME_NongTrai`, Git clone `D:\GAME_NongTrai\Nongtrai`; `Assets`/`Packages`/`ProjectSettings` và root docs/reference giống clone trước khi viết handoff; `Builds`, `DongGoi`, `Logs`, `Library` nằm ở root, không track trong clone.

# 12. INSTRUCTIONS FOR NEXT CODEX

1. Đọc toàn bộ file này trước.
2. Kiểm tra code hiện tại trước khi sửa.
3. Không giả định code vẫn giống phiên bản được mô tả nếu repository cho thấy khác.
4. Không rewrite/refactor phần đang chạy ổn nếu task không yêu cầu.
5. Giữ compatibility với hệ thống hiện tại.
6. Trước khi sửa, xác định các file và dependency liên quan.
7. Sau khi sửa, kiểm tra lỗi compile/build/test nếu có thể.
8. Không xóa chức năng hiện có chỉ để giải quyết lỗi mới.
9. Nếu HANDOFF và code thực tế mâu thuẫn, ưu tiên code thực tế và báo rõ sự khác biệt.
10. Tiếp tục từ mục NEXT TASK.

**Ưu tiên đặc biệt:** đây là handoff cho task IMPLEMENT vừa bị ngắt, **không** phải yêu cầu lặp lại lập kế hoạch. Những quy tắc mới ở mục 9 đã được user thống nhất qua các lượt hỏi; hãy thực hiện nhưng kiểm tra source/test thực tế trước. Nếu `CODEX_HANDOFF.md` chỉ có ở Unity root mà không ở Git clone, đó là chủ ý của yêu cầu tạo handoff hiện tại, không phải dấu hiệu mất file source.
