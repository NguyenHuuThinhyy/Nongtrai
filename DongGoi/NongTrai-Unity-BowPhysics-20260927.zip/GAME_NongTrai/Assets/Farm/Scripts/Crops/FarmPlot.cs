using UnityEngine;
namespace NongTrai
{
    public enum PlotState { Untilled, Tilled, Growing, Ready }
    public sealed class FarmPlot : MonoBehaviour, IInteractable
    {
        public int id;
        public PlotState State { get; private set; }
        public CropDefinition Crop { get; private set; }
        public float Moisture { get; private set; }
        public float Growth { get; private set; }
        public bool Mutated { get; private set; }
        Transform plants;
        int stage = -1;
        static Material green, stem;
        Material fruit;
        Renderer[] importedFruitRenderers;
        MaterialPropertyBlock fruitBlock;
        void Start() => Highlight(false);
        string RequiredAction => State==PlotState.Untilled?"chọn Cuốc":State==PlotState.Tilled?"chọn Hạt giống":
            State==PlotState.Ready?"hái tay":"thuê vòi / đặt nước cạnh ruộng";
        public string Description => FarmExpansion.Instance!=null && !FarmExpansion.Instance.IsUnlocked(this)
            ? "Vùng đất chưa mở • [N] Mua đất khi đủ cấp" : State == PlotState.Untilled ? "Đất trống • chọn Cuốc rồi [Chuột trái]" :
            State == PlotState.Tilled ? "Đất đã cày • chọn Hạt giống rồi [Chuột trái]" :
            State == PlotState.Ready ? Crop.displayName + (Mutated?" đột biến":"") + " chín • [Chuột trái] để hái" :
            Crop.displayName + " • " + Mathf.FloorToInt(Growth * 100) + "% • Nước " + Mathf.CeilToInt(Moisture * 100) + "% • "+RequiredAction;
        public string InteractionHint => Description;
        public bool CanInteract(FarmPlayer player) => true;
        public void Interact(PlayerInteraction actor)
        { actor.Say(FarmExpansion.Instance==null?Work(actor.field.Current,out _):FarmExpansion.Instance.Work(this)); }
        public void SetHighlighted(bool selected) { Highlight(selected);InteractionOutline.Set(this,selected); }
        public string Work(CropDefinition selected, out int harvested)
        {
            harvested = 0;
            if (State == PlotState.Untilled) { State = PlotState.Tilled; Refresh(); return "Đã cày đất. Nhấn chuột trái lần nữa để gieo " + selected.displayName; }
            if (State == PlotState.Tilled)
            {
                Crop = selected; State = PlotState.Growing; Growth = 0; Moisture = 0;
                fruit = Material(Crop.fruitColor); Refresh();
                return "Đã gieo " + Crop.displayName + ". Thuê vòi tự tưới hoặc đặt nước cạnh ruộng để cây lớn nhanh.";
            }
            if (State == PlotState.Growing) { Moisture = 1; Refresh(); return "Đã tưới đầy nước cho " + Crop.displayName; }
            harvested = Crop.yield; string result = "Thu hoạch +" + harvested + " " + Crop.displayName;
            State = PlotState.Tilled; Crop = null; Growth = 0; Moisture = 0;Mutated=false;
            if (fruit != null) Destroy(fruit);
            Refresh(); return result + ". Ô đất sẵn sàng gieo vụ mới.";
        }
        // Cập nhật theo tick từ FieldManager, không chạy Update cho từng ô.
        public void Tick(float seconds)
        {
            if (State != PlotState.Growing) return;
            float wateredSeconds = Mathf.Min(seconds, Moisture * 120);
            float drySeconds = seconds-wateredSeconds;
            Moisture = Mathf.Max(0, Moisture - seconds / 120);
            Growth = Mathf.Min(1, Growth + (wateredSeconds+drySeconds*.2f) / Crop.growthSeconds);
            if (Growth >= 1) State = PlotState.Ready;
            Refresh();
        }
        public void AddMoisture(float amount)
        {
            if(State!=PlotState.Growing || amount<=0) return;
            Moisture=Mathf.Clamp01(Moisture+amount);
            Highlight(false);
        }
        public bool ApplyFertilizer()
        {
            if(State!=PlotState.Growing)return false;
            Moisture=Mathf.Min(1,Moisture+.35f);
            Growth=Mathf.Min(1,Growth+.12f);
            if(Crop.specialProduct<0&&!Mutated&&Random.value<.08f)Mutated=true;
            if(Growth>=1)State=PlotState.Ready;
            Refresh();return true;
        }
        public void Restore(PlotState state,CropDefinition crop,float growth,float moisture,bool mutated=false)
        {
            State=state; Crop=crop; Growth=Mathf.Clamp01(growth); Moisture=Mathf.Clamp01(moisture);Mutated=mutated;
            if(fruit!=null) Destroy(fruit);
            fruit=crop==null?null:Material(crop.fruitColor);
            stage=-99;Refresh();
        }
        void Update()
        {
            if(!Mutated||fruit==null)return;
            var glow=Color.HSVToRGB(Mathf.Repeat(Time.time*.22f+id*.08f,1),.75f,1);
            fruit.color=glow;fruit.SetColor("_EmissionColor",glow*2.2f);fruit.EnableKeyword("_EMISSION");
            if(importedFruitRenderers!=null)
            {if(fruitBlock==null)fruitBlock=new MaterialPropertyBlock();foreach(var renderer in importedFruitRenderers)
             {renderer.GetPropertyBlock(fruitBlock);fruitBlock.SetColor("_BaseColor",glow);fruitBlock.SetColor("_Color",glow);fruitBlock.SetColor("_EmissionColor",glow*2.2f);renderer.SetPropertyBlock(fruitBlock);}}
        }
        public void Highlight(bool value)
        {
            var block = new MaterialPropertyBlock();
            GetComponent<Renderer>().GetPropertyBlock(block);
            bool locked=FarmExpansion.Instance!=null && !FarmExpansion.Instance.IsUnlocked(this);
            block.SetColor("_BaseColor", locked ? new Color(.27f,.28f,.29f) : value ? new Color(0.65f, 0.49f, 0.22f) :
                State == PlotState.Untilled ? new Color(0.40f, 0.30f, 0.18f) : Moisture > 0 ? new Color(0.23f, 0.14f, 0.08f) : new Color(0.38f, 0.23f, 0.12f));
            GetComponent<Renderer>().SetPropertyBlock(block);
        }
        void Refresh()
        {
            Highlight(false);
            int next = Crop == null ? -1 : Mathf.Min(3, Mathf.FloorToInt(Growth * 4));
            if (next == stage) return;
            stage = next;
            importedFruitRenderers=null;
            if (plants != null) { plants.gameObject.SetActive(false); Destroy(plants.gameObject); }
            if (Crop == null) return;
            if (green == null) { green = Material(new Color(0.19f, 0.46f, 0.12f)); stem = Material(new Color(0.35f, 0.54f, 0.12f)); }
            plants = new GameObject("Crop stage " + stage).transform;
            plants.SetParent(transform, false);
            // Giữ kích thước cây theo mét, độc lập với tỷ lệ của ô đất.
            plants.localScale = new Vector3(1 / transform.localScale.x, 1 / transform.localScale.y, 1 / transform.localScale.z);
            plants.gameObject.AddComponent<CropStageAnimation>();
            if(Crop.displayName=="Lúa mì"&&Crop.stageVisuals!=null&&Crop.stageVisuals.Length>stage&&Crop.stageVisuals[stage]!=null)
            {
                for(int x=0;x<4;x++)for(int z=0;z<3;z++)
                {
                    var stalk=Instantiate(Crop.stageVisuals[stage],plants,false);
                    stalk.transform.localPosition+=new Vector3(-.62f+x*.42f,.12f,-.42f+z*.42f);
                    // The prefab is already normalized; retain its authored scale.
                }
                return;
            }
            float height = 0.18f + stage * 0.23f;
            for (int x = -1; x <= 1; x += 2)
                for (int z = -1; z <= 1; z += 2)
                {
                    Vector3 p = new Vector3(x * 0.45f, 0.12f, z * 0.45f);
                    Part(PrimitiveType.Cylinder, p + Vector3.up * height / 2, new Vector3(0.07f, height / 2, 0.07f), stem);
                    for (int side = -1; side <= 1; side += 2)
                    {
                        var leaf = Part(PrimitiveType.Sphere, p + new Vector3(side * height * 0.22f, height * 0.6f, 0), new Vector3(height * 0.65f, 0.07f, height * 0.25f), green);
                        leaf.localRotation = Quaternion.Euler(0, 25 * z, side * 30);
                    }
                    if (stage >= 2)
                    {
                        if(Crop.displayName=="Bí ngô")
                        {
                            if(Crop.fruitVisual!=null)
                            {
                                var pumpkin=Instantiate(Crop.fruitVisual,plants,false);pumpkin.transform.localPosition+=p;
                                var renderers=pumpkin.GetComponentsInChildren<Renderer>(true);
                                if(importedFruitRenderers==null)importedFruitRenderers=renderers;else importedFruitRenderers=Merge(importedFruitRenderers,renderers);
                            }
                            else Part(PrimitiveType.Sphere,p+new Vector3(0,.26f,0),new Vector3(.47f,.31f,.43f),fruit);
                        }
                        else if(Crop.displayName=="Dâu ruộng")
                        {for(int berry=0;berry<3;berry++)Part(PrimitiveType.Sphere,p+new Vector3((berry-1)*.18f,.20f+berry*.05f,.16f),new Vector3(.13f,.15f,.13f),fruit);}
                        else if(Crop.displayName=="Hướng dương")
                        {Part(PrimitiveType.Cylinder,p+new Vector3(0,height*.8f,0),new Vector3(.07f,height*.7f,.07f),stem);
                         Part(PrimitiveType.Sphere,p+Vector3.up*(height*1.5f),new Vector3(.34f,.34f,.13f),fruit);}
                        else Part(PrimitiveType.Sphere, p + Vector3.up * height, new Vector3(0.22f, Crop.displayName == "Lúa mì" ? 0.40f : 0.22f, 0.22f), fruit);
                    }
                }
        }
        Transform Part(PrimitiveType type, Vector3 p, Vector3 s, Material material)
        {
            var go = GameObject.CreatePrimitive(type); Destroy(go.GetComponent<Collider>());
            go.transform.SetParent(plants, false); go.transform.localPosition = p; go.transform.localScale = s;
            go.GetComponent<Renderer>().sharedMaterial = material; return go.transform;
        }
        static Renderer[] Merge(Renderer[] a,Renderer[] b)
        {var merged=new Renderer[a.Length+b.Length];System.Array.Copy(a,merged,a.Length);System.Array.Copy(b,0,merged,a.Length,b.Length);return merged;}
        static Material Material(Color color) { var m = new Material(Shader.Find("Universal Render Pipeline/Lit")); m.color = color; m.enableInstancing = true; return m; }
        void OnDestroy() { if (fruit != null) Destroy(fruit); }
    }
}
