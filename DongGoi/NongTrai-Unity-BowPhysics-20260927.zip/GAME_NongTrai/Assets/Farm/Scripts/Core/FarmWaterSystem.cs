using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

namespace NongTrai
{
    [Serializable] public sealed class WaterState
    {
        public int canWater;
        public int[] stationWater;
        public bool[] stationBuilt;
        public PortableSprinklerRecord[] portable;
        public bool pendingPortable;
        public int lastPortablePurchaseDay,rentedToday;
        public int spareCans,pumpStock;
        public float pumpProgress;
    }
    [Serializable] public sealed class PortableSprinklerRecord {public Vector3 position;public float remaining;}

    public sealed class FarmWaterSystem : MonoBehaviour
    {
        public static FarmWaterSystem Instance { get; private set; }
        public FarmHud hud;
        public FarmShop shop;
        public FarmExpansion expansion;
        public FieldManager field;
        public int CanWater { get; private set; }
        public int CanCapacity => expansion==null?8:new[]{8,16,24}[Mathf.Clamp(expansion.ToolTiers[1],0,2)];
        public const int MaxCarriedCans=3;
        public const float PumpIntervalSeconds=600f;
        public int SpareCans {get;private set;}
        public int CarriedCans=>SpareCans+(CanWater>0?1:0);
        public int PumpStock {get;private set;}=1;
        public float PumpProgress {get;private set;}
        public float PumpRemaining=>PumpStock>=3?0:Mathf.Max(0,PumpIntervalSeconds-PumpProgress);
        public GameObject Panel { get; private set; }
        public readonly int[] StationWater=new int[4];
        public readonly bool[] StationBuilt=new bool[4];
        readonly int[] prices={600,900,1200,1500};
        readonly IrrigationStation[] stations=new IrrigationStation[4];
        readonly List<IrrigationStation> portable=new List<IrrigationStation>();
        public bool PendingPlacement => AdventureBag.Instance!=null&&AdventureBag.Instance.Item==56&&shop.inventory.Count(56)>0;
        public int ConsumedFrame {get;private set;}=-1;
        public int PortableCount=>portable.Count;
        public const int PortablePrice=350;
        int lastPortablePurchaseDay,rentedToday;
        public int RentalLimit=>3+(expansion.Level>=3?1:0)+(expansion.Level>=5?1:0)+(expansion.Level>=7?1:0);
        public int RentedToday {get{RefreshRentalDay();return rentedToday;}}
        static float GameSeconds=>TimeManager.Instance==null?0:((TimeManager.Instance.Day-1)+TimeManager.Instance.NormalizedTime)*TimeManager.DayLengthSeconds;
        void RefreshRentalDay(){int day=TimeManager.Instance==null?1:TimeManager.Instance.Day;if(lastPortablePurchaseDay!=day){lastPortablePurchaseDay=day;rentedToday=0;}}
        Text status,feedback;
        static readonly Vector3[] WaterNeighbours={Vector3.left,Vector3.right,Vector3.forward,Vector3.back};
        float tick;

        void Awake() => Instance=this;
        void Start()
        {
            CreatePanel();
            CreateStations();
            CreateWaterSource();
            hud.player.PauseChanged+=OnPause;
        }
        void OnDestroy() { if(Instance==this) Instance=null;if(hud!=null && hud.player!=null) hud.player.PauseChanged-=OnPause; }
        void OnPause(bool paused) { if(!paused && Panel!=null) Panel.SetActive(false); }
        void CreatePanel()
        {
            Panel=FarmUi.Panel(hud.transform,"Quản lý nước",new Vector2(930,720));
            FarmUi.TmpLabel(Panel.transform,"NƯỚC & TRẠM TƯỚI",new Vector2(30,-25),new Vector2(870,55),30);
            status=FarmUi.Label(Panel.transform,"",new Vector2(30,-90),new Vector2(870,100),21);
            FarmUi.Button(Panel.transform,"Thuê vòi tự tưới • 350 xu • hoạt động 1 ngày game",
                new Vector2(30,-215),new Vector2(870,68),BuyPortable);
            FarmUi.Label(Panel.transform,"Chọn XÔ NƯỚC có sẵn: chuột trái múc khi rỗng, chuột trái đặt nước khi đầy.\nVòi thuê tự tưới bán kính 6 m, không cần nạp; hết hạn sau 1 ngày game.\nThuê tối đa 3/ngày; LV3/5/7 mở 4/5/6 vòi mỗi ngày.",new Vector2(30,-310),new Vector2(870,150),22);
            feedback=FarmUi.Label(Panel.transform,"Chọn vòi trong túi rồi trái vào đất để đặt. Chuột phải thu hồi và kết thúc thuê.",new Vector2(30,-545),new Vector2(870,55),19);
            FarmUi.Button(Panel.transform,"Trở lại game",new Vector2(30,-630),new Vector2(870,55),hud.Resume);
            FarmUi.Label(Panel.transform,"Có thể nhấn ESC để đóng bảng",new Vector2(625,-22),new Vector2(270,36),17);
            Panel.SetActive(false);
        }
        void CreateStations()
        {
            var plots=FindObjectsByType<FarmPlot>(FindObjectsSortMode.None);
            for(int region=0;region<4;region++)
            {
                Vector3 center=Vector3.zero;int count=0;
                foreach(var plot in plots) if(expansion.RegionFor(plot)==region) { center+=plot.transform.position;count++; }
                if(count>0) center/=count;
                center+=new Vector3(0,1.05f,0);
                var go=new GameObject("Trạm tưới vùng "+(region+1)+" - E");go.transform.position=center;
                var collider=go.AddComponent<CapsuleCollider>();collider.center=new Vector3(0,.55f,0);collider.radius=.8f;collider.height=3.4f;
                RuntimePart(go.transform,"Bệ trạm",PrimitiveType.Cylinder,new Vector3(0,-.75f,0),new Vector3(1.15f,.22f,1.15f),new Color(.22f,.36f,.40f));
                RuntimePart(go.transform,"Bồn nước",PrimitiveType.Cylinder,new Vector3(0,0,0),new Vector3(.72f,.72f,.72f),new Color(.25f,.58f,.72f));
                RuntimePart(go.transform,"Nắp bồn",PrimitiveType.Sphere,new Vector3(0,.72f,0),new Vector3(.76f,.20f,.76f),new Color(.55f,.83f,.92f));
                RuntimePart(go.transform,"Cột phun",PrimitiveType.Cylinder,new Vector3(0,1.35f,0),new Vector3(.13f,.75f,.13f),new Color(.66f,.72f,.73f));
                var arms=new GameObject("Cánh tay tưới").transform;arms.SetParent(go.transform,false);arms.localPosition=new Vector3(0,2.05f,0);
                RuntimePart(arms,"Ống ngang",PrimitiveType.Cube,Vector3.zero,new Vector3(3.4f,.11f,.11f),new Color(.38f,.72f,.86f));
                RuntimePart(arms,"Ống dọc",PrimitiveType.Cube,Vector3.zero,new Vector3(.11f,.11f,3.4f),new Color(.38f,.72f,.86f));
                var station=go.AddComponent<IrrigationStation>();station.region=region;stations[region]=station;
                station.InitializeVisuals(arms);
                go.SetActive(false);
            }
        }
        static GameObject RuntimePart(Transform parent,string name,PrimitiveType type,Vector3 local,Vector3 scale,Color color)
        {
            var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(parent,false);go.transform.localPosition=local;go.transform.localScale=scale;
            Destroy(go.GetComponent<Collider>());var material=new Material(Shader.Find("Universal Render Pipeline/Lit"));material.color=color;go.GetComponent<Renderer>().material=material;return go;
        }
        void CreateWaterSource()
        {
            var source=new GameObject("Máy bơm lấy nước hồ - E");source.transform.position=new Vector3(27.5f,.75f,-11);
            var sourceCollider=source.AddComponent<CapsuleCollider>();sourceCollider.center=new Vector3(0,.55f,0);sourceCollider.radius=1.1f;sourceCollider.height=2.5f;
            RuntimePart(source.transform,"Chân bơm",PrimitiveType.Cylinder,new Vector3(0,-.45f,0),new Vector3(.68f,.18f,.68f),new Color(.24f,.42f,.48f));
            RuntimePart(source.transform,"Thân bơm",PrimitiveType.Cylinder,new Vector3(0,.38f,0),new Vector3(.40f,.85f,.40f),new Color(.30f,.62f,.72f));
            RuntimePart(source.transform,"Đầu bơm",PrimitiveType.Sphere,new Vector3(0,1.18f,0),new Vector3(.46f,.28f,.46f),new Color(.55f,.83f,.92f));
            RuntimePart(source.transform,"Vòi bơm",PrimitiveType.Cube,new Vector3(.52f,.82f,0),new Vector3(.72f,.13f,.18f),new Color(.66f,.72f,.73f));
            RuntimePart(source.transform,"Miệng vòi",PrimitiveType.Cylinder,new Vector3(.88f,.68f,0),new Vector3(.16f,.25f,.16f),new Color(.35f,.70f,.84f));
            var stream=new GameObject("Dòng hạt nước xanh từ vòi bơm");stream.transform.SetParent(source.transform,false);
            stream.transform.localPosition=new Vector3(.91f,.54f,0);
            var particles=stream.AddComponent<ParticleSystem>();var main=particles.main;
            main.startLifetime=.65f;main.startSpeed=.35f;main.startSize=.09f;main.maxParticles=180;
            main.startColor=new Color(.24f,.75f,1,1);main.gravityModifier=.35f;
            var emission=particles.emission;emission.rateOverTime=85;
            var shape=particles.shape;shape.shapeType=ParticleSystemShapeType.Cone;shape.angle=8;shape.radius=.045f;
            stream.transform.localRotation=Quaternion.Euler(115,0,0);
            var visual=source.AddComponent<WaterPumpVisual>();visual.particles=particles;
            var renderer=particles.GetComponent<ParticleSystemRenderer>();
            var droplet=GameObject.CreatePrimitive(PrimitiveType.Sphere);renderer.renderMode=ParticleSystemRenderMode.Mesh;
            renderer.mesh=droplet.GetComponent<MeshFilter>().sharedMesh;Destroy(droplet);
            var waterShader=Shader.Find("Universal Render Pipeline/Unlit");if(waterShader==null)waterShader=Shader.Find("Universal Render Pipeline/Lit");
            var streamMaterial=new Material(waterShader);streamMaterial.color=new Color(.16f,.70f,1);
            renderer.material=streamMaterial;
            var handle=RuntimePart(source.transform,"Tay bơm",PrimitiveType.Cube,new Vector3(-.10f,1.52f,0),new Vector3(.12f,.70f,.14f),new Color(.76f,.53f,.25f));
            handle.transform.localRotation=Quaternion.Euler(0,0,-58);
            RuntimePart(source.transform,"Xô nước",PrimitiveType.Cylinder,new Vector3(1.05f,-.33f,0),new Vector3(.38f,.42f,.38f),new Color(.28f,.62f,.82f));
            source.AddComponent<WaterSource>();
            var board=GameObject.CreatePrimitive(PrimitiveType.Cube);
            board.name="Bảng quản lý nước - E";board.transform.position=new Vector3(25.4f,1.45f,-10.4f);
            board.transform.localScale=new Vector3(2.4f,1.15f,.18f);
            var boardMaterial=new Material(Shader.Find("Universal Render Pipeline/Lit"));
            boardMaterial.color=new Color(.28f,.42f,.32f);board.GetComponent<Renderer>().material=boardMaterial;
            RuntimePart(board.transform,"Biểu tượng giọt nước",PrimitiveType.Sphere,new Vector3(0,0,-.7f),new Vector3(.18f,.28f,.12f),new Color(.35f,.78f,1));
            board.AddComponent<WaterManagementBoard>();
        }
        public void Open()
        {
            hud.ShowOverlay(Panel);Refresh();
        }
        public int RefillCan()
        {
            // A saved game can have only spare cans and an empty active can.
            // Move one spare into the active slot before checking the carry limit.
            LoadSpareIfEmpty();
            if(PumpStock<=0||CarriedCans>=MaxCarriedCans&&CanWater>=CanCapacity)return 0;
            int added;
            if(CanWater<CanCapacity){added=CanCapacity-CanWater;CanWater=CanCapacity;}
            else {added=CanCapacity;SpareCans++;}
            PumpStock--;Refresh();return added;
        }
        public void FillFromRiver(){CanWater=CanCapacity;SpareCans=0;Refresh();}
        public void EmptyBucket(){CanWater=0;SpareCans=0;Refresh();}
        public bool UseReserveFlask(FarmInventory inventory)
        {
            if(inventory==null||inventory.Count(64)<1||CanWater>=CanCapacity)return false;
            if(!inventory.Remove(64,1))return false;
            inventory.Add(71,1);
            CanWater=Mathf.Min(CanCapacity,CanWater+8);
            Refresh();return true;
        }
        void LoadSpareIfEmpty()
        {if(CanWater<=0&&SpareCans>0){SpareCans--;CanWater=CanCapacity;}}
        public void AdvancePump(float seconds)
        {
            if(seconds<=0||PumpStock>=3)return;
            PumpProgress+=seconds;
            while(PumpProgress>=PumpIntervalSeconds&&PumpStock<3)
            {PumpProgress-=PumpIntervalSeconds;PumpStock++;Refresh();}
            if(PumpStock>=3)PumpProgress=0;
        }
        public bool Consume(int amount)
        {
            if(amount<=0) return true;
            LoadSpareIfEmpty();
            if(CanWater<amount) return false;
            CanWater-=amount;LoadSpareIfEmpty();Refresh();return true;
        }
        public bool BuyStation(int region)
        {
            if(region<0 || region>=4) return false;
            if(StationBuilt[region]) { Say("Trạm vùng "+(region+1)+" đã được xây.");return false; }
            if(expansion.Level<2) { Say("Cần đạt LV2 để xây trạm tưới.");return false; }
            if(!expansion.UnlockedRegions[region]) { Say("Cần mở vùng đất "+(region+1)+" trước.");return false; }
            if(!shop.TrySpend(prices[region])) { Say("Không đủ "+prices[region]+" xu.");return false; }
            StationBuilt[region]=true;StationWater[region]=8;stations[region].gameObject.SetActive(true);
            Say("Đã xây trạm vùng "+(region+1)+" • tự tưới, không cần nạp nước.");FarmAudio.Instance?.Play(FarmAudio.Cue.Buy);return true;
        }
        public int TransferToStation(int region)
        {
            if(region<0 || region>=4 || !StationBuilt[region]) return 0;
            LoadSpareIfEmpty();
            int moved=Mathf.Min(CanWater,32-StationWater[region]);
            CanWater-=moved;StationWater[region]+=moved;LoadSpareIfEmpty();Refresh();return moved;
        }
        public void BuyPortable()
        {
            RefreshRentalDay();
            if(rentedToday>=RentalLimit){Say("Đã thuê đủ "+RentalLimit+" vòi hôm nay. LV3/5/7 mở thêm lượt.");return;}
            if(AdventureBag.Instance!=null&&AdventureBag.Instance.Space(56)<1){Say("Túi đầy.");return;}
            if(!shop.TrySpend(PortablePrice)){Say("Cần "+PortablePrice+" xu để thuê.");return;}
            rentedToday++;shop.inventory.Add(56,1);Say("Đã thuê vòi "+rentedToday+"/"+RentalLimit+" hôm nay. Chọn vòi rồi trái vào đất để đặt.");
        }
        IrrigationStation PlacePortable(Vector3 point,float remaining)
        {
            var clone=Instantiate(stations[0].gameObject,point+Vector3.up*1.05f,Quaternion.identity);
            clone.name="Vòi phun di động";clone.SetActive(true);
            var result=clone.GetComponent<IrrigationStation>();result.portable=true;result.remainingSeconds=Mathf.Max(0,remaining);result.rentalExpiresAt=GameSeconds+result.remainingSeconds;
            portable.Add(result);return result;
        }
        public bool TryPlacePortable(Vector3 point)
        {if(shop.inventory.Count(56)<1||!shop.inventory.Remove(56,1))return false;PlacePortable(point,TimeManager.DayLengthSeconds);return true;}
        public bool DismantlePortable(IrrigationStation sprinkler)
        {if(sprinkler==null||!sprinkler.portable||!portable.Remove(sprinkler))return false;
         sprinkler.gameObject.SetActive(false);Destroy(sprinkler.gameObject);Refresh();return true;}
        public bool RefillPortable(IrrigationStation sprinkler)=>sprinkler!=null&&sprinkler.portable&&sprinkler.remainingSeconds>0;
        void Update()
        {
            if(hud==null || hud.player.Paused) return;
            AdvancePump(Time.deltaTime);
            if(Panel!=null&&Panel.activeSelf&&Time.frameCount%30==0)Refresh();
            if(PendingPlacement&&Mouse.current!=null&&Mouse.current.leftButton.wasPressedThisFrame&&!FarmHud.WorldClickSuppressed)
            {
                ConsumedFrame=Time.frameCount;
                if(Camera.main!=null&&FarmAim.Hit(Camera.main,out var hit)&&hit.normal.y>.65f&&
                    Vector3.Distance(hit.point,hud.player.transform.position)<6f)
                {if(TryPlacePortable(hit.point))hud.Notify("Đã đặt vòi thuê • tự tưới trong vòng xanh, không cần nạp nước.");}
                else hud.Notify("Hãy ngắm mặt đất phẳng gần nhân vật để đặt vòi phun.");
            }
            for(int i=portable.Count-1;i>=0;i--)
            {if(portable[i]==null){portable.RemoveAt(i);continue;}
             portable[i].remainingSeconds=Mathf.Max(0,portable[i].rentalExpiresAt-GameSeconds);
             if(portable[i].remainingSeconds<=0){Destroy(portable[i].gameObject);portable.RemoveAt(i);}}
            tick+=Time.deltaTime;if(tick<1) return;tick=0;
            var plots=FindObjectsByType<FarmPlot>(FindObjectsSortMode.None);
            for(int region=0;region<4;region++)
            {
                if(!StationBuilt[region] || stations[region]==null) continue;
                foreach(var plot in plots)
                {
                    if(expansion.RegionFor(plot)!=region || plot.State!=PlotState.Growing || plot.Moisture>=.2f) continue;
                    if(Vector3.Distance(plot.transform.position,stations[region].transform.position)>6f) continue;
                    plot.AddMoisture(.55f);
                }
            }
            // A placed water source can also irrigate the immediately adjacent farm plots.
            foreach(var plot in plots)if(plot.State==PlotState.Growing&&plot.Moisture<.6f&&FarmVoxelWater.Instance!=null)
                foreach(var direction in WaterNeighbours)
                    if(FarmVoxelWater.Instance.IsSubmerged(plot.transform.position+direction*1.8f+Vector3.up*.25f)){plot.AddMoisture(.35f);break;}
            foreach(var sprinkler in portable)if(sprinkler!=null&&sprinkler.remainingSeconds>0)
            {
                foreach(var plot in plots)if(plot.State==PlotState.Growing&&plot.Moisture<.6f&&
                    Vector3.Distance(plot.transform.position,sprinkler.transform.position)<6.2f)plot.AddMoisture(.35f);
                foreach(var tree in FindObjectsByType<FruitTree>(FindObjectsSortMode.None))if(
                    Vector3.Distance(tree.transform.position,sprinkler.transform.position)<6.2f)tree.AdvanceWater(1);
            }
        }
        public WaterState Snapshot()
        {var records=new List<PortableSprinklerRecord>();foreach(var item in portable)if(item!=null)
            records.Add(new PortableSprinklerRecord{position=item.transform.position-Vector3.up*1.05f,remaining=item.remainingSeconds});
         return new WaterState { canWater=CanWater,stationWater=(int[])StationWater.Clone(),
             stationBuilt=(bool[])StationBuilt.Clone(),portable=records.ToArray(),pendingPortable=false,lastPortablePurchaseDay=lastPortablePurchaseDay,rentedToday=rentedToday,
             spareCans=SpareCans,pumpStock=PumpStock,pumpProgress=PumpProgress };}
        public void Restore(WaterState state,bool legacy=false)
        {
            foreach(var item in portable)if(item!=null){item.gameObject.SetActive(false);Destroy(item.gameObject);}portable.Clear();
            lastPortablePurchaseDay=state==null?0:state.lastPortablePurchaseDay;rentedToday=state==null?0:Mathf.Max(0,state.rentedToday);
            if(state!=null&&state.pendingPortable&&shop.inventory.Count(56)==0)shop.inventory.Add(56,1);
            CanWater=state==null?0:Mathf.Clamp(state.canWater,0,CanCapacity);
            SpareCans=legacy||state==null?0:Mathf.Clamp(state.spareCans,0,MaxCarriedCans-(CanWater>0?1:0));
            PumpStock=legacy||state==null?1:Mathf.Clamp(state.pumpStock,0,3);
            PumpProgress=legacy||state==null?0:Mathf.Clamp(state.pumpProgress,0,PumpIntervalSeconds);
            for(int i=0;i<4;i++)
            {
                StationBuilt[i]=state!=null && state.stationBuilt!=null && i<state.stationBuilt.Length && state.stationBuilt[i];
                StationWater[i]=state!=null && state.stationWater!=null && i<state.stationWater.Length?Mathf.Clamp(state.stationWater[i],0,32):0;
                if(stations[i]!=null) stations[i].gameObject.SetActive(StationBuilt[i]);
            }
            if(state?.portable!=null)foreach(var item in state.portable)PlacePortable(item.position,item.remaining);
            Refresh();
        }
        void Say(string value) { if(feedback!=null) feedback.text=value;hud.Notify(value);Refresh(); }
        void Refresh()
        {
            if(status==null) return;
            status.text="Xô nước: "+(CanWater>0?"ĐẦY":"RỖNG")+" • Vòi đang thuê: "+PortableCount+"\nHôm nay thuê "+RentedToday+"/"+RentalLimit+" • LV3/5/7 mở thêm lượt • Không cần nạp nước";
        }
    }

    public sealed class WaterManagementBoard : MonoBehaviour,IInteractable
    {
        public string InteractionHint => "[Chuột trái] Quản lý nước và mua vòi phun";
        public bool CanInteract(FarmPlayer player) => true;
        public void Interact(PlayerInteraction actor) => FarmWaterSystem.Instance.Open();
        public void SetHighlighted(bool selected) => InteractionOutline.Set(this,selected);
    }

    public sealed class WaterSource : MonoBehaviour,IInteractable
    {
        public string InteractionHint => "[Chuột trái] Thuê vòi tưới tự động";
        public bool CanInteract(FarmPlayer player) => true;
        public void Interact(PlayerInteraction actor)=>FarmWaterSystem.Instance.Open();
        public void SetHighlighted(bool selected) => InteractionOutline.Set(this,selected);
    }

    public sealed class WaterPumpVisual : MonoBehaviour
    {
        public ParticleSystem particles;
        readonly Transform[] beads=new Transform[10];
        void Start()
        {
            var material=new Material(Shader.Find("Universal Render Pipeline/Lit"));material.color=new Color(.12f,.70f,1f);
            for(int i=0;i<beads.Length;i++)
            {var drop=GameObject.CreatePrimitive(PrimitiveType.Sphere);drop.name="Hạt nước vòi "+i;drop.transform.SetParent(transform,false);
             drop.transform.localScale=Vector3.one*.11f;Destroy(drop.GetComponent<Collider>());
             drop.GetComponent<Renderer>().material=material;beads[i]=drop.transform;}
        }
        void Update()
        {
            bool flowing=FarmWaterSystem.Instance!=null&&FarmWaterSystem.Instance.PumpStock>0;
            if(particles!=null){var emission=particles.emission;emission.rateOverTime=flowing?85:18;}
            for(int i=0;i<beads.Length;i++)if(beads[i]!=null)
            {float t=Mathf.Repeat(Time.time*1.8f+i/(float)beads.Length,1);
             beads[i].localPosition=new Vector3(.91f+.13f*t,.54f-.73f*t,.045f*Mathf.Sin(i*3.2f+Time.time*4));
             beads[i].localScale=Vector3.one*(flowing?.12f:.065f);}
        }
    }

    public sealed class IrrigationStation : MonoBehaviour,IInteractable
    {
        public int region;public bool portable;public float remainingSeconds,rentalExpiresAt;Transform arms;ParticleSystem spray;MeshRenderer coverageRing;Transform[] droplets,splashes;
        public bool WaterVisualsActive => coverageRing!=null&&coverageRing.enabled&&spray!=null&&spray.isPlaying&&droplets!=null&&droplets[0]!=null&&droplets[0].gameObject.activeSelf&&splashes!=null;
        public string InteractionHint => portable?"Vòi thuê • còn "+Mathf.CeilToInt(remainingSeconds/60)+" phút game • tự tưới, không nạp nước":
            "Trạm vùng "+(region+1)+" • tự tưới bán kính 6 m, không cần nạp nước";
        public void InitializeVisuals(Transform rotatingArms)
        {
            arms=rotatingArms;
            var waterShader=Shader.Find("Universal Render Pipeline/Unlit");
            if(waterShader==null)waterShader=Shader.Find("Universal Render Pipeline/Lit");
            var waterMaterial=new Material(waterShader);waterMaterial.color=new Color(.10f,.82f,1f);
            // Keep the coverage guide just above the soil, including portable units.
            var ring=new GameObject("Vùng tưới 6 mét");ring.transform.SetParent(transform,false);ring.transform.localPosition=new Vector3(0,-.88f,0);
            var ringMesh=new Mesh { name="Vòng tưới phẳng 6 mét" };
            const int segments=96;
            var vertices=new Vector3[(segments+1)*2];var triangles=new int[segments*6];
            for(int i=0;i<=segments;i++)
            {
                float angle=i*Mathf.PI*2/segments;float x=Mathf.Cos(angle),z=Mathf.Sin(angle);
                vertices[i*2]=new Vector3(x*5.94f,0,z*5.94f);
                vertices[i*2+1]=new Vector3(x*6.06f,0,z*6.06f);
                if(i==segments)continue;
                int t=i*6,a=i*2,b=(i+1)*2;
                triangles[t]=a;triangles[t+1]=b;triangles[t+2]=a+1;
                triangles[t+3]=a+1;triangles[t+4]=b;triangles[t+5]=b+1;
            }
            ringMesh.vertices=vertices;ringMesh.triangles=triangles;ringMesh.RecalculateNormals();
            ring.AddComponent<MeshFilter>().sharedMesh=ringMesh;
            coverageRing=ring.AddComponent<MeshRenderer>();coverageRing.sharedMaterial=waterMaterial;
            var particles=new GameObject("Hạt phun nước");particles.transform.SetParent(arms,false);particles.transform.localPosition=Vector3.zero;
            particles.transform.localRotation=Quaternion.Euler(90,0,0);
            spray=particles.AddComponent<ParticleSystem>();var main=spray.main;main.startLifetime=.85f;main.startSpeed=.35f;main.startSize=.10f;
            main.startColor=new Color(.35f,.78f,1,.9f);main.gravityModifier=.9f;main.maxParticles=260;
            var emission=spray.emission;emission.rateOverTime=160;emission.enabled=false;
            var shape=spray.shape;shape.shapeType=ParticleSystemShapeType.Circle;shape.radius=1.45f;shape.radiusThickness=1;
            var renderer=spray.GetComponent<ParticleSystemRenderer>();var material=new Material(Shader.Find("Universal Render Pipeline/Lit"));material.color=new Color(.25f,.72f,1,.9f);renderer.material=material;
            var sphere=GameObject.CreatePrimitive(PrimitiveType.Sphere);renderer.renderMode=ParticleSystemRenderMode.Mesh;
            renderer.mesh=sphere.GetComponent<MeshFilter>().sharedMesh;Destroy(sphere);
            droplets=new Transform[96];
            for(int i=0;i<droplets.Length;i++)
            {
                var drop=GameObject.CreatePrimitive(PrimitiveType.Sphere);drop.name="Giọt nước "+(i+1);drop.transform.SetParent(arms,false);
                drop.transform.localScale=Vector3.one*.12f;Destroy(drop.GetComponent<Collider>());
                drop.GetComponent<Renderer>().material=waterMaterial;drop.SetActive(false);droplets[i]=drop.transform;
            }
            splashes=new Transform[24];
            for(int i=0;i<splashes.Length;i++)
            {
                var splash=GameObject.CreatePrimitive(PrimitiveType.Sphere);splash.name="Nước chạm đất "+(i+1);
                splash.transform.SetParent(ring.transform,false);splash.transform.localScale=new Vector3(.15f,.025f,.15f);
                Destroy(splash.GetComponent<Collider>());splash.GetComponent<Renderer>().material=waterMaterial;
                splash.SetActive(false);splashes[i]=splash.transform;
            }
        }
        void Update()
        {
            bool active=portable?remainingSeconds>0:FarmWaterSystem.Instance!=null&&FarmWaterSystem.Instance.StationBuilt[region];
            if(arms!=null&&active)arms.Rotate(0,42*Time.deltaTime,0,Space.Self);
            if(coverageRing!=null)coverageRing.enabled=true;
            if(spray!=null)
            {var emission=spray.emission;emission.enabled=active;
             if(active&&!spray.isPlaying)spray.Play();else if(!active&&spray.isPlaying)spray.Stop(true,ParticleSystemStopBehavior.StopEmittingAndClear);}
            if(droplets!=null)for(int i=0;i<droplets.Length;i++)
            {
                droplets[i].gameObject.SetActive(active);if(!active)continue;
                float phase=Mathf.Repeat(Time.time*1.2f+(i%24)/24f+(i/24)*.07f,1);
                float angle=(i/24)*Mathf.PI*.5f+Mathf.Sin(i*10.7f)*.16f;
                float radius=1.2f+phase*4.2f;
                droplets[i].localPosition=new Vector3(Mathf.Cos(angle)*radius,-3f*phase*phase,Mathf.Sin(angle)*radius);
            }
            if(splashes!=null)for(int i=0;i<splashes.Length;i++)
            {
                float phase=Mathf.Repeat(Time.time*2f+i*.31f,1);
                bool visible=active&&phase<.35f;splashes[i].gameObject.SetActive(visible);
                if(!visible)continue;
                float angle=i*2.39996f;float radius=2f+(i*7%13)*.27f;
                splashes[i].localPosition=new Vector3(Mathf.Cos(angle)*radius,.03f,Mathf.Sin(angle)*radius);
                float size=.08f+.18f*(1f-phase/.35f);
                splashes[i].localScale=new Vector3(size,.025f,size);
            }
        }
        public bool CanInteract(FarmPlayer player) => true;
        public void Interact(PlayerInteraction actor)
        {
            actor.Say(portable?"Vòi đang tự tưới. Chuột phải để thu hồi và kết thúc thuê.":"Trạm tự tưới, không cần nạp nước.");
        }
        public void SetHighlighted(bool selected) => InteractionOutline.Set(this,selected);
    }
}
