using System;
using UnityEngine;
namespace NongTrai
{
    // Các trường cũ chỉ dùng đọc và hoàn trả phiên đấu giá trong bản lưu trước v7.
    [Serializable] public sealed class IslandState
    {
        public int blueprints,lastMinigameDay,listingItem=-1,listingReward;
        public float listingSeconds;public int[] affinity,lastTalkDay;public bool[] friends;
        public Vector3 farmPosition,explorePosition;public bool hasFarmPosition,hasExplorePosition;
    }
    public sealed class IslandManager : MonoBehaviour
    {
        public static IslandManager Instance { get; private set; }
        public FarmHud hud;public FarmShop shop;public FarmInventory inventory;public FarmExpansion progress;public FarmPlayer player;
        public int Blueprints { get; private set; }
        public GameObject MapPanel { get; private set; }
        Vector3 farmPosition,explorePosition;bool hasFarmPosition,hasExplorePosition;
        public Vector3 FarmPosition=>hasFarmPosition?farmPosition:FarmArrival;
        public Vector3 ExplorePosition=>hasExplorePosition?explorePosition:ExploreArrival;
        public static readonly Vector3 FarmArrival=new Vector3(0,.4f,14);
        public static readonly Vector3 ExploreArrival=new Vector3(200,1000.4f,-20);
        void Awake()=>Instance=this;
        void Start()
        {
            if(GetComponent<FarmDeliveryRush>()==null)gameObject.AddComponent<FarmDeliveryRush>();
            if(GetComponent<FarmRunner>()==null)gameObject.AddComponent<FarmRunner>();
            if(hud.player.GetComponent<FarmConsumption>()==null)hud.player.gameObject.AddComponent<FarmConsumption>();
            if(hud.player.GetComponent<FarmerRunEffects>()==null)hud.player.gameObject.AddComponent<FarmerRunEffects>();
            if(GetComponent<FarmForge>()==null)gameObject.AddComponent<FarmForge>();
            MapPanel=FarmUi.Panel(hud.transform,"Hai bản đồ",new Vector2(920,540));
            FarmUi.TmpLabel(MapPanel.transform,"NÔNG TRẠI & KHÁM PHÁ",new Vector2(30,-25),new Vector2(860,60),32);
            FarmUi.Button(MapPanel.transform,"NÔNG TRẠI • Trồng cây, chăn nuôi, chế biến, giao đơn",new Vector2(30,-130),new Vector2(860,85),()=>Travel(0));
            FarmUi.Button(MapPanel.transform,"KHÁM PHÁ • Đào địa hình, lấy quặng, xây bằng khối",new Vector2(30,-235),new Vector2(860,75),()=>Travel(1));
            FarmUi.Button(MapPanel.transform,"FARM RUNNER • Map chạy 3 làn • Vé, xu và quà mốc KM",new Vector2(30,-330),new Vector2(860,75),()=>FarmRunner.Instance?.OpenMenu());
            FarmUi.Label(MapPanel.transform,"A/D đổi làn • W/Space nhảy • S trượt. Giao đơn hộp thư nhận vé.",new Vector2(30,-417),new Vector2(860,38),20);
            FarmUi.Button(MapPanel.transform,"Trở lại game",new Vector2(30,-455),new Vector2(860,55),hud.Resume);
            MapPanel.SetActive(false);player.PauseChanged+=OnPause;
        }
        void OnDestroy(){if(Instance==this)Instance=null;if(player!=null)player.PauseChanged-=OnPause;}
        void OnPause(bool value){if(!value&&MapPanel!=null)MapPanel.SetActive(false);}
        public void OpenMap(){hud.ShowOverlay(MapPanel);}
        public bool Travel(int index)
        {
            if(index<0||index>1)return false;
            bool exploring=player.transform.position.y>500;
            if(exploring){explorePosition=player.transform.position;hasExplorePosition=true;}
            else{farmPosition=player.transform.position;hasFarmPosition=true;}
            hud.Resume();player.Teleport(index==0?FarmPosition:ExplorePosition);
            hud.Notify(index==0?"Nông trại • B túi đồ • M chế biến • chuột trái tương tác":"Khám phá • Đổi map giữ vị trí cũ • Chỉ hồi sinh mới về cổng • Sông (-36,0), biển (0,-75)");return true;
        }
        public void UnlockMiningBlueprint()
        { if(Blueprints>0)return;Blueprints=1;hud.Notify("Đào 30 khối: đã mở bản vẽ lò nung và đèn thủ công!"); }
        public IslandState Snapshot()
        {if(player.transform.position.y>500){explorePosition=player.transform.position;hasExplorePosition=true;}else{farmPosition=player.transform.position;hasFarmPosition=true;}
         return new IslandState{blueprints=Blueprints,listingItem=-1,farmPosition=farmPosition,explorePosition=explorePosition,hasFarmPosition=hasFarmPosition,hasExplorePosition=hasExplorePosition};}
        public void Restore(IslandState state)
        {
            Blueprints=state==null?0:Mathf.Max(0,state.blueprints);
            hasFarmPosition=state!=null&&state.hasFarmPosition;hasExplorePosition=state!=null&&state.hasExplorePosition;
            farmPosition=hasFarmPosition?state.farmPosition:FarmArrival;
            explorePosition=hasExplorePosition?state.explorePosition:ExploreArrival;
            if(state!=null&&state.listingSeconds>0&&state.listingItem>=0&&state.listingItem<27)inventory.Add(state.listingItem,1);
        }
    }
}
